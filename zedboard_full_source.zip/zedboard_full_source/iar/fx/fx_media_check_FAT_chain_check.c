/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2017 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** FileX Component                                                       */
/**                                                                       */
/**   Media                                                               */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define FX_SOURCE_CODE


/* Include necessary system files.  */

#include "fx_api.h"
#include "fx_media.h"
#include "fx_utility.h"


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _fx_media_check_FAT_chain_check                     PORTABLE C      */
/*                                                           5.5          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function walks the supplied FAT chain looking for cross links  */
/*    (FAT entries already used in another FAT chain) and abnormal FAT    */
/*    entries and invalid chain termination.                              */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    media_ptr                             Pointer to a previously       */
/*                                            opened media                */
/*    starting_cluster                      Starting cluster of FAT chain */
/*    last_valid_cluster                    Last valid cluster of chain   */
/*    total_valid_clusters                  Total number of valid clusters*/
/*    logical_fat                           Pointer to the logical FAT    */
/*                                            bit map                     */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    error                                 Error code                    */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _fx_utility_FAT_entry_read            Read a FAT entry              */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    _fx_check_media                       Check media function          */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-12-2005     William E. Lamie         Initial Version 5.0           */
/*  07-18-2007     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.1    */
/*  03-01-2009     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.2    */
/*  11-01-2015     William E. Lamie         Modified comment(s),          */
/*                                            used FAT reserved and FAT   */
/*                                            last from media structure,  */
/*                                            resulting in version 5.3    */
/*  04-15-2016     William E. Lamie         Modified comment(s),          */
/*                                            cleaned up the code,        */
/*                                            resulting in version 5.4    */
/*  04-03-2017     William E. Lamie         Modified comment(s),          */
/*                                            fixed compiler warnings,    */
/*                                            resulting in version 5.5    */
/*                                                                        */
/**************************************************************************/
ULONG  _fx_media_check_FAT_chain_check(FX_MEDIA *media_ptr, ULONG starting_cluster, ULONG *last_valid_cluster, ULONG *total_valid_clusters, UCHAR *logical_fat)
{

ULONG prev_cluster, cluster, next_clust = 0;
ULONG count, error;
UINT  status;


    /* Initialize the error code.  */
    error =  0;

    /* Setup at the first cluster.  */
    cluster =  starting_cluster;

    /* Initialize the previous cluster.  */
    prev_cluster =  0;

    /* Initialize the count to 0. */
    count =  0;

    /* Loop to walk through the FAT chain.  */
    while ((cluster >= (ULONG)FX_FAT_ENTRY_START) && (cluster < media_ptr -> fx_media_fat_reserved))
    {


        /* Determine if this cluster is already in the logical FAT bit map.  */
        if (logical_fat[cluster / 8] & (1 << (cluster % 8)))
        {

            /* Yes, the cluster is already being used by another file or
               sub-directory.  */
            error =  FX_FAT_CHAIN_ERROR;
            break;
        }

        /* Now read the contents of the cluster.  */
        status =  _fx_utility_FAT_entry_read(media_ptr, cluster, &next_clust);

        /* Check the return status.  */
        if (status != FX_SUCCESS)
        {

            /* Yes, the cluster is already being used by another file or
               sub-directory.  */
            error =  FX_IO_ERROR;
            break;
        }

        /* Determine if the link is circular or the count is greater than the
           total clusters.  */
        if ((cluster == next_clust) || (count > media_ptr -> fx_media_total_clusters) ||
            (next_clust < (ULONG)FX_FAT_ENTRY_START) ||
            ((next_clust >= media_ptr -> fx_media_fat_reserved) && (next_clust != media_ptr -> fx_media_fat_last)))
        {

            error =  FX_FAT_CHAIN_ERROR;
            break;
        }

        /* Everything is good with the chain at this point.  Mark it as valid.  */
        logical_fat[cluster >> 3] |= (UCHAR)(1 << (cluster & 7));

        /* Move the cluster variable forward.  */
        prev_cluster =  cluster;
        cluster =       next_clust;

        /* Increment the number of valid clusters.  */
        count++;
    }

    /* Return the last valid cluster and the total valid cluster count.  */
    *last_valid_cluster =   prev_cluster;
    *total_valid_clusters = count;

    /* Return error code.  */
    return(error);
}

