/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Control Message Protocol (ICMP)                            */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_ipv6.h"
#include "nx_icmpv6.h"

#ifdef NX_IPSEC_ENABLE
#include "nx_ipsec.h"
#endif /* NX_IPSEC_ENABLE */


#ifdef FEATURE_NX_IPV6


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_icmpv6_DAD_failure                              PORTABLE C      */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function is called when the DAD process determines that a      */
/*    duplicate address is present on the local network.  The interface   */
/*    is set to an invalid state.                                         */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                IP stack instance             */
/*    ipv6_address                          The local IPv6 interface      */
/*                                            that detects the failure.   */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    [ipv6_address_change_notify]         User callback function         */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    _nx_icmpv6_process_na                                               */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-30-2007     Yuxin Zhou               Initial Version 5.2           */
/*  08-03-2009     Yuxin Zhou               Modified comments,            */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            modified struct field names */
/*                                            missing struct name prefix, */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s), changed  */
/*                                            name of the IPv6 address    */
/*                                            structure name,             */
/*                                            added IPsec support,        */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s), added a  */
/*                                            callback function on a      */
/*                                            failed address DAD,         */
/*                                            optimized interface index,  */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s), fixed a  */
/*                                            bug that address was not    */
/*                                            removed from interface,     */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            renamed the argument name   */
/*                                            to make it sense, renamed   */
/*                                            symbols, fixed compiler     */
/*                                            warnings, resulting in      */
/*                                            version 5.9                 */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.11   */
/*                                                                        */
/**************************************************************************/

#ifndef NX_DISABLE_IPV6_DAD
VOID _nx_icmpv6_DAD_failure(NX_IP *ip_ptr, NXD_IPV6_ADDRESS *ipv6_address)
{
#ifdef NX_ENABLE_IPV6_ADDRESS_CHANGE_NOTIFY
UINT              interface_index;
UINT              ipv6_addr_index;
#endif /* NX_ENABLE_IPV6_ADDRESS_CHANGE_NOTIFY */
NXD_IPV6_ADDRESS *address_ptr;

    /* Set the interface to an invalid state. */
    ipv6_address -> nxd_ipv6_address_state = NX_IPV6_ADDR_STATE_UNKNOWN;
    ipv6_address -> nxd_ipv6_address_valid = NX_FALSE;

    /* Indicate the DAD process is disabled. */
    ipv6_address -> nxd_ipv6_address_DupAddrDetectTransmit = 0;
#ifdef NX_ENABLE_IPV6_ADDRESS_CHANGE_NOTIFY
    if (ip_ptr -> nx_ipv6_address_change_notify)
    {
        ipv6_addr_index = (ULONG)ipv6_address -> nxd_ipv6_address_index;
        interface_index = (ULONG)ipv6_address -> nxd_ipv6_address_attached -> nx_interface_index;
        ip_ptr -> nx_ipv6_address_change_notify(ip_ptr, NX_IPV6_ADDRESS_DAD_FAILURE, interface_index, ipv6_addr_index, &ipv6_address -> nxd_ipv6_address[0]);
    }
#else
    NX_PARAMETER_NOT_USED(ip_ptr);
#endif /* NX_ENABLE_IPV6_ADDRESS_CHANGE_NOTIFY */

    /* Remove address from interface. */
    if (ipv6_address == ipv6_address -> nxd_ipv6_address_attached -> nxd_interface_ipv6_address_list_head)
    {
        ipv6_address -> nxd_ipv6_address_attached -> nxd_interface_ipv6_address_list_head = ipv6_address -> nxd_ipv6_address_next;
    }
    else
    {

        for (address_ptr = ipv6_address -> nxd_ipv6_address_attached -> nxd_interface_ipv6_address_list_head;
             address_ptr != NX_NULL;
             address_ptr = address_ptr -> nxd_ipv6_address_next)
        {
            if (address_ptr -> nxd_ipv6_address_next == ipv6_address)
            {
                address_ptr -> nxd_ipv6_address_next = ipv6_address -> nxd_ipv6_address_next;
            }
        }
    }
}

#endif  /* NX_DISABLE_IPV6_DAD */
#endif  /* FEATURE_NX_IPV6 */

