
/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/

/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Control Message Protocol (ICMP)                            */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */
#include "nx_api.h"
#include "nx_ipv6.h"
#include "nx_icmpv6.h"

#ifdef FEATURE_NX_IPV6

/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_invalidate_destination_entry                    PORTABLE C      */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function invalidates all destination entries whose next hop    */
/*    address matches the supplied IP address regardless of the           */
/*    destination address.                                                */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                Pointer to IP                 */
/*    next_hop_ip                           The next hop address to find  */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    NONE                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    _nd_cache_delete                      Delete a neighbor cache.      */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-30-2007     Yuxin Zhou               Initial Version 5.2           */
/*  08-03-2009     Yuxin Zhou               Added mutex protection,       */
/*                                            resulting in version 5.3.   */
/*  11-23-2009     Yuxin Zhou               Fixed compiler warnings,      */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s), optimized*/
/*                                            the internal process,       */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s),          */
/*                                            fixed compiler warnings,    */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            renamed symbols, resulting  */
/*                                            in version 5.9              */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s), and      */
/*                                            moved the destination table */
/*                                            to the IP structure,        */
/*                                            resulting in version 5.11   */
/*                                                                        */
/**************************************************************************/
VOID _nx_invalidate_destination_entry(NX_IP *ip_ptr, ULONG *next_hop_ip)
{

UINT i, table_size;

    /* Set a local variable for convenience. */
    table_size = ip_ptr -> nx_ipv6_destination_table_size;

    /* Check if there have been any destinations in the table. */
    if (table_size == 0)
    {
        return;
    }

    /* Loop through the whole table to match the IP address. */
    for (i = 0; table_size && (i < NX_IPV6_DESTINATION_TABLE_SIZE); i++)
    {

        /* Skip over empty slots. */
        if (!ip_ptr -> nx_ipv6_destination_table[i].nx_ipv6_destination_entry_valid)
        {
            continue;
        }

        /* Keep track of valid entries we have checked. */
        table_size--;

        /* Match the supplied next hop with the table entry next hop. */
        if (CHECK_IPV6_ADDRESSES_SAME(ip_ptr -> nx_ipv6_destination_table[i].nx_ipv6_destination_entry_next_hop, next_hop_ip))
        {

            /* A matching entry is found.  Mark the entry as invalid. */
            ip_ptr -> nx_ipv6_destination_table[i].nx_ipv6_destination_entry_valid = 0;

            /* Decrease the count of available destinations. */
            ip_ptr -> nx_ipv6_destination_table_size--;
        }
    }

    return;
}

#endif  /* FEATURE_NX_IPV6 */

