/*
 * Copyright (c) 2016, Xilinx Inc. and Contributors. All rights reserved.
 *
 * Copyright (c) 2018 Express Logic Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. Neither the name of Xilinx nor the names of its contributors may be used
 *    to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * @file	tx_zynqmp_a53.c
 * @brief	ThreadX ZynqMP APU specific system primitives implementation.
 */

#define TX_DISABLE_ERROR_CHECKING
#include <stdint.h>
#include <metal/cache.h>
#include <metal/device.h>
#include <metal/io.h>
#include <metal/sleep.h>
#include <metal/sys.h>
#include <metal/utilities.h>
#include <tx_api.h>
#include <tx_zynqmp.h>

#if 0
void xil_printf( const char *ctrl1, ...);
#define DBGPRINTF(x, ...) xil_printf(x, ##__VA_ARGS__)
#else
#define DBGPRINTF(x, ...)
#endif

/* define prototypes of Xil functions so we don't need to include bsp headers */

void Xil_DCacheFlush(void);
void Xil_DCacheFlushRange(intptr_t adr, intptr_t len);
void Xil_DCacheInvalidate(void);
void Xil_DCacheInvalidateRange(intptr_t adr, intptr_t len);


/* define metal global data */
struct metal_state _metal;


/* initialize library */

int metal_sys_init(const struct metal_init_params *params)
{
    metal_unused(params);
    metal_bus_register(&metal_generic_bus);
    return 0;
}

void metal_sys_finish(void)
{
    metal_bus_unregister(&metal_generic_bus);
}


/* flush data cache */

void metal_cache_flush(void *addr, unsigned int len)
{
    if (!addr && !len)
        Xil_DCacheFlush();
    else
        Xil_DCacheFlushRange((intptr_t)addr, (intptr_t)len);
}


/* invalidate data cache */

void metal_cache_invalidate(void *addr, unsigned int len)
{
    if (!addr && !len)
        Xil_DCacheInvalidate();
    else
        Xil_DCacheInvalidateRange((intptr_t)addr, (intptr_t)len);
}


/* get virtual pointer to shared memory */

void metal_sys_io_mem_map(struct metal_io_region *io)
{
    void *va;
    if (!io->mem_flags) {
        DBGPRINTF("metal_io_mem_map: io:%p,0x%x (not shared)\r\n", (void *) io->physmap[0], (unsigned) io->size);
        io->virt = (void *) io->physmap[0];
        return;
    }
    va = tx_zynqmp_map_nocache((uintptr_t) io->physmap[0], io->size);
    io->virt = va != NULL ? va : (void *) io->physmap[0];
    DBGPRINTF("metal_io_mem_map: io:%p,0x%x p=%p\r\n", (void *) io->physmap[0], (unsigned) io->size, io->virt);
}


/* wait for small period of time */

#define TICK_PERIOD_USEC (1000000 / TX_TIMER_TICKS_PER_SECOND)

int metal_sleep_usec(unsigned int usec)
{
    if (usec < TICK_PERIOD_USEC)
    {
        tx_zynqmp_udelay(usec);
        return 0;
    }
    tx_thread_sleep( (usec + TICK_PERIOD_USEC - 1) / TICK_PERIOD_USEC);
    return 0;
}
