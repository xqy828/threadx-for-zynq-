/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Ethernet driver for Xilinx Zynq UltraScale+ MPSoC GEM               */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#ifndef NX_DRIVER_ZYNQMP_GEM_H
#define NX_DRIVER_ZYNQMP_GEM_H

#include <stdint.h>

/* Include ThreadX header file, if not already.  */

#ifndef TX_API_H
#include "tx_api.h"
#endif

/* Include NetX header file, if not already.  */

#ifndef NX_API_H
#include "nx_api.h"
#endif

#ifdef   __cplusplus
/* Yes, C++ compiler is present.  Use standard C.  */
extern   "C" {
#endif

/* Define the Buffer Descriptors size and minimum alignment */
#ifdef __aarch64__
#define NX_DRIVER_ZYNQMP_GEM_DMABD_SIZE         16
#define NX_DRIVER_ZYNQMP_GEM_DMABD_ALIGNMENT    8
#else
#define NX_DRIVER_ZYNQMP_GEM_DMABD_SIZE         8
#define NX_DRIVER_ZYNQMP_GEM_DMABD_ALIGNMENT    4
#endif

/* Max number of buffers */
#define NX_DRIVER_ZYNQMP_GEM_DMABD_RX_MAX       128
#define NX_DRIVER_ZYNQMP_GEM_DMABD_TX_MAX       128

/* Max number of instances */
#define NX_DRIVER_ZYNQMP_MAX_INSTANCES          4

/* Number of bits of the multicast hash filter */
#define NX_DRIVER_MULTICAST_FILTER_BITS         64


/* Determine if the driver's source file is being compiled. The constants and typdefs are only valid within
   the driver's source file compilation.  */

#ifdef NX_DRIVER_SOURCE


/* Define generic constants and macros for all NetX Ethernet drivers.  */

#define NX_DRIVER_ETHERNET_IP                   0x0800
#define NX_DRIVER_ETHERNET_IPV6                 0x86dd
#define NX_DRIVER_ETHERNET_ARP                  0x0806
#define NX_DRIVER_ETHERNET_RARP                 0x8035

#define NX_DRIVER_ETHERNET_MTU                  1514
#define NX_DRIVER_ETHERNET_FRAME_SIZE           14

#define NX_DRIVER_DEFERRED_PACKET_RECEIVED      1
#define NX_DRIVER_DEFERRED_DEVICE_RESET         2
#define NX_DRIVER_DEFERRED_PACKET_TRANSMITTED   4

#define NX_DRIVER_STATE_NOT_INITIALIZED         1
#define NX_DRIVER_STATE_INITIALIZE_FAILED       2
#define NX_DRIVER_STATE_INITIALIZED             3
#define NX_DRIVER_STATE_LINK_ENABLED            4

#define NX_DRIVER_ERROR                         90


#define NX_DRIVER_ETHERNET_HEADER_REMOVE(p)   \
{   \
    p -> nx_packet_prepend_ptr =  p -> nx_packet_prepend_ptr + NX_DRIVER_ETHERNET_FRAME_SIZE;  \
    p -> nx_packet_length =  p -> nx_packet_length - NX_DRIVER_ETHERNET_FRAME_SIZE;    \
}


/* Define the link state (speed and duplex mode). */

#define NX_DRIVER_LINK_DOWN         0
#define NX_DRIVER_LINK_SPEED_MASK   3
#define NX_DRIVER_LINK_SPEED_10     1
#define NX_DRIVER_LINK_SPEED_100    2
#define NX_DRIVER_LINK_SPEED_1000   3
#define NX_DRIVER_LINK_FULLDUPLEX   4


/* Define Ethernet driver information typedef. */

typedef struct NX_DRIVER_INFORMATION_STRUCT
{
    /* The GEM ID */
    USHORT                      nx_driver_information_id;

    /* The Interrupt vector number */
    USHORT                      nx_driver_information_irq;

    /* The GEM Registers Base address */
    struct GEM_REGS_STRUCT *    nx_driver_information_gem;

    /* The Clock Generator Control register */
    volatile uint32_t *         nx_driver_information_crl_apb;

    /* Define the PHY address */
    USHORT                      nx_driver_information_phy_addr;

    /* Define the PHY identifier */
    USHORT                      nx_driver_information_phy_id;

    /* The RX buffer descriptors */
    struct DMA_BD_STRUCT *      nx_driver_information_rx_bd;

    /* The TX buffer descriptors */
    struct DMA_BD_STRUCT *      nx_driver_information_tx_bd;

    /* RX packets in descriptors */
    NX_PACKET *                 nx_driver_information_rx_bd_packets[NX_DRIVER_ZYNQMP_GEM_DMABD_RX_MAX];

    /* TX packets in descriptors */
    NX_PACKET *                 nx_driver_information_tx_bd_packets[NX_DRIVER_ZYNQMP_GEM_DMABD_TX_MAX];

#ifdef __aarch64__
    /* Physical address of RX buffer descriptors */
    uintptr_t                   nx_driver_information_rx_bd_paddr;

    /* Physical address of TX buffer descriptors */
    uintptr_t                   nx_driver_information_tx_bd_paddr;
#endif

    /* Number of RX buffer descriptors */
    UINT                        nx_driver_information_rx_bd_num;

    /* Number of TX buffer descriptors */
    UINT                        nx_driver_information_tx_bd_num;

    /* Current RX buffer */
    UINT                        nx_driver_information_rx_id;

    /* Current TX buffer */
    UINT                        nx_driver_information_tx_id;

    /* Number of TX buffers pending */
    UINT                        nx_driver_information_tx_num;

    /* NetX IP instance that this driver is attached to.  */
    NX_IP *                     nx_driver_information_ip_ptr;

    /* Driver's current state.  */
    ULONG                       nx_driver_information_state;

    /* Packet pool used for receiving packets. */
    NX_PACKET_POOL *            nx_driver_information_packet_pool_ptr;

    /* Define the driver interface association.  */
    NX_INTERFACE *              nx_driver_information_interface;

    /* Define the deferred event field. This will contain bits representing events
       deferred from the ISR for processing in the thread context.  */
    ULONG                       nx_driver_information_deferred_events;

    /* Define the link state */
    UINT                        nx_driver_information_link;

    /* Statistics */
    ULONG                       nx_driver_information_rx_packets;
    ULONG                       nx_driver_information_tx_packets;
    ULONG                       nx_driver_information_errors;
    ULONG                       nx_driver_information_alloc_errors;
    ULONG                       nx_driver_information_drops;

    /* PHY timer */
    TX_TIMER                    nx_driver_information_timer;

    /* Multicast addresses filter */
    UCHAR                       nx_driver_information_multicast_filter[NX_DRIVER_MULTICAST_FILTER_BITS];

} NX_DRIVER_INFORMATION;


/* Define the Ethernet driver entry point. */

void nx_driver_zynqmp_entry(NX_DRIVER_INFORMATION *driver_ptr, NX_IP_DRIVER *driver_req_ptr);


/* Define the MII operations functions. */

UINT nx_driver_zynqmp_mii_read(NX_DRIVER_INFORMATION *driver_ptr, UINT addr, UINT reg);

VOID nx_driver_zynqmp_mii_write(NX_DRIVER_INFORMATION *driver_ptr, UINT addr, UINT reg, UINT value);

VOID nx_driver_zynqmp_mii_read_async(NX_DRIVER_INFORMATION *driver_ptr, UINT addr, UINT reg);

UINT nx_driver_zynqmp_mii_read_async_get(NX_DRIVER_INFORMATION *driver_ptr, UINT *value_ptr);


/* Define the PHY driver functions. */

UINT nx_driver_zynqmp_phy_reset(NX_DRIVER_INFORMATION *driver_ptr);

UINT nx_driver_zynqmp_phy_status(NX_DRIVER_INFORMATION *driver_ptr);


#endif /* NX_DRIVER_SOURCE */


/* Define global drivers entry functions. */

VOID nx_driver_zynqmp_gem0(NX_IP_DRIVER *driver_req_ptr);

VOID nx_driver_zynqmp_gem1(NX_IP_DRIVER *driver_req_ptr);

VOID nx_driver_zynqmp_gem2(NX_IP_DRIVER *driver_req_ptr);

VOID nx_driver_zynqmp_gem3(NX_IP_DRIVER *driver_req_ptr);


/* Define driver configuration functions. */

UINT nx_driver_zynqmp_gem_phy_addr_set(NX_IP *ip_ptr, UINT interface_index, UINT phy_addr);

UINT nx_driver_zynqmp_gem_dmabds_set(NX_IP *ip_ptr, UINT interface_index, void *rx_ptr, UINT rx_num, void *tx_ptr, UINT tx_num);


#ifdef   __cplusplus
/* Yes, C++ compiler is present.  Use standard C.  */
    }
#endif

#endif
