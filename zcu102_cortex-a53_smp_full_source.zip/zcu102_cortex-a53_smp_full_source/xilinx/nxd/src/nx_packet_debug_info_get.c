/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Packet Pool Management (Packet)                                     */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_packet.h"


#ifdef NX_ENABLE_PACKET_DEBUG_INFO
/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_packet_debug_info_get                           PORTABLE C      */
/*                                                           5.11 SP1     */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function returns status of packet for specified index          */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    pool_ptr                              Pool to packet pool           */
/*    packet_index                          Index of packet in pool       */
/*    packet_pptr                           Pointer to packet for output  */
/*    packet_status                         Status of packet for output   */
/*    thread_info                           Thread of packet for output   */
/*    file_info                             File of packet for output     */
/*    line                                  Line of packet for output     */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                                Completion status             */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  02-22-2016     Yuxin Zhou               Initial Version 5.9           */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.11   */
/*  12-15-2018     Yuxin Zhou               Modified comment(s), and      */
/*                                            supported for 64-bit mode,  */
/*                                            resulting in version 5.11SP1*/
/*                                                                        */
/**************************************************************************/
UINT  _nx_packet_debug_info_get(NX_PACKET_POOL *pool_ptr, UINT packet_index, NX_PACKET **packet_pptr,
                                ULONG *packet_status, CHAR **thread_info, CHAR **file_info, ULONG *line)
{
ULONG      payload_size;    /* Rounded payload size       */
ULONG      header_size;     /* Rounded header size        */
NX_PACKET *packet_ptr;

    /* Get the first packet. */
    packet_ptr = (NX_PACKET *)(pool_ptr -> nx_packet_pool_start);

    /* Calculate header size. */
    header_size = (ULONG)((ALIGN_TYPE)(packet_ptr -> nx_packet_data_start) - (ALIGN_TYPE)packet_ptr);

    /* Round the packet size up to something that helps guarantee proper alignment for header and payload.  */
    payload_size = (ULONG)(((pool_ptr -> nx_packet_pool_payload_size + header_size + NX_PACKET_ALIGNMENT  - 1) / NX_PACKET_ALIGNMENT) * NX_PACKET_ALIGNMENT - header_size);

    /* Calculate packet pointer. */
    packet_ptr = (NX_PACKET *)(pool_ptr -> nx_packet_pool_start + packet_index * (header_size + payload_size));

    /* Get packet pointer. */
    if (packet_pptr)
    {
        *packet_pptr = packet_ptr;
    }

    /* Get packet status. */
    if (packet_status)
    {
        *packet_status = (ULONG)(ALIGN_TYPE)packet_ptr -> nx_packet_union_next.nx_packet_tcp_queue_next;
    }

    /* Get thread info. */
    if (thread_info)
    {
        *thread_info = packet_ptr -> nx_packet_debug_thread;
    }

    /* Get file info. */
    if (file_info)
    {
        *file_info = packet_ptr -> nx_packet_debug_file;
    }

    /* Get line. */
    if (line)
    {
        *line = packet_ptr -> nx_packet_debug_line;
    }

    /* Return success. */
    return(NX_SUCCESS);
}
#endif /* NX_ENABLE_PACKET_DEBUG_INFO */

