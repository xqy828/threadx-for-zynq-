/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Transmission Control Protocol (TCP)                                 */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_tcp.h"


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_tcp_free_port_find                              PORTABLE C      */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function finds the first available TCP port, starting from the */
/*    supplied port.  If no available ports are found, an error is        */
/*    returned.                                                           */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                IP instance pointer           */
/*    port                                  Starting port                 */
/*    free_port_ptr                         Pointer to return free port   */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                                Completion status             */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    tx_mutex_get                          Obtain protection mutex       */
/*    tx_mutex_put                          Release protection mutex      */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-12-2005     William E. Lamie         Initial Version 5.0           */
/*  08-09-2007     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.1    */
/*  12-30-2007     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.2    */
/*  08-03-2009     William E. Lamie         Modified comment(s), and added*/
/*                                            logic for trace support,    */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s), added    */
/*                                            supported NAT feature,      */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s),          */
/*                                            supported random port find, */
/*                                            resulting in version 5.11   */
/*                                                                        */
/**************************************************************************/
UINT  _nx_tcp_free_port_find(NX_IP *ip_ptr, UINT port, UINT *free_port_ptr)
{

UINT                   index;
UINT                   bound;
UINT                   starting_port;
NX_TCP_SOCKET         *search_ptr;
NX_TCP_SOCKET         *end_ptr;

#ifdef TX_ENABLE_EVENT_TRACE
TX_TRACE_BUFFER_ENTRY *trace_event;
ULONG                  trace_timestamp;
#endif


    /* If trace is enabled, insert this event into the trace buffer.  */
    NX_TRACE_IN_LINE_INSERT(NX_TRACE_TCP_FREE_PORT_FIND, ip_ptr, port, 0, 0, NX_TRACE_TCP_EVENTS, &trace_event, &trace_timestamp);

    /* Save the original port.  */
    starting_port =  port;

    /* Loop through the TCP ports until a free entry is found.  */
    do
    {

        /* Calculate the hash index in the TCP port array of the associated IP instance.  */
        index =  (UINT)((port + (port >> 8)) & NX_TCP_PORT_TABLE_MASK);

        /* Obtain the IP mutex so we can figure out whether or not the port has already
           been bound to.  */
        tx_mutex_get(&(ip_ptr -> nx_ip_protection), TX_WAIT_FOREVER);

        /* Pickup the head of the TCP ports bound list.  */
        search_ptr =  ip_ptr -> nx_ip_tcp_port_table[index];

        /* Set the bound flag to false.  */
        bound =  NX_FALSE;

        /* Determine if we need to perform a list search.  */
        if (search_ptr)
        {

            /* Walk through the circular list of TCP sockets that are already
               bound.  */
            end_ptr =     search_ptr;
            do
            {

                /* Determine if this entry is the same as the requested port.  */
                if (search_ptr -> nx_tcp_socket_port == port)
                {

                    /* Set the bound flag.  */
                    bound =  NX_TRUE;

                    /* Get out of the loop.  */
                    break;
                }

                /* Move to the next entry in the list.  */
                search_ptr =  search_ptr -> nx_tcp_socket_bound_next;
            } while (search_ptr != end_ptr);
        }

#ifdef NX_NAT_ENABLE
        if (bound == NX_FALSE)
        {

            /* Check if this IP interface has a NAT service. */
            if (ip_ptr -> nx_ip_nat_port_verify)
            {

                /* Yes, so check the port by NAT handler. If NAT does not use this port, allow NetX to use it.  */
                bound = (ip_ptr -> nx_ip_nat_port_verify)(ip_ptr, NX_PROTOCOL_TCP, port);
            }
        }
#endif

        /* Release protection.  */
        tx_mutex_put(&(ip_ptr -> nx_ip_protection));

        /* Determine if the port is available.  */
        if (!bound)
        {

            /* Setup the return port number.  */
            *free_port_ptr =  port;

            /* Update the trace event with the status.  */
            NX_TRACE_EVENT_UPDATE(trace_event, trace_timestamp, NX_TRACE_TCP_FREE_PORT_FIND, 0, 0, port, 0);

            /* Return success.  */
            return(NX_SUCCESS);
        }

        /* Move to the next port.  */
        port++;

        /* Determine if we need to wrap.  */
        if (port > NX_MAX_PORT)
        {

            /* Yes, we need to wrap around.  */
            port =  NX_SEARCH_PORT_START;
        }
    } while (starting_port != port);

    /* A free port was not found, return an error.  */
    return(NX_NO_FREE_PORTS);
}

