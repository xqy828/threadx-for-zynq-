/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Transmission Control Protocol (TCP)                                 */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_tcp.h"
#include "nx_ipv6.h"

/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nxd_tcp_socket_peer_info_get                       PORTABLE C      */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function retrieves IP address and port number of the peer      */
/*    connected to the specified TCP socket.                              */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    socket_ptr                            Pointer to the TCP sockete    */
/*    peer_ip_address                       Pointer to the IP address     */
/*                                             of the peer.               */
/*    peer_port                             Pointer to the port number    */
/*                                             of the peer.               */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    NX_SUCCESS                            Actual completion status      */
/*    NX_NOT_CONNECTED                      TCP socket is not connected   */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    tx_mutex_get                          Obtain protection             */
/*    tx_mutex_put                          Release protection            */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-30-2007     Yuxin Zhou               Initial Version 5.2           */
/*  08-03-2009     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s), added    */
/*                                            support for disabling IPv4, */
/*                                            resulting in version 5.11   */
/*                                                                        */
/**************************************************************************/
UINT  _nxd_tcp_socket_peer_info_get(NX_TCP_SOCKET *socket_ptr,
                                    NXD_ADDRESS *peer_ip_address,
                                    ULONG *peer_port)
{
#ifdef TX_ENABLE_EVENT_TRACE
ULONG  ip_address_lsw = 0;
#endif /* TX_ENABLE_EVENT_TRACE */
NX_IP *ip_ptr;


    /* Setup IP pointer. */
    ip_ptr = socket_ptr -> nx_tcp_socket_ip_ptr;

    /* Obtain the IP mutex so we can examine the bound port.  */
    tx_mutex_get(&(ip_ptr -> nx_ip_protection), TX_WAIT_FOREVER);

    /* Make sure the TCP connection has been established. */
    if ((socket_ptr -> nx_tcp_socket_state <= NX_TCP_LISTEN_STATE) ||
        (socket_ptr -> nx_tcp_socket_state > NX_TCP_ESTABLISHED))
    {

        /* Release protection.  */
        tx_mutex_put(&(ip_ptr -> nx_ip_protection));

        return(NX_NOT_CONNECTED);
    }

    /* Determine the peer IP address */

    /* Assign the IP address type (IPv4 or IPv6) */
    peer_ip_address -> nxd_ip_version = socket_ptr -> nx_tcp_socket_connect_ip.nxd_ip_version;

    /* If address type is IPv4, just copy one word. */
#ifndef NX_DISABLE_IPV4
    if (socket_ptr -> nx_tcp_socket_connect_ip.nxd_ip_version == NX_IP_VERSION_V4)
    {
        peer_ip_address -> nxd_ip_address.v4 = socket_ptr -> nx_tcp_socket_connect_ip.nxd_ip_address.v4;
    }
#endif /* !NX_DISABLE_IPV4  */

#ifdef FEATURE_NX_IPV6
    if (socket_ptr -> nx_tcp_socket_connect_ip.nxd_ip_version == NX_IP_VERSION_V6)
    {

        /* Return the IP address of the peer connected to the TCP socket. */
        COPY_IPV6_ADDRESS(socket_ptr -> nx_tcp_socket_connect_ip.nxd_ip_address.v6,
                          peer_ip_address -> nxd_ip_address.v6);
    }
#endif /* FEATURE_NX_IPV6 */

    /* Determine the peer port number and return the port number of the peer
       connected to the TCP socket. */
    *peer_port = socket_ptr -> nx_tcp_socket_connect_port;

    /* Release protection.  */
    tx_mutex_put(&(ip_ptr -> nx_ip_protection));

#ifdef TX_ENABLE_EVENT_TRACE

#ifndef NX_DISABLE_IPV4
    if (peer_ip_address -> nxd_ip_version == NX_IP_VERSION_V4)
    {
        ip_address_lsw = peer_ip_address -> nxd_ip_address.v4;
    }
#endif /* NX_DISABLE_IPV4 */

#ifdef FEATURE_NX_IPV6
    if (peer_ip_address -> nxd_ip_version == NX_IP_VERSION_V6)
    {

        ip_address_lsw = peer_ip_address -> nxd_ip_address.v6[3];
    }

#endif /* FEATURE_NX_IPV6 */

    /* If trace is enabled, insert this event into the trace buffer.  */
    NX_TRACE_IN_LINE_INSERT(NXD_TRACE_TCP_SOCKET_PEER_INFO_GET, socket_ptr, ip_address_lsw, *peer_port, 0, NX_TRACE_TCP_EVENTS, 0, 0);

#endif /* TX_ENABLE_EVENT_TRACE */

    /* Return successful completion status.  */
    return(NX_SUCCESS);
}

