/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Ethernet driver for Xilinx Zynq UltraScale+ MPSoC GEM               */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define TX_DISABLE_ERROR_CHECKING
#define NX_DISABLE_ERROR_CHECKING
#define NX_DRIVER_SOURCE
#include "nx_driver_zynqmp_gem.h"
#include "nx_driver_zynqmp_gem_regs.h"
#include "nx_ip.h"
#include "tx_zynqmp.h"

void xil_printf( const char *ctrl1, ...);
#if 0
#define DEBUG_LINK
#endif


/* Define the driver commands. */

#define CMD_PHY_ADDR_SET    (NX_LINK_USER_COMMAND + 0)
#define CMD_DMABDS_SET      (NX_LINK_USER_COMMAND + 1)

typedef struct DMABDS_SET_STRUCT
{
     void *     rx_ptr;
     UINT       rx_num;
     void *     tx_ptr;
     UINT       tx_num;
} DMABDS_SET;


/* All DMA structures must be aligned to the data cache line size */

#define DCACHE_ALIGN(a)     ((a) & ~(TX_ZYNQMP_DCACHE_LINE_SIZE-1))


/* MDIO clock divisor */
#define MDIO_CLOCK_DIV      7   /* divide by 224 */


/* PHY polling timer */
#define PHY_TIMER_TICKS     (TX_TIMER_TICKS_PER_SECOND/4)


/* Clock Generator Control configuration */
/* can be redefined in nx_user.h */
#ifndef NX_DRIVER_ZYNQMP_CRL_APB_DIV0_1000

#define NX_DRIVER_ZYNQMP_CRL_APB_DIV0_1000    12
#define NX_DRIVER_ZYNQMP_CRL_APB_DIV1_1000    1
#define NX_DRIVER_ZYNQMP_CRL_APB_DIV0_100     60
#define NX_DRIVER_ZYNQMP_CRL_APB_DIV1_100     1
#define NX_DRIVER_ZYNQMP_CRL_APB_DIV0_10      60
#define NX_DRIVER_ZYNQMP_CRL_APB_DIV1_10      10

#endif

NX_DRIVER_INFORMATION *driver_ptr_list[NX_DRIVER_ZYNQMP_MAX_INSTANCES];

/* Define the DMA buffer descriptors */

typedef struct DMA_BD_STRUCT
{
    volatile uint32_t word0;
    volatile uint32_t word1;
#ifdef __aarch64__
    volatile uint32_t word2;
    volatile uint32_t word3;
#endif
} DMA_BD;


/* DMA buffers descriptors flags */

#define DMA_BD_RX_0_ADDR    0xfffffff8u
#define DMA_BD_RX_0_WRAP    (1u<<1)
#define DMA_BD_RX_0_USED    (1u<<0)
#define DMA_BD_RX_1_END     (1u<<15)
#define DMA_BD_RX_1_START   (1u<<14)
#define DMA_BD_RX_1_LENGTH  0x1fffu

#define DMA_BD_TX_1_USED    (1u<<31)
#define DMA_BD_TX_1_WRAP    (1u<<30)
#define DMA_BD_TX_1_LAST    (1u<<15)
#define DMA_BD_TX_1_LENGTH  0x3fffu


/* Internal functions prototypes */
static void nx_driver_interrupt(NX_DRIVER_INFORMATION *driver_ptr);
static void nx_driver_transfer_to_netx(NX_DRIVER_INFORMATION *driver_ptr, NX_PACKET *packet_ptr);
static void nx_driver_timer_handler(ULONG data);
static void nx_driver_link_up(NX_DRIVER_INFORMATION *driver_ptr);
static void nx_driver_link_down(NX_DRIVER_INFORMATION *driver_ptr);

/* Free packets in TX queue */
static void nx_driver_flush_tx(NX_DRIVER_INFORMATION *driver_ptr)
{
    TX_INTERRUPT_SAVE_AREA
    UINT id, num;

    TX_DISABLE
    /* get current index and number of pending packets */
    id = driver_ptr->nx_driver_information_tx_id;
    num = driver_ptr->nx_driver_information_tx_num;
    /* reset index when tx is stopped */
    driver_ptr->nx_driver_information_tx_id = 0;
    driver_ptr->nx_driver_information_tx_num = 0;
    TX_RESTORE
    while (num != 0)
    {
        /* Remove the Ethernet header and release the packet. */
        NX_DRIVER_ETHERNET_HEADER_REMOVE(driver_ptr->nx_driver_information_tx_bd_packets[id]);

        /* release transmitted buffer */
        nx_packet_transmit_release(driver_ptr->nx_driver_information_tx_bd_packets[id]);

        /* next buffer */
        id++;
        if (id >= driver_ptr->nx_driver_information_tx_bd_num)
        {
            id = 0;
        }
        num--;
    }
}

/* Get the bit index in the 64-bit hash filter corresponding to a multicast Ethernet address, */
/* the 6-bit hash index is computed from the 48-bit ethernet address as follow: */
/* hash_index[05] = da[05]^da[11]^da[17]^da[23]^da[29]^da[35]^da[41]^da[47] */
/* hash_index[04] = da[04]^da[10]^da[16]^da[22]^da[28]^da[34]^da[40]^da[46] */
/* hash_index[03] = da[03]^da[09]^da[15]^da[21]^da[27]^da[33]^da[39]^da[45] */
/* hash_index[02] = da[02]^da[08]^da[14]^da[20]^da[26]^da[32]^da[38]^da[44] */
/* hash_index[01] = da[01]^da[07]^da[13]^da[19]^da[25]^da[31]^da[37]^da[43] */
/* hash_index[00] = da[00]^da[06]^da[12]^da[18]^da[24]^da[30]^da[36]^da[42] */
static UINT nx_driver_get_multicast_hash_index(ULONG msw, ULONG lsw)
{
    UCHAR addr[6];
    UCHAR tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8;

    /* get 6-byte ethernet address */
    addr[0] = (UCHAR) (msw >> 8);
    addr[1] = (UCHAR)  msw;
    addr[2] = (UCHAR) (lsw >> 24);
    addr[3] = (UCHAR) (lsw >> 16);
    addr[4] = (UCHAR) (lsw >> 8);
    addr[5] = (UCHAR)  lsw;

    /* compute hash index */
    tmp1 = addr[0] & 0x3F;
    tmp2 = ((addr[0] >> 6) & 0x03) | ((addr[1] & 0x0F) << 2);
    tmp3 = ((addr[1] >> 4) & 0x0F) | ((addr[2] & 0x03) << 4);
    tmp4 = ((addr[2] >> 2) & 0x3F);
    tmp5 = addr[3] & 0x3F;
    tmp6 = ((addr[3] >> 6) & 0x03) | ((addr[4] & 0x0F) << 2);
    tmp7 = ((addr[4] >> 4) & 0x0F) | ((addr[5] & 0x03) << 4);
    tmp8 = ((addr[5] >> 2) & 0x3F);

    /* return index */
    return tmp1 ^ tmp2 ^ tmp3 ^ tmp4 ^ tmp5 ^ tmp6 ^ tmp7 ^ tmp8;
}

/* Deferred events */
#define EVENT_TIMER     (1U<<0)


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    nx_driver_zynqmp_entry                   Zynq UltraScale+ MPSoC/GNU */
/*                                                           5.0          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Regis Feneon, Express Logic France.                                 */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This is the entry point of the NetX Ethernet Driver. This driver    */
/*    function is responsible for initializing the Ethernet controller,   */
/*    enabling or disabling the controller as need, preparing             */
/*    a packet for transmission, and getting status information.          */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    driver_ptr                            The driver instance           */
/*    driver_req_ptr                        The driver request from the   */
/*                                            IP layer.                   */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    nx_driver_link_up/down                Update link state             */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    IP layer                                                            */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  07-01-2018     Regis Feneon             Initial Version 5.0           */
/*                                                                        */
/**************************************************************************/
void nx_driver_zynqmp_entry(NX_DRIVER_INFORMATION *driver_ptr, NX_IP_DRIVER *driver_req_ptr)
{
    /* Process according to the driver request type in the IP control
       block.  */
    switch (driver_req_ptr->nx_ip_driver_command)
    {

    case NX_LINK_INTERFACE_ATTACH:

        /* Setup the IP instance */
        driver_ptr->nx_driver_information_ip_ptr = driver_req_ptr->nx_ip_driver_ptr;

        /* Set driver state to not initialized */
        driver_ptr->nx_driver_information_state = NX_DRIVER_STATE_NOT_INITIALIZED;

        /* Setup the default packet pool for the driver's received packets.  */
        driver_ptr->nx_driver_information_packet_pool_ptr = driver_req_ptr->nx_ip_driver_ptr->nx_ip_default_packet_pool;

        /* Setup the driver interface. */
        driver_ptr->nx_driver_information_interface = driver_req_ptr->nx_ip_driver_interface;

        /* Reset link status */
        driver_ptr->nx_driver_information_link = NX_DRIVER_LINK_DOWN;

        /* Clear deferred events */
        driver_ptr->nx_driver_information_deferred_events = 0;

        /* Create timer for PHY link status polling */
        tx_timer_create(&driver_ptr->nx_driver_information_timer, "ZynqMP GEM", nx_driver_timer_handler, driver_ptr -> nx_driver_information_id, PHY_TIMER_TICKS, PHY_TIMER_TICKS, TX_NO_ACTIVATE);

        /* Store driver instance pointer in the list so it can be retrieved in the callback.  */
        driver_ptr_list[driver_ptr -> nx_driver_information_id] = driver_ptr;

        /* Return successful status.  */
        driver_req_ptr->nx_ip_driver_status = NX_SUCCESS;

        break;

    case NX_LINK_INITIALIZE:
    {
        int i;
        ULONG hash_bottom, hash_top;

        /* Check that the buffer descriptors have been set. */
        if (driver_ptr->nx_driver_information_rx_bd_num == 0 ||
            driver_ptr->nx_driver_information_tx_bd_num == 0)
        {
            driver_req_ptr->nx_ip_driver_status = NX_DRIVER_ERROR;
            break;
        }

        /* Initialize hardware */

        /* Reset controller */
        driver_ptr->nx_driver_information_gem->network_control = 0;
        driver_ptr->nx_driver_information_gem->int_disable = ~0;
        driver_ptr->nx_driver_information_gem->int_q1_disable = ~0;
        driver_ptr->nx_driver_information_gem->receive_q_ptr = 0;
        driver_ptr->nx_driver_information_gem->receive_q1_ptr = 0;
        driver_ptr->nx_driver_information_gem->transmit_q_ptr = 0;
        driver_ptr->nx_driver_information_gem->transmit_q1_ptr = 0;

        /* Configure the controller */
        driver_ptr->nx_driver_information_gem->network_config =
            GEM_NWCFG_DWIDTH_64                     |
            (MDIO_CLOCK_DIV << GEM_NWCFG_MDC_SHIFT) |
            GEM_NWCFG_FCSREM                        |
            GEM_NWCFG_LENERRDSCRD                   |
            (2 << GEM_NWCFG_RXOFFS_SHIFT)           |   /* align ip header */
            GEM_NWCFG_MCASTHASHEN |
			GEM_NWCFG_RXCHKSUMEN ;
        driver_ptr->nx_driver_information_gem->dma_config =
#ifdef __aarch64__
            GEM_DMACR_ADDR_WIDTH_64       |
#endif
            GEM_DMACR_TXSIZE              |
            GEM_DMACR_RXSIZE              |
            (24 << GEM_DMACR_RXBUF_SHIFT) |    /* rx buf size: 24*64 = 1536 bytes */
            GEM_DMACR_INCR16_AHB_BURST |
			GEM_DMACR_TCPCKSUM;
        driver_ptr->nx_driver_information_gem->network_control =
            GEM_NWCTRL_STATCLR |
            GEM_NWCTRL_MDEN;

        /* set the physical address of the interface */
        driver_ptr->nx_driver_information_gem->spec_add1_bottom =
            ((driver_ptr->nx_driver_information_interface->nx_interface_physical_address_msw & 0xff00) >> 8) |
            ((driver_ptr->nx_driver_information_interface->nx_interface_physical_address_msw & 0x00ff) << 8) |
            ((driver_ptr->nx_driver_information_interface->nx_interface_physical_address_lsw & 0xff000000) >> 8) |
            ((driver_ptr->nx_driver_information_interface->nx_interface_physical_address_lsw & 0x00ff0000) << 8);
        driver_ptr->nx_driver_information_gem->spec_add1_top =
            ((driver_ptr->nx_driver_information_interface->nx_interface_physical_address_lsw & 0x0000ff00) >> 8) |
            ((driver_ptr->nx_driver_information_interface->nx_interface_physical_address_lsw & 0x000000ff) << 8);

        /* disable specific addresses 2-4 */
        driver_ptr->nx_driver_information_gem->spec_add2_bottom = 0;
        driver_ptr->nx_driver_information_gem->spec_add3_bottom = 0;
        driver_ptr->nx_driver_information_gem->spec_add4_bottom = 0;

        /* set multicast filter */
        hash_bottom = 0;
        hash_top = 0;
        for (i=0; i<NX_DRIVER_MULTICAST_FILTER_BITS; i++)
        {
            if (driver_ptr->nx_driver_information_multicast_filter[i] != 0)
            {
                if (i < 32)
                {
                    hash_bottom |= 1U << i;
                }
                else
                {
                    hash_top |= 1U << (i - 32);
                }
            }
        }
        driver_ptr->nx_driver_information_gem->hash_bottom = hash_bottom;
        driver_ptr->nx_driver_information_gem->hash_top    = hash_top;

        /* Prepare the list of rx descriptor */
        for (i=0; i<driver_ptr->nx_driver_information_rx_bd_num; i++)
        {
            NX_PACKET *packet_ptr;

            /* allocate packet for reception */
            if (nx_packet_allocate(driver_ptr->nx_driver_information_packet_pool_ptr, &packet_ptr, NX_RECEIVE_PACKET, NX_NO_WAIT) != NX_SUCCESS)
            {
                /* failed to allocate packet, cannot initialize driver */
                break;
            }
            /* adjust pointer so the IP header is aligned on 32-bit boundary */
            packet_ptr->nx_packet_prepend_ptr += 2;
            /* flush buffer data to ram to avoid further corruption */
            tx_zynqmp_dcache_flush(DCACHE_ALIGN((uintptr_t) packet_ptr->nx_packet_prepend_ptr), (uintptr_t) packet_ptr->nx_packet_data_end);

            /* prepare rx descriptor */
#ifdef __aarch64__
            driver_ptr->nx_driver_information_rx_bd[i].word2 =
                (uint32_t) ((uintptr_t) packet_ptr->nx_packet_prepend_ptr >> 32);
#endif
            if (i == driver_ptr->nx_driver_information_rx_bd_num-1)
            {
                /* set wrap bit on last descriptor */
                driver_ptr->nx_driver_information_rx_bd[i].word0 =
                  (((uint32_t) (uintptr_t) packet_ptr->nx_packet_prepend_ptr) & DMA_BD_RX_0_ADDR) | DMA_BD_RX_0_WRAP;
            }
            else
            {
                driver_ptr->nx_driver_information_rx_bd[i].word0 =
                  ((uint32_t) (uintptr_t) packet_ptr->nx_packet_prepend_ptr) & DMA_BD_RX_0_ADDR;
            }

            /* save pointer to packet */
            driver_ptr->nx_driver_information_rx_bd_packets[i] = packet_ptr;
        }
        if (i != driver_ptr->nx_driver_information_rx_bd_num)
        {
            /* packet allocation failure */
            while (--i > 0)
            {
                /* release previously allocated packets */
                nx_packet_release(driver_ptr->nx_driver_information_rx_bd_packets[i]);
            }
            /* return error code */
            driver_req_ptr->nx_ip_driver_status = NX_DRIVER_ERROR;
            break;
        }

        /* used last descriptor for rx priority queue 1 (disabled) */
        driver_ptr->nx_driver_information_rx_bd[driver_ptr->nx_driver_information_rx_bd_num].word0 = DMA_BD_RX_0_USED | DMA_BD_RX_0_WRAP;

        /* set descriptor table address */
#ifdef __aarch64__
        driver_ptr->nx_driver_information_gem->upper_rx_q_base_addr =
            (uint32_t) (driver_ptr->nx_driver_information_rx_bd_paddr >> 32);
        driver_ptr->nx_driver_information_gem->receive_q_ptr =
            (uint32_t)  driver_ptr->nx_driver_information_rx_bd_paddr;
        driver_ptr->nx_driver_information_gem->receive_q1_ptr =
            (uint32_t)  driver_ptr->nx_driver_information_rx_bd_paddr +
              driver_ptr->nx_driver_information_rx_bd_num * sizeof(DMA_BD);
#else
        driver_ptr->nx_driver_information_gem->receive_q_ptr =
            (uint32_t) (uintptr_t) driver_ptr->nx_driver_information_rx_bd;
        driver_ptr->nx_driver_information_gem->receive_q1_ptr =
            (uint32_t) (uintptr_t) driver_ptr->nx_driver_information_rx_bd +
              driver_ptr->nx_driver_information_rx_bd_num * sizeof(DMA_BD);
#endif

        /* Initialize current rx index */
        driver_ptr->nx_driver_information_rx_id = 0;

        /* Prepare the list of tx descriptor */
        for (i=0; i<driver_ptr->nx_driver_information_tx_bd_num; i++)
        {
            /* prepare tx descriptor */
            if (i == driver_ptr->nx_driver_information_tx_bd_num-1)
            {
                driver_ptr->nx_driver_information_tx_bd[i].word1 =
                    DMA_BD_TX_1_USED|DMA_BD_TX_1_WRAP;
            }
            else
            {
                driver_ptr->nx_driver_information_tx_bd[i].word1 =
                    DMA_BD_TX_1_USED;
            }
            driver_ptr->nx_driver_information_tx_bd_packets[i] = NULL;

        }

        /* used last descriptor for normal tx queue (disabled) */
        driver_ptr->nx_driver_information_tx_bd[driver_ptr->nx_driver_information_tx_bd_num].word1 = DMA_BD_TX_1_USED | DMA_BD_TX_1_WRAP;

        /* set descriptor table address */
#ifdef __aarch64__
        driver_ptr->nx_driver_information_gem->upper_tx_q_base_addr =
            (uint32_t) (driver_ptr->nx_driver_information_tx_bd_paddr >> 32);
        driver_ptr->nx_driver_information_gem->transmit_q1_ptr =
            (uint32_t)  driver_ptr->nx_driver_information_tx_bd_paddr;
        driver_ptr->nx_driver_information_gem->transmit_q_ptr =
            (uint32_t)  driver_ptr->nx_driver_information_tx_bd_paddr +
              driver_ptr->nx_driver_information_tx_bd_num * sizeof(DMA_BD);
#else
        driver_ptr->nx_driver_information_gem->transmit_q1_ptr =
            (uint32_t) (uintptr_t) driver_ptr->nx_driver_information_tx_bd;
        driver_ptr->nx_driver_information_gem->transmit_q_ptr =
            (uint32_t) (uintptr_t) driver_ptr->nx_driver_information_tx_bd +
              driver_ptr->nx_driver_information_tx_bd_num * sizeof(DMA_BD);
#endif

        /* Initialize current tx index and number of buffers */
        driver_ptr->nx_driver_information_tx_id = 0;
        driver_ptr->nx_driver_information_tx_num = 0;

        /* install interrupt handler */
        tx_zynqmp_irq_enable(driver_ptr->nx_driver_information_irq, (void (*)(void *)) nx_driver_interrupt, driver_ptr);

        /* enable rx/tx interrupts */
        driver_ptr->nx_driver_information_gem->int_enable =
            GEM_IXR_FRAMERX|GEM_IXR_RX_ERR/*|GEM_IXR_TXCOMPL|GEM_IXR_TX_ERR*/;
        driver_ptr->nx_driver_information_gem->int_q1_enable =
            GEM_IXR_TXCOMPL|GEM_IXR_TX_ERR;

        /* End of hardware initialization */

        /* Setupt the interface MTU */
        driver_ptr->nx_driver_information_interface->nx_interface_ip_mtu_size = NX_DRIVER_ETHERNET_MTU - NX_DRIVER_ETHERNET_FRAME_SIZE;

        /* Indicate to the IP software that IP to physical mapping
           is required.  */
        driver_ptr->nx_driver_information_interface->nx_interface_address_mapping_needed = NX_TRUE;

        /* Reset statistics counters */
        driver_ptr->nx_driver_information_rx_packets    = 0;
        driver_ptr->nx_driver_information_tx_packets    = 0;
        driver_ptr->nx_driver_information_errors        = 0;
        driver_ptr->nx_driver_information_alloc_errors  = 0;
        driver_ptr->nx_driver_information_drops         = 0;

        /* Move the driver's state to initialized.  */
        driver_ptr->nx_driver_information_state = NX_DRIVER_STATE_INITIALIZED;

        /* Return successful status.  */
        driver_req_ptr->nx_ip_driver_status = NX_SUCCESS;

        break;
    }

    case NX_LINK_ENABLE:

        /* See if we can honor the NX_LINK_ENABLE request.  */
        if (driver_ptr->nx_driver_information_state < NX_DRIVER_STATE_INITIALIZED)
        {
            /* Mark the request as not successful.  */
            driver_req_ptr->nx_ip_driver_status = NX_DRIVER_ERROR;
            break;
        }

        /* Check if it is enabled by someone already */
        if (driver_ptr->nx_driver_information_state >= NX_DRIVER_STATE_LINK_ENABLED)
        {
            /* Yes, the request has already been made.  */
            driver_req_ptr->nx_ip_driver_status = NX_ALREADY_ENABLED;
            break;
        }

        /* Reset PHY */
        if (nx_driver_zynqmp_phy_reset(driver_ptr) != NX_SUCCESS)
        {
            /* failed to initialize PHY */
            driver_req_ptr->nx_ip_driver_status = NX_DRIVER_ERROR;
            break;
        }

        /* activate PHY timer */
        tx_timer_activate(&driver_ptr->nx_driver_information_timer);

        /* Update the driver state to link enabled.  */
        driver_ptr->nx_driver_information_state = NX_DRIVER_STATE_LINK_ENABLED;

        /* Return successful status.  */
        driver_req_ptr->nx_ip_driver_status = NX_SUCCESS;

        /* Mark the IP instance as link up.  */
        driver_ptr->nx_driver_information_interface -> nx_interface_link_up =  NX_TRUE;

        break;

    case NX_LINK_DISABLE:

        /* Check if the link is enabled.  */
        if (driver_ptr->nx_driver_information_state != NX_DRIVER_STATE_LINK_ENABLED)
        {
            /* The link is not enabled, so just return an error.  */
            driver_req_ptr->nx_ip_driver_status = NX_DRIVER_ERROR;
            break;
        }

        /* Update the interface link state. */
        if (driver_ptr->nx_driver_information_link != NX_DRIVER_LINK_DOWN)
        {

            driver_ptr->nx_driver_information_link = NX_DRIVER_LINK_DOWN;

            nx_driver_link_down(driver_ptr);
        }

        /* Mark the IP instance as link down.  */
        driver_ptr->nx_driver_information_interface -> nx_interface_link_up = NX_FALSE;

        /* Stop PHY timer */
        tx_timer_deactivate(&driver_ptr->nx_driver_information_timer);

        /* Update the driver state back to initialized.  */
        driver_ptr->nx_driver_information_state = NX_DRIVER_STATE_INITIALIZED;

        /* Return successful status.  */
        driver_req_ptr->nx_ip_driver_status = NX_SUCCESS;

        break;

    case NX_LINK_UNINITIALIZE:
    {
        int i;

        /* Check if the driver is initialized.  */
        if (driver_ptr->nx_driver_information_state != NX_DRIVER_STATE_INITIALIZED)
        {
            /* The driver is not initialized, so just return an error.  */
            driver_req_ptr->nx_ip_driver_status = NX_DRIVER_ERROR;
            break;
        }

        /* disable interrupts and remove handler */
        tx_zynqmp_irq_disable(driver_ptr->nx_driver_information_irq);

        /* Free all RX packets */
        for (i=0; i<driver_ptr->nx_driver_information_rx_bd_num; i++)
        {
            nx_packet_release(driver_ptr->nx_driver_information_rx_bd_packets[i]);
        }

        /* Free pending TX packets */
        nx_driver_flush_tx(driver_ptr);

        /* Move the driver's state to not initialized.  */
        driver_ptr->nx_driver_information_state = NX_DRIVER_STATE_NOT_INITIALIZED;

        /* Return successful status.  */
        driver_req_ptr->nx_ip_driver_status = NX_SUCCESS;

        break;
    }

    case NX_LINK_INTERFACE_DETACH:

        /* Delete timer */
        tx_timer_delete(&driver_ptr->nx_driver_information_timer);

        /* Return successful status.  */
        driver_req_ptr->nx_ip_driver_status = NX_SUCCESS;

        break;

    case NX_LINK_ARP_SEND:
    case NX_LINK_ARP_RESPONSE_SEND:
    case NX_LINK_PACKET_BROADCAST:
    case NX_LINK_RARP_SEND:
    case NX_LINK_PACKET_SEND:
    {
        NX_PACKET *packet_ptr;
        ULONG *ethernet_frame_ptr;
        UINT num;
        TX_INTERRUPT_SAVE_AREA


        /* Transmit packet */
        packet_ptr =  driver_req_ptr -> nx_ip_driver_packet;

        /* Check to make sure the link is up and the packet length is valid.  */
        if (driver_ptr->nx_driver_information_link == NX_DRIVER_LINK_DOWN || packet_ptr->nx_packet_length > (NX_DRIVER_ETHERNET_MTU - NX_DRIVER_ETHERNET_FRAME_SIZE))
        {
            /* Indicate an unsuccessful packet send.  */
            driver_req_ptr -> nx_ip_driver_status = NX_DRIVER_ERROR;

            /* Free the packet.  */
            nx_packet_transmit_release(driver_req_ptr->nx_ip_driver_packet);
            break;
        }

        /* Adjust the prepend pointer.  */
        packet_ptr -> nx_packet_prepend_ptr =
                packet_ptr -> nx_packet_prepend_ptr - NX_DRIVER_ETHERNET_FRAME_SIZE;

        /* Adjust the packet length.  */
        packet_ptr -> nx_packet_length = packet_ptr -> nx_packet_length + NX_DRIVER_ETHERNET_FRAME_SIZE;

        /* Setup the ethernet frame pointer to build the ethernet frame.  Backup another 2
          * bytes to get 32-bit word alignment.  */
        ethernet_frame_ptr =  (ULONG *) (packet_ptr -> nx_packet_prepend_ptr - 2);

        /* Set up the hardware addresses in the Ethernet header. */
        *ethernet_frame_ptr       =  driver_req_ptr -> nx_ip_driver_physical_address_msw;
        *(ethernet_frame_ptr + 1) =  driver_req_ptr -> nx_ip_driver_physical_address_lsw;

        *(ethernet_frame_ptr + 2) =  (driver_ptr->nx_driver_information_ip_ptr -> nx_ip_arp_physical_address_msw << 16) |
            (driver_ptr->nx_driver_information_ip_ptr -> nx_ip_arp_physical_address_lsw >> 16);
        *(ethernet_frame_ptr + 3) =  (driver_ptr->nx_driver_information_ip_ptr -> nx_ip_arp_physical_address_lsw << 16);

        /* Set up the frame type field in the Ethernet harder. */
        if ((driver_req_ptr -> nx_ip_driver_command == NX_LINK_ARP_SEND)||
            (driver_req_ptr -> nx_ip_driver_command == NX_LINK_ARP_RESPONSE_SEND))
        {

            *(ethernet_frame_ptr + 3) |= NX_DRIVER_ETHERNET_ARP;
        }
        else if(driver_req_ptr -> nx_ip_driver_command == NX_LINK_RARP_SEND)
        {

            *(ethernet_frame_ptr + 3) |= NX_DRIVER_ETHERNET_RARP;
        }

#ifdef FEATURE_NX_IPV6
        else if(packet_ptr -> nx_packet_ip_version == NX_IP_VERSION_V6)
        {

            *(ethernet_frame_ptr + 3) |= NX_DRIVER_ETHERNET_IPV6;
        }
#endif /* FEATURE_NX_IPV6 */

        else
        {

            *(ethernet_frame_ptr + 3) |= NX_DRIVER_ETHERNET_IP;
        }

        /* Endian swapping if NX_LITTLE_ENDIAN is defined.  */
        NX_CHANGE_ULONG_ENDIAN(*(ethernet_frame_ptr));
        NX_CHANGE_ULONG_ENDIAN(*(ethernet_frame_ptr + 1));
        NX_CHANGE_ULONG_ENDIAN(*(ethernet_frame_ptr + 2));
        NX_CHANGE_ULONG_ENDIAN(*(ethernet_frame_ptr + 3));

        /* Flush packet data */
        tx_zynqmp_dcache_flush(DCACHE_ALIGN((uintptr_t) packet_ptr->nx_packet_prepend_ptr), (uintptr_t) packet_ptr->nx_packet_prepend_ptr + packet_ptr->nx_packet_length);

        /* disable interrupts while we manipulates the tx descriptors list information */
        TX_DISABLE

        /* add packet buffer to the tx list */
        num = driver_ptr->nx_driver_information_tx_num;
        if (num < driver_ptr->nx_driver_information_tx_bd_num)
        {
            UINT id;

            /* id of next tx descriptor */
            id = driver_ptr->nx_driver_information_tx_id + num;
            /* modulo number of descriptors */
            if (id >= driver_ptr->nx_driver_information_tx_bd_num)
            {
                id -= driver_ptr->nx_driver_information_tx_bd_num;
            }

            /* update number of pending tx buffers */
            driver_ptr->nx_driver_information_tx_num = num + 1;

            /* prepare descriptor for transmission */
#ifdef __aarch64__
            driver_ptr->nx_driver_information_tx_bd[id].word2 =
              (uint32_t) ((uintptr_t) packet_ptr->nx_packet_prepend_ptr >> 32);
#endif
            driver_ptr->nx_driver_information_tx_bd[id].word0 =
              (uint32_t) (uintptr_t) packet_ptr->nx_packet_prepend_ptr;
            if (id == driver_ptr->nx_driver_information_tx_bd_num-1)
            {
                driver_ptr->nx_driver_information_tx_bd[id].word1 =
                  (uint32_t) packet_ptr->nx_packet_length | DMA_BD_TX_1_LAST|DMA_BD_TX_1_WRAP;
            }
            else
            {
                driver_ptr->nx_driver_information_tx_bd[id].word1 =
                  (uint32_t) packet_ptr->nx_packet_length | DMA_BD_TX_1_LAST;
            }

            /* save pointer to packet */
            driver_ptr->nx_driver_information_tx_bd_packets[id] = packet_ptr;

            TX_RESTORE

            /* start tx */
            driver_ptr->nx_driver_information_gem->network_control |= GEM_NWCTRL_STARTTX;

            /* Set the status of the request.  */
            driver_req_ptr -> nx_ip_driver_status = NX_SUCCESS;
        }
        else
        {
            /* tx list is full, cannot send the packet */
            driver_ptr->nx_driver_information_drops++;

            TX_RESTORE

            /* Remove the Ethernet header.  */
            NX_DRIVER_ETHERNET_HEADER_REMOVE(packet_ptr);

            /* Indicate an unsuccessful packet send.  */
            driver_req_ptr -> nx_ip_driver_status =  NX_DRIVER_ERROR;

            /* Free the packet.  */
            nx_packet_transmit_release(packet_ptr);
        }

        break;
    }

    case NX_LINK_MULTICAST_JOIN:
    {
        UINT index;

        /* Process multicast join requests.  */

        /* get hash index */
        index = nx_driver_get_multicast_hash_index(driver_req_ptr->nx_ip_driver_physical_address_msw, driver_req_ptr->nx_ip_driver_physical_address_lsw);

        /* increment reference counter */
        driver_ptr->nx_driver_information_multicast_filter[index]++;

        /* update multicast filter */
        if (driver_ptr->nx_driver_information_state >= NX_DRIVER_STATE_INITIALIZED &&
            driver_ptr->nx_driver_information_multicast_filter[index] == 1)
        {
            /* set corresponding bit */
            if (index < 32)
            {
                driver_ptr->nx_driver_information_gem->hash_bottom |= 1U << index;
            }
            else
            {
                driver_ptr->nx_driver_information_gem->hash_top |= 1U << (index - 32);
            }
        }

        /* Return successful status.  */
        driver_req_ptr->nx_ip_driver_status = NX_SUCCESS;

        break;
    }

    case NX_LINK_MULTICAST_LEAVE:
    {
        UINT index;

        /* Process multicast leave requests.  */

        /* get hash index */
        index = nx_driver_get_multicast_hash_index(driver_req_ptr->nx_ip_driver_physical_address_msw, driver_req_ptr->nx_ip_driver_physical_address_lsw);

        /* decrement reference counter */
        driver_ptr->nx_driver_information_multicast_filter[index]--;

        /* update multicast filter */
        if (driver_ptr->nx_driver_information_state >= NX_DRIVER_STATE_INITIALIZED &&
            driver_ptr->nx_driver_information_multicast_filter[index] == 0)
        {
            /* clear corresponding bit */
            if (index < 32)
            {
                driver_ptr->nx_driver_information_gem->hash_bottom &= ~(1U << index);
            }
            else
            {
                driver_ptr->nx_driver_information_gem->hash_top &= ~(1U << (index - 32));
            }
        }

        /* Return successful status.  */
        driver_req_ptr->nx_ip_driver_status = NX_SUCCESS;

        break;
    }

    case NX_LINK_GET_STATUS:
    {
        /* Return current link status.  */
        *(driver_req_ptr -> nx_ip_driver_return_ptr) = driver_ptr -> nx_driver_information_link != NX_DRIVER_LINK_DOWN ? NX_TRUE : NX_FALSE;

        /* Return successful status.  */
        driver_req_ptr->nx_ip_driver_status = NX_SUCCESS;

        break;
    }

    case NX_LINK_DEFERRED_PROCESSING:
    {
        TX_INTERRUPT_SAVE_AREA
        ULONG events;

        /* get and clear deferred events */
        TX_DISABLE
        events = driver_ptr->nx_driver_information_deferred_events;
        driver_ptr->nx_driver_information_deferred_events = 0;
        TX_RESTORE

        if (events & EVENT_TIMER)
        {
            UINT link;
            link = nx_driver_zynqmp_phy_status(driver_ptr);
            if (driver_ptr->nx_driver_information_link != link)
            {
                if (driver_ptr->nx_driver_information_link == NX_DRIVER_LINK_DOWN)
                {
                    /* link is up */
                    driver_ptr->nx_driver_information_link = link;

                    nx_driver_link_up(driver_ptr);

                }
                else
                {
                    /* link is down */
                    driver_ptr->nx_driver_information_link = NX_DRIVER_LINK_DOWN;

                    nx_driver_link_down(driver_ptr);
                }
            }
        }

        break;
    }

    /*
     * Driver Configuration, must be set before driver is initialized
     */

    case NX_LINK_SET_PHYSICAL_ADDRESS:

        if (driver_ptr->nx_driver_information_state >= NX_DRIVER_STATE_INITIALIZED)
        {
            driver_req_ptr -> nx_ip_driver_status =  NX_DRIVER_ERROR;

            break;
        }

        /* Return successful status.  */
        driver_req_ptr->nx_ip_driver_status = NX_SUCCESS;

        break;

    case CMD_PHY_ADDR_SET:

        if (driver_ptr->nx_driver_information_state >= NX_DRIVER_STATE_INITIALIZED)
        {
            driver_req_ptr -> nx_ip_driver_status =  NX_DRIVER_ERROR;

            break;
        }

        /* Set PHY address */
        driver_ptr->nx_driver_information_phy_addr = (USHORT) *((UINT *) driver_req_ptr->nx_ip_driver_return_ptr);

        /* Return successful status.  */
        driver_req_ptr->nx_ip_driver_status = NX_SUCCESS;

        break;

    case CMD_DMABDS_SET:

        if (driver_ptr->nx_driver_information_state >= NX_DRIVER_STATE_INITIALIZED)
        {
            /* driver must not be running */
            driver_req_ptr -> nx_ip_driver_status =  NX_DRIVER_ERROR;

            break;
        }
        if (((DMABDS_SET *) driver_req_ptr->nx_ip_driver_return_ptr)->rx_num < 2 ||
            ((DMABDS_SET *) driver_req_ptr->nx_ip_driver_return_ptr)->tx_num < 2)
        {
            /* need at least 2 descriptors */
            driver_req_ptr -> nx_ip_driver_status =  NX_DRIVER_ERROR;

            break;
        }

        /* Set buffer descriptors address */
#ifdef __aarch64__
        driver_ptr->nx_driver_information_rx_bd_paddr = (uintptr_t) ((DMABDS_SET *) driver_req_ptr->nx_ip_driver_return_ptr)->rx_ptr;
        driver_ptr->nx_driver_information_rx_bd       = tx_zynqmp_map_nocache(driver_ptr->nx_driver_information_rx_bd_paddr, 0);
        driver_ptr->nx_driver_information_tx_bd_paddr = (uintptr_t) ((DMABDS_SET *) driver_req_ptr->nx_ip_driver_return_ptr)->tx_ptr;
        driver_ptr->nx_driver_information_tx_bd       = tx_zynqmp_map_nocache(driver_ptr->nx_driver_information_tx_bd_paddr, 0);
#else
        driver_ptr->nx_driver_information_rx_bd       = ((DMABDS_SET *) driver_req_ptr->nx_ip_driver_return_ptr)->rx_ptr;
        driver_ptr->nx_driver_information_tx_bd       = ((DMABDS_SET *) driver_req_ptr->nx_ip_driver_return_ptr)->tx_ptr;
#endif

        /* Set number of descriptors, the last one is reserved for the priority queue */
        if (((DMABDS_SET *) driver_req_ptr->nx_ip_driver_return_ptr)->rx_num > NX_DRIVER_ZYNQMP_GEM_DMABD_RX_MAX)
        {
            driver_ptr->nx_driver_information_rx_bd_num = NX_DRIVER_ZYNQMP_GEM_DMABD_RX_MAX - 1;
        }
        else
        {
            driver_ptr->nx_driver_information_rx_bd_num = ((DMABDS_SET *) driver_req_ptr->nx_ip_driver_return_ptr)->rx_num - 1;
        }
        if (((DMABDS_SET *) driver_req_ptr->nx_ip_driver_return_ptr)->tx_num > NX_DRIVER_ZYNQMP_GEM_DMABD_TX_MAX)
        {
            driver_ptr->nx_driver_information_tx_bd_num = NX_DRIVER_ZYNQMP_GEM_DMABD_TX_MAX - 1;
        }
        else
        {
            driver_ptr->nx_driver_information_tx_bd_num = ((DMABDS_SET *) driver_req_ptr->nx_ip_driver_return_ptr)->tx_num - 1;
        }

        /* Return successful status.  */
        driver_req_ptr->nx_ip_driver_status = NX_SUCCESS;

        break;

    default:

        /* Return the unhandled command status.  */
        driver_req_ptr -> nx_ip_driver_status =  NX_UNHANDLED_COMMAND;

        break;
    }
}


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    nx_driver_interrupt                      Zynq UltraScale+ MPSoC/GNU */
/*                                                           5.0          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Regis Feneon, Express Logic France.                                 */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function handles the Ethernet controller interrupts            */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    driver_ptr                            The driver instance           */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    nx_driver_transfer_to_netx            Transfer packet to NetX       */
/*    nx_packet_allocate                    Allocate receive packets      */
/*    nx_packet_release                     Release receive packets       */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Ethernet controller ISR                                             */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  07-01-2018     Regis Feneon             Initial Version 5.0           */
/*                                                                        */
/**************************************************************************/
static void nx_driver_interrupt(NX_DRIVER_INFORMATION *driver_ptr)
{
    while (1) {
        uint32_t istatus, q1_istatus;

        /* get and clear active interrupts */
        istatus = driver_ptr->nx_driver_information_gem->int_status;
        driver_ptr->nx_driver_information_gem->int_status = istatus;
        q1_istatus = driver_ptr->nx_driver_information_gem->int_q1_status;
        driver_ptr->nx_driver_information_gem->int_q1_status = q1_istatus;
        if (istatus == 0 && q1_istatus == 0)
        {
            break;
        }

        /*
         * RX/TX Errors
         */
        if (istatus & (GEM_IXR_RX_ERR|GEM_IXR_TX_ERR))
        {
            /* report errors */
            driver_ptr->nx_driver_information_errors++;
        }

        /*
         * RX interrupt
         */
        if (istatus & GEM_IXR_FRAMERX)
        {
            UINT id;

            /* get received buffers */
            id = driver_ptr->nx_driver_information_rx_id;
            while (1)
            {
                NX_PACKET *packet_ptr;
                uint32_t status;

                /* check if buffer has been written */
                if (!(driver_ptr->nx_driver_information_rx_bd[id].word0 & DMA_BD_RX_0_USED))
                {
                    /* buffer still owned by dma, stop here */
                    break;
                }

                /* if buffer is valid, allocate new packet to replace the received one */
                status = driver_ptr->nx_driver_information_rx_bd[id].word1;
                if ((status & (DMA_BD_RX_1_START|DMA_BD_RX_1_END)) != (DMA_BD_RX_1_START|DMA_BD_RX_1_END))
                {
                    /* invalid packet */
                    driver_ptr->nx_driver_information_errors++;

                    packet_ptr = driver_ptr->nx_driver_information_rx_bd_packets[id];
                }
                else if (nx_packet_allocate(driver_ptr->nx_driver_information_packet_pool_ptr, &packet_ptr, NX_RECEIVE_PACKET, NX_NO_WAIT) != NX_SUCCESS)
                {
                    /* failed to allocate new packet */
                    driver_ptr->nx_driver_information_alloc_errors++;

                    packet_ptr = driver_ptr->nx_driver_information_rx_bd_packets[id];
                }
                else
                {
                    NX_PACKET *rx_packet_ptr;

                    /* adjust pointer so the IP header is aligned on 32-bit boundary */
                    packet_ptr->nx_packet_prepend_ptr += 2;
                    /* flush buffer data to ram to avoid further corruption */
                    tx_zynqmp_dcache_flush(DCACHE_ALIGN((uintptr_t) packet_ptr->nx_packet_prepend_ptr), (uintptr_t) packet_ptr->nx_packet_data_end);

                    /* get the rx packet */
                    rx_packet_ptr = driver_ptr->nx_driver_information_rx_bd_packets[id];
                    /* assign the new one to the descriptor */
                    driver_ptr->nx_driver_information_rx_bd_packets[id] = packet_ptr;

                    /* set length of buffer */
                    rx_packet_ptr->nx_packet_length = status & DMA_BD_RX_1_LENGTH;
                    rx_packet_ptr->nx_packet_append_ptr = rx_packet_ptr->nx_packet_prepend_ptr + rx_packet_ptr->nx_packet_length;
                    /* invalidate buffer data written by dma */
                    tx_zynqmp_dcache_invalidate(DCACHE_ALIGN((uintptr_t) rx_packet_ptr->nx_packet_prepend_ptr), (uintptr_t) rx_packet_ptr->nx_packet_append_ptr);

                    /* pass rx buffer to netx for processing */
                    nx_driver_transfer_to_netx(driver_ptr, rx_packet_ptr);

                    /* increment number of received packets */
                    driver_ptr->nx_driver_information_rx_packets++;
                }

                /* update descriptor with new buffer information */
#ifdef __aarch64__
                driver_ptr->nx_driver_information_rx_bd[id].word2 =
                    (uint32_t) ((uintptr_t) packet_ptr->nx_packet_prepend_ptr >> 32);
#endif
                if (id == driver_ptr->nx_driver_information_rx_bd_num-1)
                {
                    /* set wrap bit on last descriptor */
                    driver_ptr->nx_driver_information_rx_bd[id].word0 =
                      (((uint32_t) (uintptr_t) packet_ptr->nx_packet_prepend_ptr) & DMA_BD_RX_0_ADDR) | DMA_BD_RX_0_WRAP;

                    /* back to first descriptor */
                    id = 0;
                }
                else
                {
                    driver_ptr->nx_driver_information_rx_bd[id].word0 =
                      ((uint32_t) (uintptr_t) packet_ptr->nx_packet_prepend_ptr) & DMA_BD_RX_0_ADDR;
                    /* get next descriptor */
                    id++;
                }
            }
            /* save updated index */
            driver_ptr->nx_driver_information_rx_id = id;
        }

        /*
         * TX interrupt
         */
        if (q1_istatus & GEM_IXR_TXCOMPL)
        {
            UINT id, num;
#ifdef TX_THREAD_SMP_MAX_CORES
            TX_INTERRUPT_SAVE_AREA

            TX_DISABLE
#endif
            /* get transmitted buffers */
            id = driver_ptr->nx_driver_information_tx_id;
            num = driver_ptr->nx_driver_information_tx_num;
            while (num != 0)
            {
                uint32_t status;

                /* get buffer status */
                status = driver_ptr->nx_driver_information_tx_bd[id].word1;
                if (!(status & DMA_BD_TX_1_USED))
                {
                    /* buffer not yet transmitted, stop here */
                    break;
                }

                /* Remove the Ethernet header and release the packet.  */
                NX_DRIVER_ETHERNET_HEADER_REMOVE(driver_ptr->nx_driver_information_tx_bd_packets[id]);

                /* release transmitted buffer */
                nx_packet_transmit_release(driver_ptr->nx_driver_information_tx_bd_packets[id]);

                /* clear packet pointer */
                driver_ptr->nx_driver_information_tx_bd_packets[id] = NULL;

                /* increment number of transmitted packets */
                driver_ptr->nx_driver_information_tx_packets++;

                /* next buffer */
                id++;
                if (id >= driver_ptr->nx_driver_information_tx_bd_num)
                {
                    id = 0;
                }
                num--;
            }
            /* save updated index */
            driver_ptr->nx_driver_information_tx_id = id;
            driver_ptr->nx_driver_information_tx_num = num;

#ifdef TX_THREAD_SMP_MAX_CORES
            TX_RESTORE
#endif
        }

    } /* while (int_status) */

}


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    nx_driver_transfer_to_netx               Zynq UltraScale+ MPSoC/GNU */
/*                                                           5.0          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function processing incoming packets.  This routine would      */
/*    be called from the driver-specific receive packet processing        */
/*    function _nx_driver_hardware.                                       */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    driver_ptr                            Pointer to driver             */
/*    packet_ptr                            Packet pointer                */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    Error indication                                                    */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _nx_ip_packet_deferred_receive        NetX IP packet receive        */
/*    _nx_arp_packet_deferred_receive       NetX ARP packet receive       */
/*    _nx_rarp_packet_deferred_receive      NetX RARP packet receive      */
/*    _nx_packet_release                    Release packet                */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    nx_driver_interrupt                   Driver interrupt handler      */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  07-01-2018     Yuxin Zhou               Initial Version 5.0           */
/*                                                                        */
/**************************************************************************/
static void nx_driver_transfer_to_netx(NX_DRIVER_INFORMATION *driver_ptr, NX_PACKET *packet_ptr)
{
NX_IP *   ip_ptr = driver_ptr->nx_driver_information_ip_ptr;
USHORT    packet_type;


    /* Set the interface for the incoming packet.  */
    packet_ptr -> nx_packet_ip_interface = driver_ptr->nx_driver_information_interface;

    /* Pickup the packet header to determine where the packet needs to be
       sent.  */
    packet_type =  (USHORT)(((UINT) (*(packet_ptr -> nx_packet_prepend_ptr+12))) << 8) |
        ((UINT) (*(packet_ptr -> nx_packet_prepend_ptr+13)));

    /* Route the incoming packet according to its ethernet type.  */
    if (packet_type == NX_DRIVER_ETHERNET_IP || packet_type == NX_DRIVER_ETHERNET_IPV6)
    {
        /* Note:  The length reported by some Ethernet hardware includes
           bytes after the packet as well as the Ethernet header.  In some
           cases, the actual packet length after the Ethernet header should
           be derived from the length in the IP header (lower 16 bits of
           the first 32-bit word).  */

        /* Clean off the Ethernet header.  */
        packet_ptr -> nx_packet_prepend_ptr =
            packet_ptr -> nx_packet_prepend_ptr + NX_DRIVER_ETHERNET_FRAME_SIZE;

        /* Adjust the packet length.  */
        packet_ptr -> nx_packet_length =
            packet_ptr -> nx_packet_length - NX_DRIVER_ETHERNET_FRAME_SIZE;

        /* Route to the IP receive function.  */
        _nx_ip_packet_deferred_receive(ip_ptr, packet_ptr);
    }
    else if (packet_type == NX_DRIVER_ETHERNET_ARP)
    {

        /* Clean off the Ethernet header.  */
        packet_ptr -> nx_packet_prepend_ptr =
            packet_ptr -> nx_packet_prepend_ptr + NX_DRIVER_ETHERNET_FRAME_SIZE;

        /* Adjust the packet length.  */
        packet_ptr -> nx_packet_length =
            packet_ptr -> nx_packet_length - NX_DRIVER_ETHERNET_FRAME_SIZE;

        /* Route to the ARP receive function.  */
        _nx_arp_packet_deferred_receive(ip_ptr, packet_ptr);
    }
    else if (packet_type == NX_DRIVER_ETHERNET_RARP)
    {

        /* Clean off the Ethernet header.  */
        packet_ptr -> nx_packet_prepend_ptr =
            packet_ptr -> nx_packet_prepend_ptr + NX_DRIVER_ETHERNET_FRAME_SIZE;

        /* Adjust the packet length.  */
        packet_ptr -> nx_packet_length =
            packet_ptr -> nx_packet_length - NX_DRIVER_ETHERNET_FRAME_SIZE;

        /* Route to the RARP receive function.  */
        _nx_rarp_packet_deferred_receive(ip_ptr, packet_ptr);
    }
    else
    {
        /* Invalid ethernet header... release the packet.  */
        nx_packet_release(packet_ptr);
    }
}


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    nx_driver_timer_handler                  Zynq UltraScale+ MPSoC/GNU */
/*                                                           5.0          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Regis Feneon, Express Logic France.                                 */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function handles the PHY status check timer                    */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    data                                  The driver instance           */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _nx_ip_driver_deferred_processing     Schedule deferred processing  */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    ThreadX Timer                                                       */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  07-01-2018     Regis Feneon             Initial Version 5.0           */
/*                                                                        */
/**************************************************************************/
static void nx_driver_timer_handler(ULONG data)
{

	NX_DRIVER_INFORMATION * driver_ptr = driver_ptr_list[data];
    TX_INTERRUPT_SAVE_AREA

    /* set timer event flag */
    TX_DISABLE
    driver_ptr->nx_driver_information_deferred_events |= EVENT_TIMER;
    TX_RESTORE

    /* wake up IP helper thread */
    _nx_ip_driver_deferred_processing(driver_ptr->nx_driver_information_ip_ptr);
}


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    nx_driver_link_up                        Zynq UltraScale+ MPSoC/GNU */
/*                                                           5.0          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Regis Feneon, Express Logic France.                                 */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function enables rx/tx when the link goes up                   */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    driver_ptr                            The driver instance           */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    nx_driver_entry                       Driver entry point            */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  07-01-2018     Regis Feneon             Initial Version 5.0           */
/*                                                                        */
/**************************************************************************/
static void nx_driver_link_up(NX_DRIVER_INFORMATION *driver_ptr)
{
    uint32_t conf, crl_apb;
    UINT speed;

    /* update network configuration register */
    conf = driver_ptr->nx_driver_information_gem->network_config;
    conf &= ~(GEM_NWCFG_1000|GEM_NWCFG_100|GEM_NWCFG_FDEN);

    /* update clock generator control */
    crl_apb = *driver_ptr->nx_driver_information_crl_apb;
    crl_apb &= ~(CRL_APB_GEM_DIV0|CRL_APB_GEM_DIV1);

    /* select speed */
    speed = driver_ptr->nx_driver_information_link & NX_DRIVER_LINK_SPEED_MASK;
    if (speed == NX_DRIVER_LINK_SPEED_1000)
    {
        conf |= GEM_NWCFG_1000;
        crl_apb |= (NX_DRIVER_ZYNQMP_CRL_APB_DIV0_1000 << CRL_APB_GEM_DIV0_SHIFT) |
                   (NX_DRIVER_ZYNQMP_CRL_APB_DIV1_1000 << CRL_APB_GEM_DIV1_SHIFT);
    }
    else if (speed == NX_DRIVER_LINK_SPEED_100)
    {
        conf |= GEM_NWCFG_100;
        crl_apb |= (NX_DRIVER_ZYNQMP_CRL_APB_DIV0_100 << CRL_APB_GEM_DIV0_SHIFT) |
                   (NX_DRIVER_ZYNQMP_CRL_APB_DIV1_100 << CRL_APB_GEM_DIV1_SHIFT);
    }
    else /* default = 10Mbps */
    {
        crl_apb |= (NX_DRIVER_ZYNQMP_CRL_APB_DIV0_10 << CRL_APB_GEM_DIV0_SHIFT) |
                   (NX_DRIVER_ZYNQMP_CRL_APB_DIV1_10 << CRL_APB_GEM_DIV1_SHIFT);
    }

    /* select duplex mode */
    if (driver_ptr->nx_driver_information_link & NX_DRIVER_LINK_FULLDUPLEX)
    {
        conf |= GEM_NWCFG_FDEN;
    }

#ifdef DEBUG_LINK
    {
      const char *s;
      if (speed == NX_DRIVER_LINK_SPEED_1000)     s = "1000";
      else if (speed == NX_DRIVER_LINK_SPEED_100) s = "100";
      else                                        s = "10";
      xil_printf("GEM%d: link up %s-%cD\r\n", driver_ptr->nx_driver_information_id, s,
        driver_ptr->nx_driver_information_link & NX_DRIVER_LINK_FULLDUPLEX ? 'F' : 'H');
    }
#endif

    /* set network configuration */
    driver_ptr->nx_driver_information_gem->network_config = conf;

    /* configure clock */
    *driver_ptr->nx_driver_information_crl_apb = crl_apb;

    /* enable rx/tx */
    driver_ptr->nx_driver_information_gem->network_control |= GEM_NWCTRL_RXEN|GEM_NWCTRL_TXEN;

    /* Mark link status changed. */
    driver_ptr->nx_driver_information_interface -> nx_interface_link_status_change = NX_TRUE;

    /* Wakeup IP helper thread to process the link status event.  */
    tx_event_flags_set(&(driver_ptr->nx_driver_information_ip_ptr -> nx_ip_events), NX_IP_LINK_STATUS_EVENT, TX_OR);
}


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    nx_driver_link_down                      Zynq UltraScale+ MPSoC/GNU */
/*                                                           5.0          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Regis Feneon, Express Logic France.                                 */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function disables rx/tx when the link goes down                */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    driver_ptr                            The driver instance           */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    nx_driver_entry                       Driver entry point            */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  07-01-2018     Regis Feneon             Initial Version 5.0           */
/*                                                                        */
/**************************************************************************/
static void nx_driver_link_down(NX_DRIVER_INFORMATION *driver_ptr)
{
    /* stop rx/tx */
    driver_ptr->nx_driver_information_gem->network_control &= ~(GEM_NWCTRL_RXEN|GEM_NWCTRL_TXEN);

    /* flush tx queue */
    nx_driver_flush_tx(driver_ptr);

#ifdef DEBUG_LINK
    xil_printf("GEM%d: link down\r\n", driver_ptr->nx_driver_information_id);
#endif

    /* Mark link status changed. */
    driver_ptr->nx_driver_information_interface -> nx_interface_link_status_change = NX_TRUE;

    /* Wakeup IP helper thread to process the link status event.  */
    tx_event_flags_set(&(driver_ptr->nx_driver_information_ip_ptr -> nx_ip_events), NX_IP_LINK_STATUS_EVENT, TX_OR);
}


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    nx_driver_zynqmp_mii_read                Zynq UltraScale+ MPSoC/GNU */
/*                                                           5.0          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Regis Feneon, Express Logic France.                                 */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function reads a PHY register                                  */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    driver_ptr                            The driver instance           */
/*    addr                                  The PHY address               */
/*    reg                                   The register to read          */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    The register value                                                  */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    PHY driver                                                          */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  07-01-2018     Regis Feneon             Initial Version 5.0           */
/*                                                                        */
/**************************************************************************/
UINT nx_driver_zynqmp_mii_read(NX_DRIVER_INFORMATION *driver_ptr, UINT addr, UINT reg)
{
    /* wait for idle state */
    while (!(driver_ptr->nx_driver_information_gem->network_status & GEM_NWSR_MDIOIDLE)) {}

    /* send read command */
    driver_ptr->nx_driver_information_gem->phy_management =
        GEM_PHYMNTNC_OP | GEM_PHYMNTNC_OP_R |
        (addr << GEM_PHYMNTNC_PHAD_SHIFT)   |
        (reg << GEM_PHYMNTNC_PREG_SHIFT);

    /* wait for completion */
    while (!(driver_ptr->nx_driver_information_gem->network_status & GEM_NWSR_MDIOIDLE)) {}

    /* return read value */
    return driver_ptr->nx_driver_information_gem->phy_management & GEM_PHYMNTNC_DATA;
}


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    nx_driver_zynqmp_mii_write               Zynq UltraScale+ MPSoC/GNU */
/*                                                           5.0          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Regis Feneon, Express Logic France.                                 */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function writes to a PHY register                              */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    driver_ptr                            The driver instance           */
/*    addr                                  The PHY address               */
/*    reg                                   The register to write         */
/*    value                                 The value to write            */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    PHY driver                                                          */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  07-01-2018     Regis Feneon             Initial Version 5.0           */
/*                                                                        */
/**************************************************************************/
VOID nx_driver_zynqmp_mii_write(NX_DRIVER_INFORMATION *driver_ptr, UINT addr, UINT reg, UINT value)
{
    /* wait for idle state */
    while (!(driver_ptr->nx_driver_information_gem->network_status & GEM_NWSR_MDIOIDLE)) {}

    /* send write command */
    driver_ptr->nx_driver_information_gem->phy_management =
        GEM_PHYMNTNC_OP | GEM_PHYMNTNC_OP_W |
        (addr << GEM_PHYMNTNC_PHAD_SHIFT)   |
        (reg << GEM_PHYMNTNC_PREG_SHIFT)    |
        (value & GEM_PHYMNTNC_DATA);
}


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    nx_driver_zynqmp_mii_read_async          Zynq UltraScale+ MPSoC/GNU */
/*                                                           5.0          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Regis Feneon, Express Logic France.                                 */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function reads a PHY register asynchronously                   */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    driver_ptr                            The driver instance           */
/*    addr                                  The PHY address               */
/*    reg                                   The register to read          */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    PHY driver                                                          */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  07-01-2018     Regis Feneon             Initial Version 5.0           */
/*                                                                        */
/**************************************************************************/
VOID nx_driver_zynqmp_mii_read_async(NX_DRIVER_INFORMATION *driver_ptr, UINT addr, UINT reg)
{
    /* wait for idle state */
    while (!(driver_ptr->nx_driver_information_gem->network_status & GEM_NWSR_MDIOIDLE)) {}

    /* send read command */
    driver_ptr->nx_driver_information_gem->phy_management =
        GEM_PHYMNTNC_OP | GEM_PHYMNTNC_OP_R |
        (addr << GEM_PHYMNTNC_PHAD_SHIFT)   |
        (reg << GEM_PHYMNTNC_PREG_SHIFT);
}


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    nx_driver_zynqmp_mii_read_async_get      Zynq UltraScale+ MPSoC/GNU */
/*                                                           5.0          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Regis Feneon, Express Logic France.                                 */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function gets the value of a PHY asynchronous read operation   */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    driver_ptr                            The driver instance           */
/*    value_ptr                             The read value                */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                                Completion status             */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    PHY driver                                                          */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  07-01-2018     Regis Feneon             Initial Version 5.0           */
/*                                                                        */
/**************************************************************************/
UINT nx_driver_zynqmp_mii_read_async_get(NX_DRIVER_INFORMATION *driver_ptr, UINT *value_ptr)
{
    if (!(driver_ptr->nx_driver_information_gem->network_status & GEM_NWSR_MDIOIDLE))
    {
        /* still busy */
        return TX_NOT_AVAILABLE;
    }

    /* return read value */
    *value_ptr = driver_ptr->nx_driver_information_gem->phy_management & GEM_PHYMNTNC_DATA;
    return NX_SUCCESS;
}


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    nx_driver_zynqmp_gem_phy_addr_set        Zynq UltraScale+ MPSoC/GNU */
/*                                                           5.0          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Regis Feneon, Express Logic France.                                 */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function configures the PHY address                            */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                The IP instance               */
/*    interface_index                       The interface index           */
/*    phy_addr                              The PHY address               */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                                Completion status             */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    nx_ip_driver_interface_direct_command                               */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application                                                         */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  07-01-2018     Regis Feneon             Initial Version 5.0           */
/*                                                                        */
/**************************************************************************/
UINT nx_driver_zynqmp_gem_phy_addr_set(NX_IP *ip_ptr, UINT interface_index, UINT phy_addr)
{
    return nx_ip_driver_interface_direct_command(ip_ptr, CMD_PHY_ADDR_SET, interface_index, (ULONG *) &phy_addr);
}


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    nx_driver_zynqmp_gem_dmabds_set          Zynq UltraScale+ MPSoC/GNU */
/*                                                           5.0          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Regis Feneon, Express Logic France.                                 */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function configures the DMA buffers descriptors                */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                The IP instance               */
/*    interface_index                       The interface index           */
/*    rx_ptr                                The RX descriptors virtual    */
/*                                            address                     */
/*    rx_physaddr                           The RX descriptors physical   */
/*                                            address                     */
/*    rx_num                                The number of RX descriptors  */
/*    tx_ptr                                The TX descriptors virtual    */
/*                                            address                     */
/*    tx_physaddr                           The TX descriptors physical   */
/*                                            address                     */
/*    tx_num                                The number of TX descriptors  */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                                Completion status             */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    nx_ip_driver_interface_direct_command                               */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application                                                         */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  07-01-2018     Regis Feneon             Initial Version 5.0           */
/*                                                                        */
/**************************************************************************/
UINT nx_driver_zynqmp_gem_dmabds_set(NX_IP *ip_ptr, UINT interface_index, void *rx_ptr, UINT rx_num, void *tx_ptr, UINT tx_num)
{
    DMABDS_SET set;
    set.rx_ptr    = rx_ptr;
    set.rx_num    = rx_num;
    set.tx_ptr    = tx_ptr;
    set.tx_num    = tx_num;
    return nx_ip_driver_interface_direct_command(ip_ptr, CMD_DMABDS_SET, interface_index, (ULONG *) &set);
}
