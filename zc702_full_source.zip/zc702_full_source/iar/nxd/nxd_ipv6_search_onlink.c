/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2016 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/
/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Protocol version 6 Default Router Table (IPv6 router)      */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/
#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_ipv6.h"
#include "nx_nd_cache.h"


#ifdef FEATURE_NX_IPV6
/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nxd_ipv6_search_onlink                              PORTABLE C     */
/*                                                           5.10         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function checks whether a given IP address is on link.         */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                IP instance                   */
/*    dest_addr                             The destination address to    */
/*                                             be checked.                */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                                0: Address is not onlink      */
/*                                          1: Address is onlink          */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    NONE                                                                */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    nx_ipv6_packet_send                  Sends IPv6 packets from upper  */
/*                                           layer to remote host         */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-30-2007     Yuxin Zhou               Initial Version 5.2           */
/*  08-03-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            fixed a bug where incorrect */
/*                                            bit mask was used,          */
/*                                            modified struct field names */
/*                                            missing struct name prefix, */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s), also     */
/*                                            search for manually         */
/*                                            configured IPv6 addresses   */
/*                                            for onlink nodes, resulting */
/*                                            in version 5.6              */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s),          */
/*                                            fixed compiler warnings,    */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            fixed type for shift,       */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*                                                                        */
/**************************************************************************/
INT _nxd_ipv6_search_onlink(NX_IP *ip_ptr, ULONG *dest_addr)
{

ULONG                 valid_words;
ULONG                 valid_bits;
ULONG                 i;
ULONG                 valid_mask;
UINT                  addr_index;
NX_IPV6_PREFIX_ENTRY *prefix_entry;
NXD_IPV6_ADDRESS     *ipv6_address;


    /* First special case is the link local address. All these
       addresses are onlink.  */
    if ((dest_addr[0] & (UINT)0xFFE00000) == (UINT)0xFE800000)
    {
        return(1);
    }

    /* Set a local pointer for convenience. */
    prefix_entry = ip_ptr -> nx_ipv6_prefix_list_ptr;

    /* Loop through the prefix table. Prefixes are the IPv6 equivalent of
       network domains in IPv4.  */
    while (prefix_entry)
    {

        /* Attempt to match the top words against the network prefix. */
        valid_words = prefix_entry -> nx_ipv6_prefix_entry_prefix_length >> 5;

        for (i = 0; i < valid_words; i++)
        {
            /* As soon as we hit a mismatch, bail out and go to the next prefix. */
            if (dest_addr[i] != prefix_entry -> nx_ipv6_prefix_entry_network_address[i])
            {
                break;
            }
        }

        /* Did the prefix match the network address component of the destination? */
        if (i == valid_words)
        {

            /* Yes, so check the rest of the address.  */
            valid_bits = prefix_entry -> nx_ipv6_prefix_entry_prefix_length & 31;
            if (valid_bits)
            {
                valid_mask = ~(((ULONG)1 << (32 - valid_bits)) - 1);

                /* If they match this is an onlink address. */
                if (prefix_entry -> nx_ipv6_prefix_entry_network_address[i] == (dest_addr[i] & valid_mask))
                {
                    return(1);
                }
            }
            else
            {
                return(1);
            }
        }

        /* No match. Try the next prefix. */
        prefix_entry = prefix_entry -> nx_ipv6_prefix_entry_next;
    }

    /* If no matches found in the prefix list, search the manually configured IPv6 interface addresses. */
    for (addr_index = 0; addr_index < NX_MAX_IPV6_ADDRESSES; addr_index++)
    {

        ipv6_address = &ip_ptr -> nx_ipv6_address[addr_index];
        /* Skip invalid entries. */
        if (!(ipv6_address -> nxd_ipv6_address_valid))
        {
            continue;
        }

        /* Skip non-manually configured entires. */
        if (ipv6_address -> nxd_ipv6_address_ConfigurationMethod != NX_IPV6_ADDRESS_MANUAL_CONFIG)
        {
            continue;
        }

        /* Check whether or not the destination address is on link. */

        /* Attempt to match the top words against the network prefix. */
        valid_words = (ipv6_address -> nxd_ipv6_address_prefix_length) >> 5;

        for (i = 0; i < valid_words; i++)
        {
            /* As soon as we hit a mismatch, bail out and go to the next prefix. */
            if (dest_addr[i] != ipv6_address -> nxd_ipv6_address[i])
            {
                break;
            }
        }

        /* Did the prefix match the network address component of the destination? */
        if (i == valid_words)
        {

            /* Yes, so check the rest of the address.  */
            valid_bits = ipv6_address -> nxd_ipv6_address_prefix_length & 31;
            if (valid_bits)
            {
                valid_mask = ~(((ULONG)1 << (32 - valid_bits)) - 1);

                /* If they match this is an onlink address. */
                if (((ipv6_address -> nxd_ipv6_address[i]) & valid_mask) == (dest_addr[i] & valid_mask))
                {
                    return(1);
                }
            }
            else
            {
                return(1);
            }
        }
    }


    /* No matches found. Not an onlink address. */
    return(0);
}

#endif /* FEATURE_NX_IPV6 */

