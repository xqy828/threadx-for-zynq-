/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/
/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Protocol version 6 Default Router Table (IPv6 router)      */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/
#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_ipv6.h"
#include "nx_nd_cache.h"


#ifdef FEATURE_NX_IPV6
/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nxd_ipv6_find_default_router_from_address          PORTABLE C      */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function finds the specific IPv6 default router.               */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                IP instance pointer           */
/*    router_address                        The specific gateway address  */
/*                                            to search for.              */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    default router entry                  Pointer to the default router */
/*                                            entry.                      */
/*  CALLS                                                                 */
/*                                                                        */
/*    tx_mutex_get                          Obtain IP protection mutex    */
/*    tx_mutex_put                          Release IP protection mutex   */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    _nxd_icmpv6_process_na                                              */
/*                                                                        */
/*  NOTE                                                                  */
/*                                                                        */
/*    This function acquires the nx_ipv6_protection mutex.                */
/*    Make sure the mutex is not locked before entering this function.    */
/*                                                                        */
/*    This function cannot be called from ISR.                            */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-30-2007     Yuxin Zhou               Initial Version 5.2           */
/*  08-03-2009     Janet Christiansen       Modified comment(s), and added*/
/*                                            logic for trace support,    */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            modified struct field names */
/*                                            missing struct name prefix, */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.11   */
/*                                                                        */
/**************************************************************************/
NX_IPV6_DEFAULT_ROUTER_ENTRY *_nxd_ipv6_find_default_router_from_address(NX_IP *ip_ptr, ULONG *router_address)
{

INT                           i;
NX_IPV6_DEFAULT_ROUTER_ENTRY *rt_entry;


    /* Get exclusive access to the IP task lock. */
    tx_mutex_get(&(ip_ptr -> nx_ip_protection), TX_WAIT_FOREVER);

    /* Start the search at the top of the list...*/
    i = 0;

    /* And go through the entire table or until a match is found. */
    while (i < NX_IPV6_DEFAULT_ROUTER_TABLE_SIZE)
    {

        /* Local pointer to table entry. */
        rt_entry = &ip_ptr -> nx_ipv6_default_router_table[i];

        /* Does this slot contain a valid router? */
        if (rt_entry -> nx_ipv6_default_router_entry_flag)
        {

            /* Yes, check if it matches the specified router address. */
            if (CHECK_IPV6_ADDRESSES_SAME(router_address, rt_entry -> nx_ipv6_default_router_entry_router_address))
            {


                /* Yes it does, we can release the IP protection. */
                tx_mutex_put(&(ip_ptr -> nx_ip_protection));

                /* Return the pointer to this router entry. */
                return(rt_entry);
            }
        }

        i++;
    }

    /* Release the lock. */
    tx_mutex_put(&(ip_ptr -> nx_ip_protection));

    /* Return a null pointer indicating no matching router found. */
    return(NX_NULL);
}

#endif /* FEATURE_NX_IPV6 */

