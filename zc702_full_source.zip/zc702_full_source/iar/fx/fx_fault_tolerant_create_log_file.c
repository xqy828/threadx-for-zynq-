/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2017 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** FileX Component                                                       */
/**                                                                       */
/**   Fault Tolerant                                                      */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define FX_SOURCE_CODE

#include "fx_api.h"
#include "fx_utility.h"
#include "fx_directory.h"
#include "fx_fault_tolerant.h"


#ifdef FX_ENABLE_FAULT_TOLERANT
/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _fx_fault_tolerant_create_log_file                  PORTABLE C      */
/*                                                           5.5          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function finds an available cluster used by log file. Then it  */
/*    sets the cluster number to boot sector.                             */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    media_ptr                             Media control block pointer   */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    return status                                                       */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _fx_utility_exFAT_cluster_state_set   Set state of exFAT cluster    */
/*    _fx_utility_FAT_entry_read            Read a FAT entry              */
/*    _fx_utility_FAT_entry_write           Write a FAT entry             */
/*    _fx_utility_exFAT_bitmap_flush        Flush exFAT allocation bitmap */
/*    _fx_utility_FAT_flush                 Flush written FAT entries     */
/*    _fx_utility_32_unsigned_write         Write a ULONG from memory     */
/*    _fx_utility_exFAT_system_sector_write Write data into boot sector   */
/*    _fx_utility_exFAT_system_area_checksum_write                        */
/*                                          Write checksum of boot sector */
/*    _fx_utility_exFAT_bitmap_free_cluster_find                          */
/*                                          Find a free cluster           */
/*    _fx_utility_logical_sector_read       Read a logical sector         */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    _fx_fault_tolerant_enable                                           */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  11-01-2015     William E. Lamie         Initial Version 5.3           */
/*  04-15-2016     William E. Lamie         Modified comment(s),          */
/*                                            cleaned up the code,        */
/*                                            resulting in version 5.4    */
/*  04-03-2017     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.5    */
/*                                                                        */
/**************************************************************************/
UINT _fx_fault_tolerant_create_log_file(FX_MEDIA *media_ptr)
{
ULONG  start_cluster;
ULONG  FAT_value = 0;
UINT   status;
ULONG  total_clusters;
#ifdef FX_ENABLE_EXFAT
ULONG  checksum;
UINT   i, count;
UCHAR *byte_ptr;
#endif /* FX_ENABLE_EXFAT */

    /* Yes. Create a log file. */
    /* First find a free cluster. */
    if (media_ptr -> fx_media_available_clusters == 0)
    {

        /* Out of disk space.  */
        return(FX_NO_MORE_SPACE);
    }

#ifdef FX_ENABLE_EXFAT
    if (media_ptr -> fx_media_FAT_type == FX_exFAT)
    {
        status = _fx_utility_exFAT_bitmap_free_cluster_find(media_ptr,
                                                            media_ptr -> fx_media_cluster_search_start,
                                                            &start_cluster);

        /* Check for a bad status.  */
        if (status != FX_SUCCESS)
        {

            /* Return the bad status.  */
            return(status);
        }

        /* Update Bitmap */
        status = _fx_utility_exFAT_cluster_state_set(media_ptr, start_cluster, FX_EXFAT_BITMAP_CLUSTER_OCCUPIED);

        /* Check for a bad status.  */
        if (status != FX_SUCCESS)
        {

            /* Return the bad status.  */
            return(status);
        }
    }
    else
    {
#endif /* FX_ENABLE_EXFAT */

        /* Loop to find the first available cluster.  */
        total_clusters = media_ptr -> fx_media_total_clusters;
        start_cluster = media_ptr -> fx_media_cluster_search_start;
        do
        {

            /* Make sure we stop looking after one pass through the FAT table.  */
            if (!total_clusters)
            {

                /* Something is wrong with the media - the desired clusters were
                   not found in the FAT table.  */
                return(FX_NO_MORE_SPACE);
            }

            /* Read FAT entry.  */
            status =  _fx_utility_FAT_entry_read(media_ptr, start_cluster, &FAT_value);

            /* Check for a bad status.  */
            if (status != FX_SUCCESS)
            {

                /* Return the bad status.  */
                return(status);
            }

            /* Decrement the total cluster count.  */
            total_clusters--;

            /* Determine if the FAT entry is free.  */
            if (FAT_value == FX_FREE_CLUSTER)
            {

                /* Move cluster search pointer forward.  */
                media_ptr -> fx_media_cluster_search_start =  start_cluster + 1;

                /* Determine if this needs to be wrapped.  */
                if (media_ptr -> fx_media_cluster_search_start >= (media_ptr -> fx_media_total_clusters + FX_FAT_ENTRY_START))
                {

                    /* Wrap the search to the beginning FAT entry.  */
                    media_ptr -> fx_media_cluster_search_start =  FX_FAT_ENTRY_START;
                }

                /* Break this loop.  */
                break;
            }
            else
            {

                /* FAT entry is not free... Advance the FAT index.  */
                start_cluster++;

                /* Determine if we need to wrap the FAT index around.  */
                if (start_cluster >= (media_ptr -> fx_media_total_clusters + FX_FAT_ENTRY_START))
                {

                    /* Wrap the search to the beginning FAT entry.  */
                    start_cluster = FX_FAT_ENTRY_START;
                }
            }
        } while (FX_TRUE);
#ifdef FX_ENABLE_EXFAT
    }
#endif /* FX_ENABLE_EXFAT */

    /* This is the last cluster. */
    status = _fx_utility_FAT_entry_write(media_ptr, start_cluster, media_ptr -> fx_media_fat_last);

    /* Check for a bad status.  */
    if (status != FX_SUCCESS)
    {

        /* Return the bad status.  */
        return(status);
    }

#ifdef FX_FAULT_TOLERANT
#ifdef FX_ENABLE_EXFAT
    if (media_ptr -> fx_media_FAT_type == FX_exFAT)
    {

        /* Flush exFAT bitmap.  */
        _fx_utility_exFAT_bitmap_flush(media_ptr);
    }
#endif /* FX_ENABLE_EXFAT */

    /* Ensure the new FAT chain is properly written to the media.  */

    /* Flush the cached individual FAT entries */
    _fx_utility_FAT_flush(media_ptr);
#endif

    /* Write start cluster for the file tolerant log file into the boot sector. */
    _fx_utility_32_unsigned_write(media_ptr -> fx_media_fault_tolerant_memory_buffer + FX_FAULT_TOLERANT_BOOT_INDEX, start_cluster);

    /* Write the boot sector.  */
    media_ptr -> fx_media_driver_request =       FX_DRIVER_BOOT_WRITE;
    media_ptr -> fx_media_driver_status =        FX_IO_ERROR;
    media_ptr -> fx_media_driver_buffer =        media_ptr -> fx_media_fault_tolerant_memory_buffer;
    media_ptr -> fx_media_driver_sectors =       1;
    media_ptr -> fx_media_driver_sector_type =   FX_BOOT_SECTOR;

    /* If trace is enabled, insert this event into the trace buffer.  */
    FX_TRACE_IN_LINE_INSERT(FX_TRACE_INTERNAL_IO_DRIVER_BOOT_WRITE, media_ptr, media_ptr -> fx_media_fault_tolerant_memory_buffer, 0, 0, FX_TRACE_INTERNAL_EVENTS, 0, 0)

    /* Invoke the driver to read the boot sector.  */
    (media_ptr -> fx_media_driver_entry) (media_ptr);

    /* Determine if the boot sector was read correctly. */
    if (media_ptr -> fx_media_driver_status != FX_SUCCESS)
    {

        /* Return the boot sector error status.  */
        return(FX_BOOT_ERROR);
    }

#ifdef FX_ENABLE_EXFAT
    if (media_ptr -> fx_media_FAT_type == FX_exFAT)
    {

        /* Write backup. */
        status = _fx_utility_exFAT_system_sector_write(media_ptr, media_ptr -> fx_media_fault_tolerant_memory_buffer,
                                                       FX_EXFAT_FAT_MAIN_SYSTEM_AREA_SIZE,
                                                       1, FX_BOOT_SECTOR);

        /* Determine if the boot sector was read correctly. */
        if (status != FX_SUCCESS)
        {

            /* Return the boot sector error status.  */
            return(FX_BOOT_ERROR);
        }

        /* Calculate checksum. */
        checksum = 0;
        byte_ptr = media_ptr -> fx_media_fault_tolerant_memory_buffer;

        /* Calculate Boot Sector Check Sum.  */
        for (i = 0; i < FX_BOOT_SECTOR_SIZE; i++)
        {
            if ((FX_EF_VOLUME_FLAGS     == i) ||
                (FX_EF_VOLUME_FLAGS + 1 == i) ||
                (FX_EF_PERCENT_IN_USE   == i))
            {
                continue;
            }

            checksum = ((checksum >> 1) | (checksum << 31)) + (ULONG)byte_ptr[i];
        }

        for (count = 1; count < FX_EXFAT_FAT_CHECK_SUM_OFFSET; count++)
        {

            /* Read sector. */
            status =  _fx_utility_logical_sector_read(media_ptr, (ULONG64) count,
                                                      media_ptr -> fx_media_fault_tolerant_memory_buffer, ((ULONG) 1), FX_BOOT_SECTOR);

            /* Check for good completion status.  */
            if (status !=  FX_SUCCESS)
            {

                /* Return the error status.  */
                return(status);
            }

            /* Calculate Check Sum for System Area  */
            for (i = 0; i < FX_BOOT_SECTOR_SIZE; i++)
            {
                checksum = ((checksum >> 1) | (checksum << 31)) + (ULONG)byte_ptr[i];
            }
        }

        /* Write System Area CheckSum.  */
        status = _fx_utility_exFAT_system_area_checksum_write(media_ptr, media_ptr -> fx_media_fault_tolerant_memory_buffer,
                                                              &checksum);

        if (status != FX_SUCCESS)
        {

            return(status);
        }
    }
#endif /* FX_ENABLE_EXFAT */

    /* Set the start cluster. */
    media_ptr -> fx_media_fault_tolerant_start_cluster = start_cluster;

    /* Decrease available cluster. */
    media_ptr -> fx_media_available_clusters--;

    /* Return success.  */
    return(FX_SUCCESS);
}
#endif /* FX_ENABLE_FAULT_TOLERANT */

