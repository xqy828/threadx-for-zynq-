/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2016 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Neighbor Discovery Cache                                            */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_nd_cache.h"
#ifdef FEATURE_NX_IPV6
#include "nx_ipv6.h"
#endif /* FEATURE_NX_IPV6 */

/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nxd_nd_cache_entry_ip_address_find                 PORTABLE C      */
/*                                                           5.10         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function finds an IPv6 address in the neighbor discovery       */
/*    cache table based on user-speicified MAC address.                   */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                Pointer to IP instance        */
/*    ip_address                            Pointer to the IP address     */
/*                                            to search for               */
/*    physical_msw                          Physical address, most        */
/*                                            significant word            */
/*    physical_lsw                          Physical address, least       */
/*                                            significant word            */
/*    interface_index                       Index to the network          */
/*                                            interface through which the */
/*                                            node is reachable.          */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    Status                                Completion status             */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _nx_nd_cache_find_entry_by_mac_addr   Internal find IP address in   */
/*                                          ND cache table mapped to      */
/*                                            input by mac address.       */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-30-2007     Yuxin Zhou               Initial Version 5.2           */
/*  08-03-2009     William E. Lamie         Modified comment(s), and added*/
/*                                            logic for trace support,    */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            modified struct field names */
/*                                            missing struct name prefix, */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s), added    */
/*                                            support for multihome,      */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s), fixed    */
/*                                            compiler warnings,          */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            optimized the code, returned*/
/*                                            NX_NOT_SUPPORTED when IPv6  */
/*                                            was disable,                */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*                                                                        */
/**************************************************************************/
UINT  _nxd_nd_cache_ip_address_find(NX_IP *ip_ptr,
                                    NXD_ADDRESS *ip_address,
                                    ULONG physical_msw,
                                    ULONG physical_lsw,
                                    UINT *interface_index)
{
#ifdef FEATURE_NX_IPV6

ND_CACHE_ENTRY *entry;

    /* Find ND entry according to the given MAC address. */
    /* Note: _nx_nd_cache_find_entry_by_mac_addr  will need to
       acquire the nx_nd_cache_protection lock. */
    if (_nx_nd_cache_find_entry_by_mac_addr(ip_ptr, physical_msw, physical_lsw, &entry) != NX_SUCCESS)
    {

        /* No such MAC address found in cache table. */
        return(NX_ENTRY_NOT_FOUND);
    }

    /* Copy the IP address and version from the cache entry into the address structure. */
    ip_address -> nxd_ip_version = NX_IP_VERSION_V6;

    /*lint -e{644} suppress variable might not be initialized, since "entry" was initialized as long as previous call is NX_SUCCESS. */
    COPY_IPV6_ADDRESS(entry -> nx_nd_cache_dest_ip, ip_address -> nxd_ip_address.v6);

    /* If trace is enabled, insert this event into the trace buffer. */
    NX_TRACE_IN_LINE_INSERT(NX_TRACE_ND_CACHE_IP_ADDRESS_FIND, ip_ptr, ip_address -> nxd_ip_address.v6[3], physical_msw, physical_lsw, NX_TRACE_ARP_EVENTS, 0, 0);

    /* Get the interface_index.  */
    *interface_index = entry -> nx_nd_cache_interface_ptr -> nx_interface_index;

    /* Successful completion*/
    return(NX_SUCCESS);

#else /* !FEATURE_NX_IPV6 */
    NX_PARAMETER_NOT_USED(ip_ptr);
    NX_PARAMETER_NOT_USED(ip_address);
    NX_PARAMETER_NOT_USED(physical_msw);
    NX_PARAMETER_NOT_USED(physical_lsw);
    NX_PARAMETER_NOT_USED(interface_index);

    return(NX_NOT_SUPPORTED);

#endif /* FEATURE_NX_IPV6 */
}

