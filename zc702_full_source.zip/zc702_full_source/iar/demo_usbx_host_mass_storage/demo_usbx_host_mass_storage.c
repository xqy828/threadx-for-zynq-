/**************************************************************************/
/**                                                                       */ 
/** USBX Host Mass Storage Example for xilinx_zc702 Board                */
/**                                                                       */
/** This example illustrates USBX working on a Cortex-A9 processor        */
/**                                                                       */
/** This demo will show the host side of USBX. A USB flash drive can be   */ 
/** mounted and this demo will cycle through the directory entries,       */ 
/** reading the contents of any file in the root directory.               */ 
/**                                                                       */ 
/**************************************************************************/

/* Include necessary system files.  */

#include <stdio.h>
#include <stdlib.h>
#include "tx_api.h"
#include "fx_api.h"
#include "ux_api.h"
#include "ux_system.h"
#include "ux_utility.h"
#include "ux_hcd_ehci.h"
#include "ux_host_class_hub.h"
#include "ux_host_class_storage.h"

#include "xscugic.h"
#include "xusbps.h"
#include "xil_cache.h"


/* Define constants.  */

/* Define local function prototypes.  */

void  demo_thread_entry(ULONG arg);
UINT  demo_class_storage_get(void);

void  demo_read_file();
VOID hardware_setup(void);

/* Define global data structures.   */

TX_THREAD                           tx_demo_thread;
UX_HOST_CLASS                       *class_driver;
ULONG                               class_driver_index;
UX_HOST_CLASS_STORAGE               *storage;
UX_HOST_CLASS_STORAGE_MEDIA         *storage_media;
FX_MEDIA                            *media;
UINT                                status;
ULONG                               requested_length;
FX_FILE                             my_file;
TX_SEMAPHORE                        tx_demo_semaphore;
CHAR                                file_name[64];
UCHAR                               local_buffer[1024];
ULONG  								thread0_stack_area[  1024 / sizeof(ULONG)];
ULONG 								usb_memory_area[100* 1024/ sizeof(ULONG)] ;
UINT 								*usb_uncached_memory_area=(UINT*)0x10000000 ;
#define USB_UNCACHED_MEMORY 100*1024

XUsbPs_Config						*UsbConfigPtr;
XUsbPs 								UsbInstance;
extern XScuGic      				Gic0;

VOID hardware_setup(void);

int main(int argc, char ** argv)
{
    /* Setup the hardware. */
    hardware_setup();

    /* Enter the ThreadX kernel.  */
    tx_kernel_enter();
}


void  tx_application_define(void *first_unused_memory)
{
    /* Initialize FileX.  */
    fx_system_initialize();
    
    ux_system_initialize(usb_memory_area,sizeof(usb_memory_area), usb_uncached_memory_area, USB_UNCACHED_MEMORY);
    /* Create the main demo thread.  */
    tx_thread_create(&tx_demo_thread, "tx demo", demo_thread_entry, 0,  
    		thread0_stack_area, sizeof(thread0_stack_area),
            30, 30, 1, TX_AUTO_START);
}


void  demo_thread_entry(ULONG arg)
{

    /* The code below is required for installing the host portion of USBX.  */
    status =  ux_host_stack_initialize(UX_NULL);
    if (status != UX_SUCCESS)
        return;
    
    /* Register the HUB class.  */
    status =  ux_host_stack_class_register(_ux_system_host_class_hub_name, _ux_host_class_hub_entry);
    if (status != UX_SUCCESS)
        return;

    /* Register storage class.  */
    status =  ux_host_stack_class_register(_ux_system_host_class_storage_name, _ux_host_class_storage_entry);
    if (status != UX_SUCCESS)
    {
        return;
    }


    status =  ux_host_stack_hcd_register(_ux_system_host_hcd_ehci_name, _ux_hcd_ehci_initialize, 0xe0002000 + 0x100, 0x0);

    status = XScuGic_Connect(&Gic0,  XPAR_XUSBPS_0_INTR, (Xil_InterruptHandler)_ux_hcd_ehci_interrupt_handler,
                  NULL);

    if (status != UX_SUCCESS)
    return;

    XScuGic_Enable(&Gic0, XPAR_XUSBPS_0_INTR);

    if (status != UX_SUCCESS)
    {
        return;
    }


    while(1)
    {
      /* Find the storage class. */
      status =  demo_class_storage_get();
      
      if (status != UX_SUCCESS)
          continue;

      /* Find first file on media.  */
      status =  fx_directory_first_entry_find(media, file_name);
      
      if (status != UX_SUCCESS)
          continue;

      demo_read_file();
     
      tx_thread_sleep(10);
    }  
}

void demo_read_file()
{  
ULONG       files_count = 0;
FX_FILE     my_file;
ULONG       requested_length;
UINT        file_attribute;
ULONG       error_count = 0;

    /* We come here if there is at least a file in the directory.   */
    do
    {

        /* Increment file count.  */
        files_count++;

        /* Reset file attributes.  */
        file_attribute = 0;
        
        /* Try to read the file attributes.  */
        status =  fx_file_attributes_read(media, file_name, &file_attribute);

        /* If this is a directory, pass.  */
        if(!(file_attribute & 0x18) && (status == UX_SUCCESS))
        {

                /* Try to open the file.  */
                status =  fx_file_open(media, &my_file, file_name, FX_OPEN_FOR_READ);
                if (status != UX_SUCCESS)
                    break;
    
                /* Read the entire file.  */
                while(status == UX_SUCCESS)
                {

                    /* Read the file in blocks */
                    status = fx_file_read(&my_file, local_buffer,1024, &requested_length);
                    
                    /* Check if status OK.  */
                    if (status != UX_SUCCESS)
                    {
                        error_count++;
                        break;
                    }                    
    
                    /* Check if end of file.  */
                    if (requested_length != 1024)
                        break;
    
                }
                /* Finished reading file either at the end or because of error. */
                fx_file_close(&my_file);
        }            

        /* Ask FileX to find another file.  */
        status =  fx_directory_next_entry_find(media, file_name);
    
    } while(status == UX_SUCCESS);

    /* We get here we have exhausted all the files in the root directory. */
    return;
}


UINT  demo_class_storage_get(void)
{

UX_HOST_CLASS       *class;


    /* Find the main storage container */
    status =  ux_host_stack_class_get(_ux_system_host_class_storage_name, &class);
    if (status != UX_SUCCESS)
        return(status);

    
    /* We still need to wait for the storage status to be live */
    do
    {
        /* We get the first instance of the storage device */
        do  
        {

            status =  ux_host_stack_class_instance_get(class, 0, (void **) &storage);
            tx_thread_sleep(10);
        } while (status != UX_SUCCESS);
        
        tx_thread_sleep(10);
        
    }while (storage -> ux_host_class_storage_state != UX_HOST_CLASS_INSTANCE_LIVE);

    /* We try to get the first media attached to the class container.  */
    while (class -> ux_host_class_media == UX_NULL)
    {
        tx_thread_sleep(10);
    }

    /* Setup media pointer.  */
    storage_media =  (UX_HOST_CLASS_STORAGE_MEDIA *) class -> ux_host_class_media;
    media =  &storage_media -> ux_host_class_storage_media;

    return(UX_SUCCESS);
}
