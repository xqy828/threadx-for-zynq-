/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2017 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** FileX Component                                                       */
/**                                                                       */
/**   Media                                                               */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define FX_SOURCE_CODE


/* Include necessary system files.  */

#include "fx_api.h"
#include "fx_system.h"
#include "fx_directory.h"
#include "fx_media.h"
#include "fx_utility.h"
#ifdef FX_ENABLE_EXFAT
#include "fx_directory_exFAT.h"
#endif /* FX_ENABLE_EXFAT */


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _fx_media_volume_get                                PORTABLE C      */
/*                                                           5.5          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function reads the volume name stored in the media's boot      */
/*    record or root directory.                                           */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    media_ptr                             Media control block pointer   */
/*    volume_name                           Pointer to destination for    */
/*                                            the volume name (maximum    */
/*                                            11 characters + NULL)       */
/*    volume_source                         Source of volume              */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    return status                                                       */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _fx_utility_logical_sector_read       Read directory sector         */
/*    _fx_directory_entry_read              Directory entry read          */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-12-2005     William E. Lamie         Initial Version 5.0           */
/*  07-18-2007     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.1    */
/*  03-01-2009     William E. Lamie         Modified comment(s), and      */
/*                                            added trace logic,          */
/*                                            resulting in version 5.2    */
/*  11-01-2015     William E. Lamie         Modified comment(s), and      */
/*                                            added exFAT support,        */
/*                                            resulting in version 5.3    */
/*  04-15-2016     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  04-03-2017     William E. Lamie         Modified comment(s), added    */ 
/*                                            driver status check for     */ 
/*                                            boot sector read, and       */
/*                                            corrected volume name copy  */ 
/*                                            from directory, fixed       */ 
/*                                            compile warnings,           */
/*                                            resulting in version 5.5    */
/*                                                                        */
/**************************************************************************/
UINT  _fx_media_volume_get(FX_MEDIA *media_ptr, CHAR *volume_name, UINT volume_source)
{

UINT         status, offset;
ULONG        i;

#ifdef FX_ENABLE_EXFAT
ULONG        character_count;
#endif /* FX_ENABLE_EXFAT */
FX_DIR_ENTRY dir_entry;


    /* Clear the volume name.  */
    volume_name[0] =  FX_NULL;

    /* Check the media to make sure it is open.  */
    if (media_ptr -> fx_media_id != FX_MEDIA_ID)
    {

        /* Return the media not opened error.  */
        return(FX_MEDIA_NOT_OPEN);
    }

    /* If trace is enabled, insert this event into the trace buffer.  */
    FX_TRACE_IN_LINE_INSERT(FX_TRACE_MEDIA_VOLUME_GET, media_ptr, volume_name, volume_source, 0, FX_TRACE_MEDIA_EVENTS, 0, 0)

    /* Protect against other threads accessing the media.  */
    FX_PROTECT

#ifdef FX_ENABLE_EXFAT
    if (media_ptr -> fx_media_FAT_type == FX_exFAT)
    {
        volume_source = FX_DIRECTORY_SECTOR;
    }
#endif /* FX_ENABLE_EXFAT */

    /* Ensure the volume name is NULL initially.  */
    volume_name[0] =  FX_NULL;

    /* Determine if the request is for the boot record.  */
    if (volume_source == FX_BOOT_SECTOR)
    {

        /* Read the logical directory sector 0 - we just do this to get a memory_buffer pointer */
        status =  _fx_utility_logical_sector_read(media_ptr, ((ULONG64) 0),
                                                  media_ptr -> fx_media_memory_buffer, ((ULONG) 1), FX_DATA_SECTOR);

        /* Check the return status.  */
        if (status != FX_SUCCESS)
        {

            /* Release media protection.  */
            FX_UNPROTECT

            /* Return the error status.  */
            return(status);
        }

#ifndef FX_MEDIA_STATISTICS_DISABLE

        /* Increment the number of driver read boot sector requests.  */
        media_ptr -> fx_media_driver_boot_read_requests++;
#endif

        /* Build the driver request to read the boot record.  */
        media_ptr -> fx_media_driver_request =      FX_DRIVER_BOOT_READ;
        media_ptr -> fx_media_driver_status =       FX_IO_ERROR;
        media_ptr -> fx_media_driver_buffer =       media_ptr -> fx_media_memory_buffer;
        media_ptr -> fx_media_driver_sectors =      1;
        media_ptr -> fx_media_driver_sector_type =  FX_BOOT_SECTOR;

        /* If trace is enabled, insert this event into the trace buffer.  */
        FX_TRACE_IN_LINE_INSERT(FX_TRACE_INTERNAL_IO_DRIVER_BOOT_READ, media_ptr, media_ptr -> fx_media_memory_buffer, 0, 0, FX_TRACE_INTERNAL_EVENTS, 0, 0)

        /* Invoke the driver to read the boot sector.  */
        (media_ptr -> fx_media_driver_entry) (media_ptr);

        /* Determine if the request is successful.  */
        if (media_ptr -> fx_media_driver_status)
        {

            /* Release media protection.  */
            FX_UNPROTECT

            /* An error occurred in the driver.  */
            return(media_ptr -> fx_media_driver_status);
        }

        /* Calculate the offset to the volume name based on the type of FAT.  */
        if (media_ptr -> fx_media_32_bit_FAT)
        {

            /* FAT32 offset to volume name.  */
            offset =  FX_VOLUME_LABEL_32;
        }
        else
        {

            /* FAT12/16 offset to volume name.  */
            offset =  FX_VOLUME_LABEL;
        }

        /* Pickup the 11 characters of the volume name from the boot sector.  */
        for (i = 0; i < 11; i++)
        {

            /* Pickup byte of volume name.  */
            volume_name[i] =  (CHAR)media_ptr -> fx_media_memory_buffer[offset + i];

            /* Check for space character.  */
            if (volume_name[i] == (UCHAR)' ')
            {

                /* Yes, space character signals end of volume name.  */
                break;
            }
        }

        /* NULL terminate the volume name.  */
        volume_name[i] =  FX_NULL;
    }
    else
    {

        /* Setup pointer to media name buffer.  */
        dir_entry.fx_dir_entry_name =  media_ptr -> fx_media_name_buffer;

        /* Clear the short name string.  */
        dir_entry.fx_dir_entry_short_name[0] =  0;

        /* Attempt to find the volume name in the root directory.  */
        i =  0;
        do
        {

            /* Read an entry from the root directory.  */
            status =  _fx_directory_entry_read(media_ptr, FX_NULL, &i, &dir_entry);

            /* Check for error status.  */
            if (status != FX_SUCCESS)
            {

                /* Release media protection.  */
                FX_UNPROTECT

                /* Return to caller.  */
                return(status);
            }

            /* Check for a volume name.  */
#ifdef FX_ENABLE_EXFAT
            if (dir_entry.fx_dir_entry_attributes & FX_VOLUME || dir_entry.fx_dir_entry_type == FX_EXFAT_DIR_ENTRY_TYPE_VOLUME_LABEL)
#else
            if (dir_entry.fx_dir_entry_attributes & FX_VOLUME)
#endif /* FX_ENABLE_EXFAT */
            {

                /* Yes, we have found a previously set volume name.  */
                break;
            }

            /* Move to next directory entry.  */
            i++;
        } while (i < media_ptr -> fx_media_root_directory_entries);

        /* Determine if a volume entry has been found.  */
        if (i == media_ptr -> fx_media_root_directory_entries)
        {

            /* Release media protection.  */
            FX_UNPROTECT

            /* No existing volume name was found, return an error.  */
            return(FX_NOT_FOUND);
        }

#ifdef FX_ENABLE_EXFAT
        if (media_ptr -> fx_media_FAT_type == FX_exFAT)
        {

            /* Read the logical directory sector.  */
            status =  _fx_utility_logical_sector_read(media_ptr, (ULONG64) dir_entry.fx_dir_entry_log_sector,
                                                      media_ptr -> fx_media_memory_buffer, ((ULONG) 1), FX_DIRECTORY_SECTOR);

            /* Determine if an error occurred.  */
            if (status != FX_SUCCESS)
            {

                /* Release media protection.  */
                FX_UNPROTECT

                /* Return error code.  */
                return(status);
            }

            /* Offset to volume label entry.  */
            offset = dir_entry.fx_dir_entry_byte_offset;

            /* Read character count of volume label.  */
            character_count = media_ptr -> fx_media_memory_buffer[offset + FX_EXFAT_CHAR_COUNT];

            /* Move to volume label field.  */
            offset += FX_EXFAT_VOLUME_LABEL;

            for (i = 0; i < character_count; i++)
            {

                /* Read one character of volume label.  */
                volume_name[i] = (CHAR)_fx_utility_16_unsigned_read(&media_ptr -> fx_media_memory_buffer[offset]);

                /* Move to next character.  */
                offset += 2;
            }
        }
        else
        {
#endif /* FX_ENABLE_EXFAT */

            /* Pickup the 11 characters of the volume name from the directory entry.  */
            for (i = 0; i < 11; i++)
            {

                /* Pickup byte of volume name.  */
                volume_name[i] =  dir_entry.fx_dir_entry_name[i];

                /* Check for NULL character.  */
                if (volume_name[i] == ((UCHAR) 0))
                {

                    /* Yes, space character signals end of volume name.  */
                    break;
                }
            }
#ifdef FX_ENABLE_EXFAT
        }
#endif /* FX_ENABLE_EXFAT */

        /* NULL terminate the volume name.  */
        volume_name[i] =  FX_NULL;
    }

    /* Release media protection.  */
    FX_UNPROTECT

    /* Return success!  */
    return(FX_SUCCESS);
}

