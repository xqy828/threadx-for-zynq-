/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/
/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Protocol version 6 Default Router Table (IPv6 router)      */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/
#define NX_SOURCE_CODE


#include "nx_api.h"
#include "nx_ipv6.h"

#ifdef FEATURE_NX_IPV6

/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nxd_ipv6_find_max_prefix_length                    PORTABLE C      */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function finds the longest matching prefix between two IPv6    */
/*      addresses.                                                        */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    addr1                                 IPv6 address 1                */
/*    addr2                                 IPv6 address 2                */
/*    max_length                            Maximum length to match       */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    Number of matching bits                                             */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    _nx_ipv6_source_selection                                           */
/*                                                                        */
/*  NOTE                                                                  */
/*                                                                        */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  11-23-2009     Yuxin Zhou               Initial Version 5.4           */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            fixed a bug where least     */
/*                                            signficant byte was matched */
/*                                            first, resulting in         */
/*                                            version 5.5                 */
/*  10-10-2011     Yuxin Zhou               Modified comment(s), replaced */
/*                                            lineary search with a       */
/*                                            binary search algorithm,    */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.11   */
/*                                                                        */
/**************************************************************************/
UINT _nxd_ipv6_find_max_prefix_length(ULONG *addr1, ULONG *addr2, UINT max_length)
{
UINT length = 0;
UINT i, j, bit, time;

    for (i = 0; i < 4; i++)
    {
        if (addr1[i] == addr2[i])
        {
            length += 32;
        }
        /* Length shall not exceed max_length. Stop compare. */
        else if (length + 31 < max_length)
        {
            break;
        }
        else
        {
            bit = 16;
            time = 16;
            for (j = 0; j < 5; j++)
            {
                time = time / 2;
                if (addr1[i] >> bit == addr2[i] >> bit)
                {
                    bit -= time;
                    if (time == 0)
                    {
                        length += (32 - bit);
                    }
                }
                else if (j == 4)
                {
                    length += (31 - bit);
                    break;
                }
                else
                {
                    bit += time;
                }
            }
            break;
        }
    }


    return(length);
}

#endif /* FEATURE_NX_IPV6 */

