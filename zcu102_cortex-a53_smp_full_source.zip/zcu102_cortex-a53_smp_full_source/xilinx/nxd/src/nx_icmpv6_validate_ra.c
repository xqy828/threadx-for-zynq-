/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/

/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Control Message Protocol (ICMP)                            */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE
/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_ipv6.h"
#include "nx_icmpv6.h"

#ifdef FEATURE_NX_IPV6


#ifndef NX_DISABLE_ICMPV6_ROUTER_ADVERTISEMENT_PROCESS

/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_icmpv6_validate_ra                              PORTABLE C      */
/*                                                           5.11 SP1     */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function validates incoming router advertisement messages.     */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    packet_ptr                            ICMP packet pointer           */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    NX_SUCCESS                            Successful completion (no     */
/*                                            option fields to validate)  */
/*    NX_NOT_SUCCESSFUL                     Invalid ICMP header data      */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    IPv6_Address_Type                     Find IP address type.         */
/*    _nx_icmpv6_validate_options           Validate option field.        */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    _nx_icmpv6_process_ra                 Main ICMP packet pocess       */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-30-2007     Yuxin Zhou               Initial Version 5.2           */
/*  08-03-2009     Yuxin Zhou               Modified comments, resuling   */
/*                                            in version 5.3              */
/*  11-23-2009     Yuxin Zhou               Added multiple IPv6 global    */
/*                                            address suppport,           */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comments, added      */
/*                                            IPv6 PMTU support,          */
/*                                            modified struct field names */
/*                                            missing struct name prefix, */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s),          */
/*                                            fixed compiler warnings,    */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            renamed symbols, resulting  */
/*                                            in version 5.9              */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.11   */
/*  12-15-2018     Yuxin Zhou               Modified comment(s), and      */
/*                                            supported for 64-bit mode,  */
/*                                            resulting in version 5.11SP1*/
/*                                                                        */
/**************************************************************************/
UINT _nx_icmpv6_validate_ra(NX_PACKET *packet_ptr)
{

NX_IPV6_HEADER   *ipv6_header;
NX_ICMPV6_RA     *header_ptr;
NX_ICMPV6_OPTION *option_ptr;
INT               option_length;
ULONG             source_address_type, dest_address_type;


    /* Set a pointer to he ICMP message header.  */
    /*lint -e{927} -e{826} suppress cast of pointer to pointer, since it is necessary  */
    header_ptr =  (NX_ICMPV6_RA *)packet_ptr -> nx_packet_prepend_ptr;

    /* Set a pointer to the IPv6 header. */
    /*lint -e{927} -e{826} suppress cast of pointer to pointer, since it is necessary  */
    ipv6_header = (NX_IPV6_HEADER *)packet_ptr -> nx_packet_ip_header;

    source_address_type = IPv6_Address_Type(ipv6_header -> nx_ip_header_source_ip);
    dest_address_type = IPv6_Address_Type(ipv6_header -> nx_ip_header_destination_ip);

    /* Validate the IP header information. */

    /*  The source address must be the link local router address. RFC2461 4.2 */
    if ((source_address_type & IPV6_ADDRESS_LINKLOCAL) != IPV6_ADDRESS_LINKLOCAL)
    {

        return(NX_NOT_SUCCESSFUL);
    }

    /* IP destination address must be multicast address or solicited sender link local address. */
    if ((dest_address_type  != (ULONG)(IPV6_ADDRESS_LINKLOCAL | IPV6_ADDRESS_UNICAST)) &&
        (dest_address_type  != (ULONG)(IPV6_ALL_NODE_MCAST | IPV6_ADDRESS_MULTICAST)))
    {

        return(NX_NOT_SUCCESSFUL);
    }

    /*  The IP header hop limit must be 255 */
    if ((ipv6_header -> nx_ip_header_word_1 & 0xFF) != 0xFF)
    {

        return(NX_NOT_SUCCESSFUL);
    }

    /* Validate ICMP fields */
    if (header_ptr -> nx_icmpv6_ra_icmpv6_header.nx_icmpv6_header_code != 0)
    {

        return(NX_NOT_SUCCESSFUL);
    }

    /* Locate the option field. */
    /*lint -e{923} suppress cast between pointer and ULONG, since it is necessary  */
    option_ptr = (NX_ICMPV6_OPTION *)NX_UCHAR_POINTER_ADD(header_ptr, sizeof(NX_ICMPV6_RA));
    option_length = (INT)(packet_ptr -> nx_packet_length - sizeof(NX_ICMPV6_RA));

    /* Check for options (if there is a non zero option length ICMPv6 header field). */
    if (option_length)
    {

        /* Validate option field(s). */
        return(_nx_icmpv6_validate_options(option_ptr, option_length, NX_NULL));
    }

    return(NX_SUCCESS);
}


#endif /* NX_DISABLE_ICMPV6_ROUTER_ADVERTISEMENT_PROCESS */

#endif /* FEATURE_NX_IPV6 */

