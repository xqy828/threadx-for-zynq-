/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Address Resolution Protocol (ARP)                                   */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_arp.h"


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_arp_enable                                      PORTABLE C      */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function enables the ARP management component for the          */
/*    specified IP instance.                                              */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                IP instance pointer           */
/*    arp_cache_memory                      Start of ARP cache memory     */
/*    arp_cache_size                        Size in bytes of cache memory */
/*    memset                                Set the memory                */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                                Completion status             */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-12-2005     William E. Lamie         Initial Version 5.0           */
/*  08-09-2007     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.1    */
/*  12-30-2007     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.2    */
/*  08-03-2009     William E. Lamie         Modified comment(s), and added*/
/*                                            logic for trace support,    */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s), cleaned  */
/*                                            up redundant logic,         */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s), added    */
/*                                            support for disabling IPv4, */
/*                                            resulting in version 5.11   */
/*                                                                        */
/**************************************************************************/
UINT  _nx_arp_enable(NX_IP *ip_ptr, VOID *arp_cache_memory, ULONG arp_cache_size)
{

#ifndef NX_DISABLE_IPV4
ULONG   i;
ULONG   arp_entries;
NX_ARP *entry_ptr;


    /* If trace is enabled, insert this event into the trace buffer.  */
    NX_TRACE_IN_LINE_INSERT(NX_TRACE_ARP_ENABLE, ip_ptr, arp_cache_memory, arp_cache_size, 0, NX_TRACE_ARP_EVENTS, 0, 0);

    /* Clear the entire ARP cache.  */
    memset((void *)arp_cache_memory, 0, arp_cache_size);

    /* Pickup starting address of ARP entry array.  */
    entry_ptr =  (NX_ARP *)arp_cache_memory;

    /* Determine how many ARP entries will fit in this cache area.  */
    arp_entries =  arp_cache_size / sizeof(NX_ARP);

    /* Initialize the forward pointers of available ARP entries.  */
    for (i = 0; i < (arp_entries - 1); i++)
    {
        /* Setup each entry to point to the next entry.  */
        entry_ptr -> nx_arp_pool_next =  entry_ptr + 1;
        entry_ptr++;
    }

    /* The entry now points to the last entry in the ARP array.  Set its
       next pointer to the first entry.  */
    entry_ptr -> nx_arp_pool_next =  (NX_ARP *)arp_cache_memory;

    /* Initialize the backward pointers of available ARP entries.  */
    for (i = 0; i < (arp_entries - 1); i++)
    {
        /* Setup each entry to point to the previous entry.  */
        entry_ptr -> nx_arp_pool_previous =  entry_ptr - 1;
        entry_ptr--;
    }

    /* The entry now points to the first entry, set the previous pointer
       to the last entry.  */
    entry_ptr -> nx_arp_pool_previous =  (entry_ptr + (arp_entries - 1));

    /* At this point, everything is okay in the ARP enable call.. populate the
       information in the IP structure.  */

    /* Setup the list head pointers in the IP instance.  At first all ARP
       entries are associated with the dynamic ARP list.  The static ARP list
       is NULL until static ARP entry calls are made.  */
    ip_ptr -> nx_ip_arp_static_list =   NX_NULL;
    ip_ptr -> nx_ip_arp_dynamic_list =  (NX_ARP *)arp_cache_memory;

    /* Store the initial ARP cache information in the IP control block.  */
    ip_ptr -> nx_ip_arp_cache_memory  =  arp_cache_memory;
    ip_ptr -> nx_ip_arp_total_entries =  arp_entries;

    /* Setup the ARP periodic update routine.  */
    ip_ptr -> nx_ip_arp_periodic_update =  _nx_arp_periodic_update;

    /* Setup the ARP queue process routine.  */
    ip_ptr -> nx_ip_arp_queue_process =  _nx_arp_queue_process;

    /* Setup the ARP send packet routine.  */
    ip_ptr -> nx_ip_arp_packet_send =  _nx_arp_packet_send;

    /* Setup the ARP allocate service request pointer.  */
    ip_ptr -> nx_ip_arp_allocate =  _nx_arp_entry_allocate;

    /* Return successful completion.  */
    return(NX_SUCCESS);
#else /* NX_DISABLE_IPV4  */
    NX_PARAMETER_NOT_USED(ip_ptr);
    NX_PARAMETER_NOT_USED(arp_cache_memory);
    NX_PARAMETER_NOT_USED(arp_cache_size);

    return(NX_NOT_SUPPORTED);
#endif /* !NX_DISABLE_IPV4  */
}

#ifndef NX_DISABLE_INCLUDE_SOURCE_CODE
#include "nx_arp_dynamic_entry_delete.c"
#include "nx_arp_entry_delete.c"
#include "nx_arp_interface_entries_delete.c"
#include "nx_arp_queue_send.c"
#include "nx_arp_static_entry_delete_internal.c"
#include "nx_arp_announce_send.c"
#include "nx_arp_probe_send.c"
#endif /* NX_DISABLE_INCLUDE_SOURCE_CODE */

