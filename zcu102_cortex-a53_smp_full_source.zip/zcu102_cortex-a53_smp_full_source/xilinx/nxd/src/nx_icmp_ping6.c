/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Control Message Protocol (ICMP)                            */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE

/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_icmpv6.h"

#ifdef FEATURE_NX_IPV6



/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_icmp_ping6                                      PORTABLE C      */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function builds an ICMPv6 ping request packet and calls the    */
/*    associated driver to send it out on the network.  The function will */
/*    then suspend for the specified time waiting for the ICMP ping       */
/*    response.                                                           */
/*                                                                        */
/*    Note that for multicast or link local destination addresses, NetX   */
/*    Duo will default to the primary interface.  To specify a non primary*/
/*    interface to send pings out on with these address destination       */
/*    address types, use the nx_icmp_interface_ping6 service.             */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                Pointer to IP instance        */
/*    ip_address                            IPv6 address to ping          */
/*    data_ptr                              Pointer to user data to       */
/*                                           include in ping packet       */
/*    data_size                             Size of user data             */
/*    response_ptr                          Pointer to response packet    */
/*    wait_option                           Time out on packet allocate   */
/*                                             and sending packet         */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                                Actual completion status      */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _nxd_ipv6_interface_find             Finds outgoing interface       */
/*    _nx_icmp_interface_ping6             Handle details of sending pings*/
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-30-2007     Yuxin Zhou               Initial Version 5.2           */
/*  08-03-2009     Yuxin Zhou               Modified comment(s), added    */
/*                                            logic for trace support,    */
/*                                            and logic for IPSec,        */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Added support for multiple    */
/*                                            IPv6 global addresses, also */
/*                                            NX_ICMP_PACKET now has IPsec*/
/*                                            header built-in, thus does  */
/*                                            require manual offset       */
/*                                            adjustment, resulting in    */
/*                                            version 5.4                 */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            modified struct field names */
/*                                            missing struct name prefix, */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s), moved    */
/*                                            the ping6 functionality to  */
/*                                            _nx_icmp_interface_ping6,   */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s), and      */
/*                                            supported specified source  */
/*                                            interface for IPv6,         */
/*                                            resulting in version 5.11   */
/*                                                                        */
/**************************************************************************/
UINT  _nx_icmp_ping6(NX_IP *ip_ptr, NXD_ADDRESS *ip_address, CHAR *data_ptr, ULONG data_size,
                     NX_PACKET **response_ptr, ULONG wait_option)
{

UINT              status;
NXD_IPV6_ADDRESS *outgoing_address;

    /* Clear the destination pointer.  */
    *response_ptr =  NX_NULL;

    /* Find a suitable outgoing interface. */
    status = _nxd_ipv6_interface_find(ip_ptr, ip_address -> nxd_ip_address.v6,
                                      &outgoing_address, NX_NULL);

    /* Cannot find usable outgoing interface. */
    if (status != NX_SUCCESS)
    {
        return(status);
    }

    /* Now send the actual ping packet. */
    /*lint -e{644} suppress variable might not be initialized, since "outgoing_address" was initialized in _nxd_ipv6_interface_find. */
    status = _nx_icmp_interface_ping6(ip_ptr, ip_address, data_ptr, data_size, outgoing_address, response_ptr, wait_option);

    return(status);
}

#endif /* FEATURE_NX_IPV6 */

