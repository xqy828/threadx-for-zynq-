/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Protocol (IP)                                              */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE



/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_ipv6.h"
#include "nx_icmpv6.h"

#ifdef FEATURE_NX_IPV6


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_ipv6_process_hop_by_hop_option                  PORTABLE C      */
/*                                                           5.11 SP1     */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function processes the Hop by Hop and the Destination headers. */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                Pointer to IP control block   */
/*    packet_ptr                            Pointer to packet to process  */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    NX_SUCCESS                            Successful completion         */
/*    NX_OPTION_HEADER_ERROR                Error parsing packet options  */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _nx_ipv6_option_error                Handle errors in IPv6 option   */
/*                                                                        */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    _nx_ipv6_dispatch_process            Process IPv6 optional header   */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-30-2007     Yuxin Zhou               Initial Version 5.1           */
/*  08-03-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            modified struct field names */
/*                                            missing struct name prefix, */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s), fixed    */
/*                                            a compiler warning,         */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s),          */
/*                                            fixed compiler warnings,    */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            supported packet debugging, */
/*                                            eliminated unreachable code,*/
/*                                            fixed compiler warnings,    */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s), added    */
/*                                            support for Thread, improved*/
/*                                            packet length verification, */
/*                                            resulting in version 5.11   */
/*  12-15-2018     Yuxin Zhou               Modified comment(s), and      */
/*                                            supported for 64-bit mode,  */
/*                                            resulting in version 5.11SP1*/
/*                                                                        */
/**************************************************************************/
UINT _nx_ipv6_process_hop_by_hop_option(NX_IP *ip_ptr, NX_PACKET *packet_ptr)
{

INT                        header_length;
UINT                       offset_base, offset;
UINT                       rv;
NX_IPV6_HOP_BY_HOP_OPTION *option;


    /* Add debug information. */
    NX_PACKET_DEBUG(__FILE__, __LINE__, packet_ptr);

    /* Read the Hdr Ext Len field. */
    header_length = *(packet_ptr -> nx_packet_prepend_ptr + 1);

    /* Calculate the the true header length: (n + 1) * 8 */
    header_length = (header_length + 1) << 3;

    /* The 1st option starts from the 3rd byte. */
    offset = 2;

    /*lint -e{946} -e{947} suppress pointer subtraction, since it is necessary. */
    /*lint -e{737} suppress loss of sign, since nx_packet_append_ptr is assumed to be larger than nx_packet_ip_header. */
    offset_base = (UINT)((ULONG)(packet_ptr -> nx_packet_prepend_ptr - packet_ptr -> nx_packet_ip_header) - (ULONG)sizeof(NX_IPV6_HEADER));
    header_length = header_length - (INT)offset;

    /* Sanity check; does the header length data go past the end of the end of the packet buffer? */
    /*lint -e{946} -e{947} suppress pointer subtraction, since it is necessary. */
    if ((UINT)(packet_ptr -> nx_packet_append_ptr - packet_ptr -> nx_packet_prepend_ptr) <
        ((UINT)header_length + offset))
    {

        /* Yes, handle the error as indicated by the option type 2 msb's. */
        /*lint -e{927} -e{826} suppress cast of pointer to pointer, since it is necessary  */
        option = (NX_IPV6_HOP_BY_HOP_OPTION *)(packet_ptr -> nx_packet_prepend_ptr + offset);

        _nx_ipv6_option_error(ip_ptr, packet_ptr, option -> nx_ipv6_hop_by_hop_option_type, offset_base + offset);
        return(NX_OPTION_HEADER_ERROR);
    }

    while (header_length > 0)
    {

        /* Get a pointer to the options. */
        /*lint -e{927} -e{826} suppress cast of pointer to pointer, since it is necessary  */
        option = (NX_IPV6_HOP_BY_HOP_OPTION *)(packet_ptr -> nx_packet_prepend_ptr + offset);

        switch (option -> nx_ipv6_hop_by_hop_option_type)
        {

        case 0:

            /* Pad1 option.  This option indicates the size of the padding is one.
               So we skip one byte. */
            offset++;
            header_length--;
            break;

        case 1:

            /* PadN option. Skip N+2 bytes. */
            offset += ((UINT)(option -> nx_ipv6_hop_by_hop_length) + 2);
            header_length -= ((INT)(option -> nx_ipv6_hop_by_hop_length) + 2);
            break;

#ifdef NX_ENABLE_THREAD
        case 109:

            /* RFC 7731.  */

            /* Skip N+2 bytes.  */
            offset += ((UINT)(option -> nx_ipv6_hop_by_hop_length) + 2);
            header_length -= ((INT)(option -> nx_ipv6_hop_by_hop_length) + 2);
            break;
#endif /* NX_ENABLE_THREAD  */

        default:

            /* Unknown option.  */
            rv = _nx_ipv6_option_error(ip_ptr, packet_ptr, option -> nx_ipv6_hop_by_hop_option_type, offset_base + offset);

            /* If no errors, just skip this option and move onto the next option.*/
            if (rv == NX_SUCCESS)
            {

                /* Skip this option and continue processing the rest of the header. */
                offset += ((UINT)(option -> nx_ipv6_hop_by_hop_length) + 2);
                header_length -= ((INT)(option -> nx_ipv6_hop_by_hop_length) + 2);
                break;
            }
            else
            {

                /* Return value indicates an error status: we need to drop the entire packet. */
                return(rv); /* Drop this packet. */
            }
        }
    }

    /* Successful processing of option header. */
    return(NX_SUCCESS);
}

#endif /*  FEATURE_NX_IPV6 */

