/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2016 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Address Resolution Protocol (ARP)                                   */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_arp.h"
#include "nx_ip.h"

/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_arp_dynamic_entry_set                           PORTABLE C      */
/*                                                           5.10         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function allocates an ARP dynamic entry for the application    */
/*    and assigns the specified IP to hardware mapping. If the specified  */
/*    hardware address is zero, an actual ARP request will be sent out.   */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                IP instance pointer           */
/*    ip_address                            IP Address to bind to         */
/*    physical_msw                          Physical address MSW          */
/*    physical_lsw                          Physical address LSW          */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                                Completion status             */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _nx_ip_route_find                     Find suitable outgoing        */
/*                                            interface                   */
/*    _nx_arp_entry_allocate                Allocate an ARP entry         */
/*    _nx_arp_packet_send                   Send ARP request              */
/*    _nx_arp_queue_send                    Send the queued packet        */
/*    tx_mutex_get                          Obtain protection mutex       */
/*    tx_mutex_put                          Release protection mutex      */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-12-2005     William E. Lamie         Initial Version 5.0           */
/*  08-09-2007     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.1    */
/*  12-30-2007     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.2    */
/*  08-03-2009     William E. Lamie         Modified comment(s), and added*/
/*                                            logic for trace support,    */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s), added    */
/*                                            multihome support,          */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            conditional compile the     */
/*                                            IP fragment logic,          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s),          */
/*                                            optimized NX_PACKET_STRUCT, */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s), ensured  */
/*                                            only one ARP entry points   */
/*                                            a specific address,         */
/*                                            optimized the ARP queued    */
/*                                            packet send routine,        */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*                                                                        */
/**************************************************************************/
UINT  _nx_arp_dynamic_entry_set(NX_IP *ip_ptr, ULONG ip_address,
                                ULONG physical_msw, ULONG physical_lsw)
{

NX_ARP       *arp_ptr;
NX_ARP       *search_ptr;
NX_ARP       *arp_list_head;
UINT          index;
UINT          status;
NX_INTERFACE *nx_interface = NX_NULL;
ULONG         next_hop_address;

    /* If trace is enabled, insert this event into the trace buffer.  */
    NX_TRACE_IN_LINE_INSERT(NX_TRACE_ARP_DYNAMIC_ENTRY_SET, ip_ptr, ip_address, physical_msw, physical_lsw, NX_TRACE_ARP_EVENTS, 0, 0);

    /* Initialize next_hop_address to zero. */
    next_hop_address = 0;

    /* Make sure the destination address is directly accessible. */
    if (_nx_ip_route_find(ip_ptr, ip_address, &nx_interface, &next_hop_address) != NX_SUCCESS)
    {

        return(NX_IP_ADDRESS_ERROR);
    }

    /*lint -e{644} suppress variable might not be initialized, since "next_hop_address" was initialized by _nx_ip_route_find. */
    if (next_hop_address != ip_address)
    {

        return(NX_IP_ADDRESS_ERROR);
    }

    /* Obtain protection on this IP instance for access into the ARP dynamic
       list.  */
    tx_mutex_get(&(ip_ptr -> nx_ip_protection), TX_WAIT_FOREVER);

    /* Calculate the hash index for the specified IP address.  */
    index =  (UINT)((ip_address + (ip_address >> 8)) & NX_ARP_TABLE_MASK);

    /* Pickup the head pointer of the ARP entries for this IP instance.  */
    arp_list_head =  ip_ptr -> nx_ip_arp_table[index];

    /* Search the ARP list for the same IP address.  */
    search_ptr =  arp_list_head;
    arp_ptr =     NX_NULL;
    while (search_ptr)
    {

        /* Determine if there is a duplicate IP address.  */
        if (search_ptr -> nx_arp_ip_address == ip_address)
        {

            /* Yes, the IP address matches, setup the ARP entry pointer.  */
            arp_ptr =  search_ptr;

            /* Get out of the loop.  */
            break;
        }

        /* Move to the next entry in the active list.  */
        search_ptr =  search_ptr -> nx_arp_active_next;

        /* Determine if the search pointer is back at the head of
           the list.  */
        if (search_ptr == arp_list_head)
        {

            /* End of the ARP list, end the search.  */
            break;
        }
    }

    /* Determine if an ARP entry is found.  */
    if (arp_ptr)
    {

        /* Determine if this is a static entry. */
        if (arp_ptr -> nx_arp_route_static == NX_TRUE)
        {

            /* Release the mutex.  */
            tx_mutex_put(&(ip_ptr -> nx_ip_protection));

            /* Return the error status.  */
            return(NX_SUCCESS);
        }
    }
    else
    {

        /* No matching IP address in the ARP cache and a new dynamic entry needs to be allocated.  */

        /* Allocate a dynamic ARP entry.  */
        status =  _nx_arp_entry_allocate(ip_ptr, &(ip_ptr -> nx_ip_arp_table[index]), NX_FALSE);

        /* Determine if an error occurred.  */
        if (status != NX_SUCCESS)
        {

            /* Release the mutex.  */
            tx_mutex_put(&(ip_ptr -> nx_ip_protection));

            /* Return the error status.  */
            return(status);
        }

        /* Otherwise, setup a pointer to the new ARP entry.  The newly allocated
           ARP entry was allocated at the end of the ARP list so it should be
           referenced using the previous pointer from the list head.  */
        arp_ptr =  (ip_ptr -> nx_ip_arp_table[index]) -> nx_arp_active_previous;
    }

    /* Setup the IP address and clear the physical mapping.  */
    arp_ptr -> nx_arp_ip_address =            ip_address;
    arp_ptr -> nx_arp_physical_address_msw =  physical_msw;
    arp_ptr -> nx_arp_physical_address_lsw =  physical_lsw;
    arp_ptr -> nx_arp_retries =               0;

    /*lint -e{644} suppress variable might not be initialized, since "nx_interface" was initialized in _nx_ip_route_find. */
    arp_ptr -> nx_arp_ip_interface =          nx_interface;

    /* Determine if a physical address was supplied.  */
    if ((physical_msw | physical_lsw) == 0)
    {

        /* Since there isn't physical mapping, change the update rate
           for possible ARP retries.  */
        arp_ptr -> nx_arp_entry_next_update =     NX_ARP_UPDATE_RATE;

        /* The physical address was not specified so send an
           ARP request for the selected IP address.  */
        /*lint -e{668} suppress possibly passing a null pointer, since nx_interface is set in _nx_ip_route_find.  */
        _nx_arp_packet_send(ip_ptr, ip_address, nx_interface);
    }
    else
    {

        /* Update the next update time.  */
        arp_ptr -> nx_arp_entry_next_update = NX_ARP_EXPIRATION_RATE;

        /* Call queue send function to send the packet queued up.  */
        _nx_arp_queue_send(ip_ptr, arp_ptr);
    }

    /* Release the protection on the ARP list.  */
    tx_mutex_put(&(ip_ptr -> nx_ip_protection));

    /* Return status to the caller.  */
    return(NX_SUCCESS);
}

