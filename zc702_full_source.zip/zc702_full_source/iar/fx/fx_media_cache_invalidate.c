/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2017 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** FileX Component                                                       */
/**                                                                       */
/**   Media                                                               */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define FX_SOURCE_CODE


/* Include necessary system files.  */

#include "fx_api.h"
#include "fx_media.h"
#include "fx_utility.h"


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _fx_media_cache_invalidate                          PORTABLE C      */
/*                                                           5.5          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function examines the logical cache, flushing written sectors  */
/*    out to the media and invalidating all sectors in the logical cache. */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    media_ptr                             Media control block pointer   */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    return status                                                       */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _fx_utility_FAT_flush                 Flush cached FAT entries      */
/*    _fx_utility_FAT_map_flush             Flush primary FAT changes to  */
/*                                            secondary FAT(s)            */
/*    _fx_utility_logical_sector_flush      Flush logical sector cache    */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-12-2005     William E. Lamie         Initial Version 5.0           */
/*  07-18-2007     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.1    */
/*  03-01-2009     William E. Lamie         Modified comment(s), and      */
/*                                            added trace logic,          */
/*                                            resulting in version 5.2    */
/*  11-01-2015     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.3    */
/*  04-15-2016     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  04-03-2017     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.5    */
/*                                                                        */
/**************************************************************************/
UINT  _fx_media_cache_invalidate(FX_MEDIA *media_ptr)
{

UINT status;
UINT i;


#ifndef FX_MEDIA_STATISTICS_DISABLE

    /* Increment the number of times this service has been called.  */
    media_ptr -> fx_media_flushes++;
#endif

    /* Check the media to make sure it is open.  */
    if (media_ptr -> fx_media_id != FX_MEDIA_ID)
    {

        /* Return the media not opened error.  */
        return(FX_MEDIA_NOT_OPEN);
    }

    /* If trace is enabled, insert this event into the trace buffer.  */
    FX_TRACE_IN_LINE_INSERT(FX_TRACE_MEDIA_CACHE_INVALIDATE, media_ptr, 0, 0, 0, FX_TRACE_MEDIA_EVENTS, 0, 0)

    /* Protect against other threads accessing the media.  */
    FX_PROTECT
    /* Flush the cached individual FAT entries */
    _fx_utility_FAT_flush(media_ptr);

    /* Flush changed sector(s) in the primary FAT to secondary FATs.  */
    _fx_utility_FAT_map_flush(media_ptr);

    /* Clear the FAT cache entry array.  */
    for (i = 0; i < FX_MAX_FAT_CACHE; i++)
    {

        /* Clear entry in the FAT cache.  */
        media_ptr -> fx_media_fat_cache[i].fx_fat_cache_entry_cluster =   0;
        media_ptr -> fx_media_fat_cache[i].fx_fat_cache_entry_value   =   0;
    }

    /* Clear the secondary FAT update map.  */
    for (i = 0; i < FX_FAT_MAP_SIZE; i++)
    {

        /* Clear bit map entry for secondary FAT update.  */
        media_ptr -> fx_media_fat_secondary_update_map[i] =  0;
    }

    /* Call the logical sector flush to invalidate the logical sector cache.  */
    status =  _fx_utility_logical_sector_flush(media_ptr, ((ULONG64) 1), (ULONG64) (media_ptr -> fx_media_total_sectors), FX_TRUE);

    /* Release media protection.  */
    FX_UNPROTECT

    /* If we get here, return successful status to the caller.  */
    return(status);
}

