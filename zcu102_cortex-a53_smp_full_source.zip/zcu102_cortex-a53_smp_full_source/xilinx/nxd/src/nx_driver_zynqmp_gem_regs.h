/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/**   Xilinx Zynq UltraScale+ MPSoC                                       */
/**                                                                       */
/**    Gigabit Ethernet Controller Registers Description                  */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#ifndef NX_DRIVER_ZYNQMP_GEM_REGS_H
#define NX_DRIVER_ZYNQMP_GEM_REGS_H

#include <stdint.h>

#define GEM0_BASE     0xFF0B0000u
#define GEM1_BASE     0xFF0C0000u
#define GEM2_BASE     0xFF0D0000u
#define GEM3_BASE     0xFF0E0000u

#define GEM0_IRQ      89
#define GEM1_IRQ      91
#define GEM2_IRQ      93
#define GEM3_IRQ      95

/* GEM registers */
typedef struct GEM_REGS_STRUCT {
    volatile uint32_t   network_control;
    volatile uint32_t   network_config;
    volatile uint32_t   network_status;
    uint32_t            pad_00c;
    volatile uint32_t   dma_config;
    volatile uint32_t   transmit_status;
    volatile uint32_t   receive_q_ptr;
    volatile uint32_t   transmit_q_ptr;
    volatile uint32_t   receive_status;
    volatile uint32_t   int_status;
    volatile uint32_t   int_enable;
    volatile uint32_t   int_disable;
    volatile uint32_t   int_mask;
    volatile uint32_t   phy_management;
    volatile uint32_t   pause_time;
    volatile uint32_t   tx_pause_quantum;
    volatile uint32_t   pbuf_txcutthru;
    volatile uint32_t   pbuf_rxcutthru;
    volatile uint32_t   jumbo_max_length;
    volatile uint32_t   external_fifo_interface;
    uint32_t            pad_050;
    volatile uint32_t   axi_max_pipeline;
    uint32_t            pad_058[10];  /* 058-080 */
    volatile uint32_t   hash_bottom;
    volatile uint32_t   hash_top;
    volatile uint32_t   spec_add1_bottom;
    volatile uint32_t   spec_add1_top;
    volatile uint32_t   spec_add2_bottom;
    volatile uint32_t   spec_add2_top;
    volatile uint32_t   spec_add3_bottom;
    volatile uint32_t   spec_add3_top;
    volatile uint32_t   spec_add4_bottom;
    volatile uint32_t   spec_add4_top;
    volatile uint32_t   spec_type1;
    volatile uint32_t   spec_type2;
    volatile uint32_t   spec_type3;
    volatile uint32_t   spec_type4;
    volatile uint32_t   wol_register;
    volatile uint32_t   stretch_ratio;
    volatile uint32_t   stacked_vlan;
    volatile uint32_t   tx_pfc_pause;
    volatile uint32_t   mask_add1_bottom;
    volatile uint32_t   mask_add1_top;
    volatile uint32_t   dma_addr_or_mask;
    volatile uint32_t   rx_ptp_unicast;
    volatile uint32_t   tx_ptp_unicast;
    volatile uint32_t   tsu_nsec_cmp;
    volatile uint32_t   tsu_sec_cmp;
    volatile uint32_t   tsu_msb_sec_cmp;
    volatile uint32_t   tsu_ptp_tx_msb_sec;
    volatile uint32_t   tsu_ptp_rx_msb_sec;
    volatile uint32_t   tsu_peer_tx_msb_sec;
    volatile uint32_t   tsu_peer_rx_msb_sec;
    volatile uint32_t   dpram_fill_dbg;
    volatile uint32_t   revision_reg;
    uint32_t            pad_100[192]; /* 100-400 */
    volatile uint32_t   int_q1_status;
    uint32_t            pad_404[15];  /* 404-440 */
    volatile uint32_t   transmit_q1_ptr;
    uint32_t            pad_444[15];  /* 444-480 */
    volatile uint32_t   receive_q1_ptr;
    uint32_t            pad_484[7];   /* 484-4a0 */
    volatile uint32_t   dma_rxbuf_size_q1;
    uint32_t            pad_4a4[6];   /* 4a4-4bc */
    volatile uint32_t   cbs_control;
    volatile uint32_t   cbs_idleslope_q_a;
    volatile uint32_t   cbs_idleslope_q_b;
    volatile uint32_t   upper_tx_q_base_addr;
    volatile uint32_t   tx_bd_control;
    volatile uint32_t   rx_bd_control;
    volatile uint32_t   upper_rx_q_base_addr;
    uint32_t            pad_4d8[10];  /* 4d8-500 */
    volatile uint32_t   screening_type_1_register_0;
    volatile uint32_t   screening_type_1_register_1;
    volatile uint32_t   screening_type_1_register_2;
    volatile uint32_t   screening_type_1_register_3;
    uint32_t            pad_510[12];  /* 510-540 */
    volatile uint32_t   screening_type_2_register_0;
    volatile uint32_t   screening_type_2_register_1;
    volatile uint32_t   screening_type_2_register_2;
    volatile uint32_t   screening_type_2_register_3;
    uint32_t            pad_550[44];  /* 550-600 */
    volatile uint32_t   int_q1_enable;
    uint32_t            pad_604[7];   /* 604-620 */
    volatile uint32_t   int_q1_disable;
    uint32_t            pad_624[7];   /* 624-640 */
    volatile uint32_t   int_q1_mask;
    uint32_t            pad_644[39];  /* 644-6e0 */
    volatile uint32_t   screening_type_2_ethertype_reg_0;
    volatile uint32_t   screening_type_2_ethertype_reg_1;
    volatile uint32_t   screening_type_2_ethertype_reg_2;
    volatile uint32_t   screening_type_2_ethertype_reg_3;
    uint32_t            pad_6f0[4];   /* 6f0-700 */
    volatile uint32_t   type2_compare_0_word_0;
    volatile uint32_t   type2_compare_0_word_1;
    volatile uint32_t   type2_compare_1_word_0;
    volatile uint32_t   type2_compare_1_word_1;
    volatile uint32_t   type2_compare_2_word_0;
    volatile uint32_t   type2_compare_2_word_1;
    volatile uint32_t   type2_compare_3_word_0;
    volatile uint32_t   type2_compare_3_word_1;
} GEM_REGS;

/* network_control */
#define GEM_NWCTRL_FLUSH_DPRAM  0x00040000u
#define GEM_NWCTRL_ZEROPAUSETX  0x00000800u
#define GEM_NWCTRL_PAUSETX      0x00000800u
#define GEM_NWCTRL_HALTTX       0x00000400u
#define GEM_NWCTRL_STARTTX      0x00000200u
#define GEM_NWCTRL_STATWEN      0x00000080u
#define GEM_NWCTRL_STATINC      0x00000040u
#define GEM_NWCTRL_STATCLR      0x00000020u
#define GEM_NWCTRL_MDEN         0x00000010u
#define GEM_NWCTRL_TXEN         0x00000008u
#define GEM_NWCTRL_RXEN         0x00000004u
#define GEM_NWCTRL_LOOPEN       0x00000002u

/* network_config */
#define GEM_NWCFG_BADPREAMBEN   0x20000000u
#define GEM_NWCFG_IPDSTRETCH    0x10000000u
#define GEM_NWCFG_SGMIIEN       0x08000000u
#define GEM_NWCFG_FCSIGNORE     0x04000000u
#define GEM_NWCFG_HDRXEN        0x02000000u
#define GEM_NWCFG_RXCHKSUMEN    0x01000000u
#define GEM_NWCFG_PAUSECOPYDI   0x00800000u
#define GEM_NWCFG_DWIDTH_64     0x00200000u
#define GEM_NWCFG_MDC_SHIFT       18
#define GEM_NWCFG_MDCCLKDIV     0x001C0000u
#define GEM_NWCFG_FCSREM        0x00020000u
#define GEM_NWCFG_LENERRDSCRD   0x00010000u
#define GEM_NWCFG_RXOFFS        0x0000C000u
#define GEM_NWCFG_RXOFFS_SHIFT    14
#define GEM_NWCFG_PAUSEEN       0x00002000u
#define GEM_NWCFG_RETRYTESTEN   0x00001000u
#define GEM_NWCFG_XTADDMACHEN   0x00000200u
#define GEM_NWCFG_PCSSEL        0x00000800u
#define GEM_NWCFG_1000          0x00000400u
#define GEM_NWCFG_1536RXEN      0x00000100u
#define GEM_NWCFG_UCASTHASHEN   0x00000080u
#define GEM_NWCFG_MCASTHASHEN   0x00000040u
#define GEM_NWCFG_BCASTDI       0x00000020u
#define GEM_NWCFG_COPYALLEN     0x00000010u
#define GEM_NWCFG_JUMBO         0x00000008u
#define GEM_NWCFG_NVLANDISC     0x00000004u
#define GEM_NWCFG_FDEN          0x00000002u
#define GEM_NWCFG_100           0x00000001u

/* network_status */
#define GEM_NWSR_MDIOIDLE       0x00000004u
#define GEM_NWSR_MDIO           0x00000002u

/* dma_config */
#define GEM_DMACR_ADDR_WIDTH_64 0x40000000u
#define GEM_DMACR_TXEXTEND      0x20000000u
#define GEM_DMACR_RXEXTEND      0x10000000u
#define GEM_DMACR_RXBUF         0x00FF0000u
#define GEM_DMACR_RXBUF_SHIFT     16
#define GEM_DMACR_TCPCKSUM      0x00000800u
#define GEM_DMACR_TXSIZE        0x00000400u
#define GEM_DMACR_RXSIZE        0x00000300u
#define GEM_DMACR_ENDIAN        0x00000080u
#define GEM_DMACR_BLENGTH       0x0000001Fu
#define GEM_DMACR_SINGLE_AHB_BURST  0x00000001u
#define GEM_DMACR_INCR4_AHB_BURST   0x00000004u
#define GEM_DMACR_INCR8_AHB_BURST   0x00000008u
#define GEM_DMACR_INCR16_AHB_BURST  0x00000010u

/* interrupts */
#define GEM_IXR_PTPPSTX         0x02000000u
#define GEM_IXR_PTPPDRTX        0x01000000u
#define GEM_IXR_PTPSTX          0x00800000u
#define GEM_IXR_PTPDRTX         0x00400000u
#define GEM_IXR_PTPPSRX         0x00200000u
#define GEM_IXR_PTPPDRRX        0x00100000u
#define GEM_IXR_PTPSRX          0x00080000u
#define GEM_IXR_PTPDRRX         0x00040000u
#define GEM_IXR_PAUSETX         0x00004000u
#define GEM_IXR_PAUSEZERO       0x00002000u
#define GEM_IXR_PAUSENZERO      0x00001000u
#define GEM_IXR_HRESPNOK        0x00000800u
#define GEM_IXR_RXOVR           0x00000400u
#define GEM_IXR_TXCOMPL         0x00000080u
#define GEM_IXR_TXEXH           0x00000040u
#define GEM_IXR_RETRY           0x00000020u
#define GEM_IXR_URUN            0x00000010u
#define GEM_IXR_TXUSED          0x00000008u
#define GEM_IXR_RXUSED          0x00000004u
#define GEM_IXR_FRAMERX         0x00000002u
#define GEM_IXR_MGMNT           0x00000001u

#define GEM_IXR_TX_ERR    (GEM_IXR_TXEXH|GEM_IXR_RETRY|GEM_IXR_URUN)
#define GEM_IXR_RX_ERR    (GEM_IXR_HRESPNOK|GEM_IXR_RXUSED|GEM_IXR_RXOVR)

/* q1 interrupts */
#define GEM_INTQ1SR_TXCOMPL     0x00000080u
#define GEM_INTQ1SR_TXERR       0x00000040u

/* phy_management */
#define GEM_PHYMNTNC_OP         0x40020000u
#define GEM_PHYMNTNC_OP_R       0x20000000u
#define GEM_PHYMNTNC_OP_W       0x10000000u
#define GEM_PHYMNTNC_ADDR       0x0F800000u
#define GEM_PHYMNTNC_REG        0x007C0000u
#define GEM_PHYMNTNC_DATA       0x0000FFFFu
#define GEM_PHYMNTNC_PHAD_SHIFT   23
#define GEM_PHYMNTNC_PREG_SHIFT   18

/* Clock Generator Control registers */
#define GEM0_CRL_APB  0xFF5E0050u
#define GEM1_CRL_APB  0xFF5E0054u
#define GEM2_CRL_APB  0xFF5E0058u
#define GEM3_CRL_APB  0xFF5E005Cu

#define CRL_APB_GEM_DIV0        0x00003F00u
#define CRL_APB_GEM_DIV0_SHIFT    8
#define CRL_APB_GEM_DIV1        0x003F0000u
#define CRL_APB_GEM_DIV1_SHIFT    16

#endif /* NX_DRIVER_ZYNQMP_GEM_REGS_H */
