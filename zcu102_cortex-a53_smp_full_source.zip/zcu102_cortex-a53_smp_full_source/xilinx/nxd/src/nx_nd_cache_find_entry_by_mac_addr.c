/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Neighbor Discovery Cache                                            */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_ipv6.h"
#include "nx_nd_cache.h"

#ifdef FEATURE_NX_IPV6


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    nx_nd_cache_find_entry_by_mac_addr                  PORTABLE C      */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This internal function finds an entry in the ND cache that is       */
/*    mapped to the specified MAC address.                                */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                   Pointer to IP instance                     */
/*    physical_msw             Physical address, most significant word    */
/*    physical_lsw             Physical address, least significant word   */
/*    nd_cache_entry           User specified storage space for pointer to*/
/*                               the corresponding ND cache.              */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                   NX_SUCCESS: The ND cache entry is located. */
/*                                nd_cache_entry contains valid value.    */
/*                             NX_NOT_SUCCESSFUL:  The ND cache entry     */
/*                                cannot be found, or nd_cache_entry is   */
/*                                NULL.                                   */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    tx_mutex_get             Obtain protection mutex                    */
/*    tx_mutex_put             Release protection mutex                   */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    _nxd_nd_cache_ip_address_find  User level service                   */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-30-2007     Yuxin Zhou               Initial Version 5.2           */
/*  08-03-2009     Yuxin Zhou               Modified comment(s), and added*/
/*                                            logic for trace support,    */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            modified struct field names */
/*                                            missing struct name prefix, */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s), added a  */
/*                                            check to make sure this     */
/*                                            function only operates on   */
/*                                            an entry owned by ip_ptr,   */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s), added    */
/*                                            the interface pointer check */
/*                                            to avoid crash,             */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            removed unreachable code,   */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s), and      */
/*                                            moved the destination table */
/*                                            to the IP structure,        */
/*                                            resulting in version 5.11   */
/*                                                                        */
/**************************************************************************/
UINT _nx_nd_cache_find_entry_by_mac_addr(NX_IP *ip_ptr, ULONG physical_msw,
                                         ULONG physical_lsw, ND_CACHE_ENTRY **nd_cache_entry)
{
INT   i;
ULONG mac_msw, mac_lsw;

    /* Initialize the return value. */
    *nd_cache_entry = NX_NULL;

    /* Loop to match the physical address.  */
    for (i = 0; i < NX_IPV6_NEIGHBOR_CACHE_SIZE; i++)
    {

        /* Check the interface pointer.  */
        if (ip_ptr -> nx_ipv6_nd_cache[i].nx_nd_cache_interface_ptr == NX_NULL)
        {
            continue;
        }

        /* Check the ND CACHE status.  */
        if (ip_ptr -> nx_ipv6_nd_cache[i].nx_nd_cache_nd_status == ND_CACHE_STATE_INVALID)
        {
            continue;
        }

        /* Set the physical address.  */
        mac_msw = ((ULONG)ip_ptr -> nx_ipv6_nd_cache[i].nx_nd_cache_mac_addr[0] << 8) | ip_ptr -> nx_ipv6_nd_cache[i].nx_nd_cache_mac_addr[1];
        mac_lsw = ((ULONG)ip_ptr -> nx_ipv6_nd_cache[i].nx_nd_cache_mac_addr[2] << 24) | ((ULONG)ip_ptr -> nx_ipv6_nd_cache[i].nx_nd_cache_mac_addr[3] << 16) |
            ((ULONG)ip_ptr -> nx_ipv6_nd_cache[i].nx_nd_cache_mac_addr[4] << 8) | ip_ptr -> nx_ipv6_nd_cache[i].nx_nd_cache_mac_addr[5];

        /* Check the physical address.  */
        if ((mac_msw == physical_msw) && (mac_lsw == physical_lsw))
        {

            /* Find a match */
            *nd_cache_entry = &ip_ptr -> nx_ipv6_nd_cache[i];

            return(NX_SUCCESS);
        }
    }

    return(NX_NOT_SUCCESSFUL);
}

#endif /* FEATURE_NX_IPV6 */

