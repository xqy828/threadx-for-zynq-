/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2017 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** FileX Component                                                       */
/**                                                                       */
/**   Unicode                                                             */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define FX_SOURCE_CODE


/* Include necessary system files.  */

#include "fx_api.h"
#include "fx_unicode.h"
#include "fx_utility.h"
#include "tx_thread.h"


/* Define several Unicode working arrays...  This keeps the data structures
   off the local stack.  */

UCHAR _fx_unicode_temp_long_file_name[FX_MAX_LONG_NAME_LEN];
UCHAR _fx_unicode_search_name[FX_MAX_LONG_NAME_LEN * 2];


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _fx_unicode_directory_search                        PORTABLE C      */
/*                                                           5.5          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function searches for the specified unicode or short name.     */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    media_ptr                             Pointer to media              */
/*    short_name                            Pointer to short name         */
/*    unicode_name                          Pointer to unicode name       */
/*    unicode_name_length                   Unicode name length           */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    Completion Status                                                   */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _fx_unicode_directory_entry_read      Read a full unicode directory */
/*                                            entry                       */
/*    _fx_utility_FAT_entry_read            Read a FAT entry              */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Unicode Utilities                                                   */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-12-2005     William E. Lamie         Initial version 5.0           */
/*  07-18-2007     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.1    */
/*  03-01-2009     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.2    */
/*  11-01-2015     William E. Lamie         Modified comment(s),          */
/*                                            used FAT reserved and FAT   */
/*                                            last from media structure,  */
/*                                            fixed data compare between  */
/*                                            singed and unsigned char,   */
/*                                            resulting in version 5.3    */
/*  04-15-2016     William E. Lamie         Modified comment(s),          */
/*                                            cleaned up the code,        */
/*                                            resulting in version 5.4    */
/*  04-03-2017     William E. Lamie         Modified comment(s),          */
/*                                            fixed compiler warnings,    */
/*                                            removed unreachable         */
/*                                            branches,                   */
/*                                            resulting in version 5.5    */
/*                                                                        */
/**************************************************************************/
UINT  _fx_unicode_directory_search(FX_MEDIA *media_ptr, FX_DIR_ENTRY *entry_ptr,
                                   UCHAR *short_name, UCHAR *unicode_name, ULONG *unicode_name_length)
{

ULONG         i, j;
UINT          status, found;
ULONG         cluster, next_cluster = 0;
ULONG         directory_size;
FX_DIR_ENTRY  search_dir;
FX_DIR_ENTRY *search_dir_ptr;
ULONG         unicode_search_length;
ULONG         local_unicode_name_length;
CHAR          unicode_to_short_name[13];
CHAR         *short_name_ptr;


    /* Setup temp unicode name length.  */
    local_unicode_name_length =  *unicode_name_length;

#ifndef FX_MEDIA_STATISTICS_DISABLE

    /* Increment the number of directory search requests.  */
    media_ptr -> fx_media_directory_searches++;
#endif

    /* Set the initial search directory to the current working
       directory - if there is one.  */

    /* First check for a local path pointer stored in the thread control block.  This
       is only available in ThreadX Version 4 and above.  */
#ifndef FX_NO_LOCAL_PATH
    if (_tx_thread_current_ptr -> tx_thread_filex_ptr)
    {

        /* Determine if the local directory is not the root directory.  */
        if (((FX_PATH *)_tx_thread_current_ptr -> tx_thread_filex_ptr) -> fx_path_directory.fx_dir_entry_name[0])
        {

            /* Start at the current working directory of the media.  */
            search_dir =   ((FX_PATH *)_tx_thread_current_ptr -> tx_thread_filex_ptr) -> fx_path_directory;

            /* Set the internal pointer to the search directory as well.  */
            search_dir_ptr =  &search_dir;
        }
        else
        {

            /* We are searching in the root directory.  */
            search_dir_ptr =  FX_NULL;
        }
    }
    else
#endif
    if (media_ptr -> fx_media_default_path.fx_path_directory.fx_dir_entry_name[0])
    {

        /* Start at the current working directory of the media.  */
        search_dir =  media_ptr -> fx_media_default_path.fx_path_directory;

        /* Set the internal pointer to the search directory as well.  */
        search_dir_ptr =  &search_dir;
    }
    else
    {

        /* The current default directory is the root so just set the
           search directory pointer to NULL.  */
        search_dir_ptr =  FX_NULL;
    }

    /* Calculate the directory size.  */
    if (search_dir_ptr)
    {

        /* Ensure that the search directory's last search cluster is cleared.  */
        search_dir_ptr -> fx_dir_entry_last_search_cluster =  0;

        /* Calculate the directory size by counting the allocated
           clusters for it.  */
        i =        0;
        cluster =  search_dir_ptr -> fx_dir_entry_cluster;
        while ((cluster >= FX_FAT_ENTRY_START) && (cluster < media_ptr -> fx_media_fat_reserved))
        {

            /* Increment the cluster count.  */
            i++;

            /* Read the next FAT entry.  */
            status =  _fx_utility_FAT_entry_read(media_ptr, cluster, &next_cluster);

            /* Check the return status.  */
            if (status != FX_SUCCESS)
            {

                /* Return the bad status.  */
                return(status);
            }

            /* Check for error situation.  */
            if ((cluster == next_cluster) || (i > media_ptr -> fx_media_total_clusters))
            {

                /* Return the bad status.  */
                return(FX_FAT_READ_ERROR);
            }

            cluster = next_cluster;
        }

        /* Now we can calculate the directory size.  */
        directory_size =  (((ULONG)media_ptr -> fx_media_bytes_per_sector) *
                           ((ULONG)media_ptr -> fx_media_sectors_per_cluster) * i) /
                           (ULONG)FX_DIR_ENTRY_SIZE;

        /* Also save this in the directory entry so we don't have to
           calculate it later.  */
        search_dir_ptr -> fx_dir_entry_file_size =  directory_size;
    }
    else
    {

        /* Directory size is the number of entries in the root directory.  */
        directory_size =  (ULONG)media_ptr -> fx_media_root_directory_entries;
    }

    /* Determine if we are searching for a short file name or a unicode file name.  */
    if (short_name[0] == 0)
    {

        /* If the unicode name fit into short name length, covert the Unicode to ASCII if possible.  */
        if (local_unicode_name_length <= 13)
        {
            for (j = 0; j < local_unicode_name_length; j++)
            {
                if ((unicode_name[j * 2] <= 0x7F) && (unicode_name[j * 2 + 1] == 0))
                {

                    unicode_to_short_name[j] = (CHAR)unicode_name[j * 2];
                    if ((unicode_to_short_name[j] >= 'a') && (unicode_to_short_name[j] <= 'z'))
                    {

                        /* Lower case, convert to upper case!  */
                        unicode_to_short_name[j] =  (CHAR)((INT)unicode_to_short_name[j] - 0x20);
                    }
                }
                else
                {
                    unicode_to_short_name[0] = 0;
                    break;
                }
            }
        }
        else
        {
            unicode_to_short_name[0] = 0;
        }
    }
    else
    {
        unicode_to_short_name[0] = 0;
    }

    /* Loop through entries in the directory.  Yes, this is a
       linear search!  */
    i =      0;
    do
    {

        /* Read an entry from the directory.  */
        status =  _fx_unicode_directory_entry_read(media_ptr, search_dir_ptr, &i, entry_ptr, &_fx_unicode_search_name[0], &unicode_search_length);
        i++;

        /* Check for error status.  */
        if (status != FX_SUCCESS)
        {
            return(status);
        }

        /* Determine if this is an empty entry.  */
        if (((UCHAR)entry_ptr -> fx_dir_entry_name[0] == (UCHAR)FX_DIR_ENTRY_FREE) && (entry_ptr -> fx_dir_entry_short_name[0] == 0))
        {
            continue;
        }

        /* Determine if this is the last directory entry.  */
        if ((UCHAR)entry_ptr -> fx_dir_entry_name[0] == (UCHAR)FX_DIR_ENTRY_DONE)
        {
            break;
        }

        /* Determine if there is a short name to match.  */
        if (unicode_to_short_name[0])
        {

            /* Get the short name pointer.  */
            if (entry_ptr -> fx_dir_entry_short_name[0])
            {
                short_name_ptr =  entry_ptr -> fx_dir_entry_short_name;
            }
            else
            {
                short_name_ptr =  entry_ptr -> fx_dir_entry_name;
            }

            for (j = 0; j < local_unicode_name_length; j++)
            {

                /* Compare characters.  */
                if (short_name_ptr[j] != unicode_to_short_name[j])
                {
                    break;
                }
            }
            if (j == local_unicode_name_length)
            {

                /* The names match, copy the short name into the destination.  */
                for (j = 0; j < 13; j++)
                {
                    short_name[j] = (UCHAR)short_name_ptr[j];
                }

                /* Return success to caller.  */
                return(FX_SUCCESS);
            }
        }

        /* Determine if this is not a unicode name.  */
        if (unicode_search_length == 0)
        {
            continue;
        }

        /* Determine if we are searching for a short file name or a unicode file name.  */
        if (short_name[0])
        {

            /* We have a short name and need a unicode name.  Compare the short name against the short name in
               the directory entry for a match.  */
            found =  FX_TRUE;
            for (j = 0; j < 12; j++)
            {

                /* Compare characters...  */
                if (entry_ptr -> fx_dir_entry_short_name[0])
                {

                    /* Yes, the return name is in the short name field... compare against it!  */
                    if (short_name[j] != (UCHAR)entry_ptr -> fx_dir_entry_short_name[j])
                    {

                        found = FX_FALSE;
                        break;
                    }
                }
                else
                {

                    /* No, the return name is in the name field... compare against it!  */
                    if (short_name[j] != (UCHAR)entry_ptr -> fx_dir_entry_name[j])
                    {

                        found = FX_FALSE;
                        break;
                    }
                }

                /* Are we done?  */
                if (short_name[j] == (UCHAR)FX_NULL)
                {
                    break;
                }
            }

            /* One final compare to see if we have a match.  */
            if ((found == FX_FALSE) || ((j == 12) && (short_name[12] != 0)))
            {
                continue;
            }

            /* A match was found so copy the unicode name and length and return.  */
            for (j = 0; j < unicode_search_length * 2; j++)
            {

                /* Copy one unicode character to the destination...  */
                unicode_name[j] =  _fx_unicode_search_name[j];
            }

            /* Make sure there is a NULL in the destination.  */
            unicode_name[j] =    (UCHAR)0;
            unicode_name[j + 1] =  (UCHAR)0;

            /* Copy the length.  */
            *unicode_name_length =  unicode_search_length;

            /* Return successful completion.  */
            return(FX_SUCCESS);
        }
        else
        {

            /* Determine if this is the correct unicode name.  */
            if (unicode_search_length != local_unicode_name_length)
            {
                continue;
            }

            /* Compare the unicode search name with the requested unicode name.  */
            for (j = 0; j < (local_unicode_name_length * 2); j = j + 2)
            {

                /* Compare bytes of each unicode name.  */
                if (unicode_name[j] != _fx_unicode_search_name[j])
                {

                    /* Not match, Check if the character is in ASCII range.  */
                    if ((_fx_unicode_search_name[j + 1] == 0) && (unicode_name[j + 1] == 0))
                    {

                        /* Check if it is case mismatch.  */
                        if ((unicode_name[j]) >= 'a' && (unicode_name[j] <= 'z'))
                        {
                            if ((unicode_name[j] - 0x20) == _fx_unicode_search_name[j])
                            {
                                continue;
                            }
                        }
                        if ((_fx_unicode_search_name[j]) >= 'a' && (_fx_unicode_search_name[j] <= 'z'))
                        {
                            if ((_fx_unicode_search_name[j] - 0x20) == unicode_name[j])
                            {
                                continue;
                            }
                        }
                    }

                    break;
                }

                /* Compare the next byte.  */
                if (unicode_name[j + 1] != _fx_unicode_search_name[j + 1])
                {
                    break;
                }
            }

            /* Determine if the names do not match.  */
            if (j != (local_unicode_name_length * 2))
            {
                continue;
            }

            /* Otherwise, the names match, copy the short name into the destination.  */
            for (j = 0; j < 13; j++)
            {

                /* Copy a character.  */
                if (entry_ptr -> fx_dir_entry_short_name[0])
                {
                    short_name[j] =  (UCHAR)entry_ptr -> fx_dir_entry_short_name[j];
                }
                else
                {
                    short_name[j] =  (UCHAR)entry_ptr -> fx_dir_entry_name[j];
                }
            }

            /* Return success to caller.  */
            return(FX_SUCCESS);
        }
    } while (i < directory_size);

    /* Return not found.  */
    return(FX_NOT_FOUND);
}

