/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2017 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** FileX Component                                                       */
/**                                                                       */
/**   Directory                                                           */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/
#define FX_SOURCE_CODE


/* Include necessary system files.  */

#include "fx_api.h"

#ifdef FX_ENABLE_EXFAT
#include "fx_directory.h"


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _fx_directory_exFAT_entry_write                     PORTABLE C      */
/*                                                           5.5          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function writes the supplied directory entry to the specified  */
/*    logical sector and offset.                                          */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    media_ptr                             Media control block pointer   */
/*    entry_ptr                             Pointer to directory entry    */
/*    update_level                          Update level for entry write  */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    return status                                                       */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _fx_directory_exFAT_unicode_entry_write                             */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    fx_directory_attributes_set                                         */
/*    fx_directory_create                                                 */
/*    fx_directory_delete                                                 */
/*    fx_directory_exFAT_unicode_entry_write                              */
/*    fx_directory_rename                                                 */
/*    fx_file_allocate                                                    */
/*    fx_file_attributes_set                                              */
/*    fx_file_best_effort_allocate                                        */
/*    fx_file_close                                                       */
/*    fx_file_create                                                      */
/*    fx_file_date_time_set                                               */
/*    fx_file_delete                                                      */
/*    fx_file_rename                                                      */
/*    fx_file_truncate_release                                            */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  11-01-2015     William E. Lamie         Initial Version 5.3           */
/*  04-15-2016     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  04-03-2017     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.5    */
/*                                                                        */
/**************************************************************************/
UINT  _fx_directory_exFAT_entry_write(FX_MEDIA *media_ptr, FX_DIR_ENTRY *entry_ptr, UCHAR update_level)
{

UINT status;


    /* Call the unicode director entry write function.  */
    status =  _fx_directory_exFAT_unicode_entry_write(media_ptr, entry_ptr, update_level, NULL, 0);

    /* Return completion status.  */
    return(status);
}

#endif

