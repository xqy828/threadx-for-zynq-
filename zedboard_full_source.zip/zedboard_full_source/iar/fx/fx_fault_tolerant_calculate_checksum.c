/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2017 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** FileX Component                                                       */
/**                                                                       */
/**   Fault Tolerant                                                      */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define FX_SOURCE_CODE

#include "fx_api.h"
#include "fx_fault_tolerant.h"
#include "fx_utility.h"


#ifdef FX_ENABLE_FAULT_TOLERANT
/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _fx_fault_tolerant_calculate_checksum               PORTABLE C      */
/*                                                           5.5          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function calculates checksum for consecutive data.  The size   */
/*    of the log file is required to be 4-byte aligned.  Therefore this   */
/*    checksum routine is able to perform 4-byte access.                  */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    data                                  Pointer to data               */
/*    len                                   Data length                   */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    Computed checksum value                                             */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*     _fx_utility_32_unsigned_read         Read a UINT from memory       */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    _fx_fault_tolerant_enable                                           */
/*    _fx_fault_tolerant_cleanup_FAT_chain                                */
/*    _fx_fault_tolerant_reset_log_file                                   */
/*    _fx_fault_tolerant_set_FAT_chain                                    */
/*    _fx_fault_tolerant_transaction_end                                  */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  11-01-2015     William E. Lamie         Initial Version 5.3           */
/*  04-15-2016     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  04-03-2017     William E. Lamie         Modified comment(s),          */
/*                                            fixed compiler warnings,    */
/*                                            resulting in version 5.5    */
/*                                                                        */
/**************************************************************************/
USHORT  _fx_fault_tolerant_calculate_checksum(UCHAR *data, UINT len)
{
ULONG checksum = 0;
ULONG long_value;

    while (len >= 4)
    {

        /* Read first long value. */
        long_value = _fx_utility_32_unsigned_read(data);

        /* Calculate checksum. */
        checksum += (long_value >> 16) + (long_value & 0xFFFF);

        /* Decrease length. */
        len -= sizeof(ULONG);
        data += sizeof(ULONG);
    }

    /* Trim high 16 bits of checksum. */
    checksum = (checksum & 0xFFFF) + (checksum >> 16);
    checksum = (checksum & 0xFFFF) + (checksum >> 16);

    return((USHORT)((~checksum) & 0xFFFF));
}
#endif /* FX_ENABLE_FAULT_TOLERANT */

