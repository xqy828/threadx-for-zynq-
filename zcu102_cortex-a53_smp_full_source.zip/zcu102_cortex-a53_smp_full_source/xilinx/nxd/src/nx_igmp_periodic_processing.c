/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Group Management Protocol (IGMP)                           */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_igmp.h"

#ifndef NX_DISABLE_IPV4
/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_igmp_periodic_processing                        PORTABLE C      */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function handles the sending of periodic processing of IGMP    */
/*    join report messages.                                               */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                IP instance pointer           */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    nx_igmp_interface_report_send         Send IGMP group report        */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    _nx_ip_thread_entry                   IP helper thread              */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-12-2005     William E. Lamie         Initial Version 5.0           */
/*  08-09-2007     William E. Lamie         Modified comment(s), and      */
/*                                            optimized the checksum      */
/*                                            logic, resulting in         */
/*                                            version 5.1                 */
/*  12-30-2007     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.2    */
/*  07-25-2008     Janet Christiansen       Added support for IGMPv2      */
/*  08-03-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Removed internal debug logic, */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s), added    */
/*                                            support for multihome,      */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Janet Christiansen       Modified comment(s), and      */
/*                                            fixed a bug preventing the  */
/*                                            loop from decrementing all  */
/*                                            group update times, added   */
/*                                            device capability support,  */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s), and      */
/*                                            added router alert feature, */
/*                                            supported IPv4 multicast,   */
/*                                            optimized NX_PACKET_STRUCT, */
/*                                            added dual packet pool      */
/*                                            support, used a data        */
/*                                            structure to encapsulate all*/
/*                                            IGMP-related info,          */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            supported packet debugging, */
/*                                            removed unused logic,       */
/*                                            renamed symbols,            */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            cleaned up internal logic,  */
/*                                            fixed the bug for adding    */
/*                                            packet debug information,   */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Janet Christiansen       Modified comment(s), and      */
/*                                            optimized logic for sending */
/*                                            IGMP reports, added support */
/*                                            for disabling IPv4 feature, */
/*                                            resulting in version 5.11   */
/*                                                                        */
/**************************************************************************/
VOID  _nx_igmp_periodic_processing(NX_IP *ip_ptr)
{

UINT          i;
UINT          status;
UINT          sent_count = 0;
NX_INTERFACE *interface_ptr;
UINT          interface_index;


    /* Search the multicast join list for pending IGMP responses.  */
    for (i = 0; i < NX_MAX_MULTICAST_GROUPS; i++)
    {

        /* Determine if the specified entry is active.  */
        if (ip_ptr -> nx_ipv4_multicast_entry[i].nx_ipv4_multicast_join_list)
        {

            /* Now determine if a response is pending.  */
            if ((ip_ptr -> nx_ipv4_multicast_entry[i].nx_ipv4_multicast_update_time > 0) &&
                (ip_ptr -> nx_ipv4_multicast_entry[i].nx_ipv4_multicast_update_time != NX_WAIT_FOREVER))
            {

                /* Yes, it is active.  Decrement and check for expiration.  */
                ip_ptr -> nx_ipv4_multicast_entry[i].nx_ipv4_multicast_update_time--;

                /* We don't want to decrement a join group if we cannot send it. Check
                   if we've already sent a packet on this periodic. */
                if ((ip_ptr -> nx_ipv4_multicast_entry[i].nx_ipv4_multicast_update_time == 0) && (sent_count > 0))
                {

                    /* Restore the timeout to 1 second because we cannot send on this periodic; we've already sent out a packet. */
                    ip_ptr -> nx_ipv4_multicast_entry[i].nx_ipv4_multicast_update_time = 1;
                }

                /* Has time expired and have we not sent an IGMP report in this period?  */
                if (ip_ptr -> nx_ipv4_multicast_entry[i].nx_ipv4_multicast_update_time == 0)
                {

                    /* Yes, time has expired and we have not yet sent a packet out on this periodic. */

                    /* Build and send the join report packet. */
                    interface_ptr = ip_ptr -> nx_ipv4_multicast_entry[i].nx_ipv4_multicast_join_interface_list;

                    interface_index = (UINT)interface_ptr -> nx_interface_index;

                    /* Build a IGMP host response packet for a join report and send it!  */
                    status = _nx_igmp_interface_report_send(ip_ptr, ip_ptr -> nx_ipv4_multicast_entry[i].nx_ipv4_multicast_join_list,
                                                            interface_index, NX_TRUE);

                    if (status == NX_SUCCESS)
                    {

                        /* Update the sent count. Only one report sent per IP periodic. */
                        sent_count++;
                    }
                }
            }
        }
    }
}
#endif /* !NX_DISABLE_IPV4  */

