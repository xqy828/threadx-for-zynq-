/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2017 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** FileX Component                                                       */
/**                                                                       */
/**   Utility                                                             */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/
#define FX_SOURCE_CODE

/* Include necessary system files.  */

#include "fx_api.h"


#ifdef FX_ENABLE_EXFAT
#include "fx_system.h"
#include "fx_media.h"
#include "fx_utility.h"
#include "fx_directory_exFAT.h"
#ifdef FX_ENABLE_FAULT_TOLERANT
#include "fx_fault_tolerant.h"
#endif /* FX_ENABLE_FAULT_TOLERANT */


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _fx_utility_exFAT_cluster_state_get                 PORTABLE C      */
/*                                                           5.5          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function gets the cluster state of exFAT volume.               */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    media_ptr                             Media control block pointer   */
/*    cluster                               Cluster number                */
/*    cluster_state                         UCHAR pointer to store state  */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    return status                                                       */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _fx_utility_exFAT_bitmap_cache_prepare                              */
/*                                          Read bitmap to cache          */
/*    _fx_fault_tolerant_read_FAT           Read FAT entry from log file  */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    FileX System Functions                                              */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  11-01-2015     William E. Lamie         Initial Version 5.3           */
/*  04-15-2016     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  04-03-2017     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.5    */
/*                                                                        */
/**************************************************************************/
UINT  _fx_utility_exFAT_cluster_state_get(FX_MEDIA *media_ptr, ULONG cluster, UCHAR *cluster_state)
{

UINT  status;
UINT  bitmap_offset;
UCHAR cluster_shift;
UCHAR eight_clusters_block;
#ifdef FX_ENABLE_FAULT_TOLERANT
ULONG value;

    if (media_ptr -> fx_media_fault_tolerant_enabled &&
        (media_ptr -> fx_media_fault_tolerant_state & FX_FAULT_TOLERANT_STATE_STARTED))
    {


        /* Redirect this request to the log file.
           During file or directory operations with Fault Tolerant
           protection, intermediate operations are written to the fault
           tolerant log file.  Therefore, FAT-entry read should search for
           fault tolerant log before the request can be passed to normal FAT
           entry read routine.
         */
        status = _fx_fault_tolerant_read_FAT(media_ptr, cluster, &value, FX_FAULT_TOLERANT_BITMAP_LOG_TYPE);

        /* Return on success. */
        if (status != FX_READ_CONTINUE)
        {
            *cluster_state = (UCHAR)value;
            return(status);
        }
    }
#endif /* FX_ENABLE_FAULT_TOLERANT */

    /* Prepare bitmap cache.  */
    status = _fx_utility_exFAT_bitmap_cache_prepare(media_ptr, cluster);

    /* Was it successful?  */
    if (status == FX_SUCCESS)
    {

        /* Calculate the bitmap offset.  */
        bitmap_offset = (UINT)(cluster - media_ptr -> fx_media_exfat_bitmap_cache_start_cluster) >> BITS_PER_BYTE_SHIFT;

        /* Pickup the 8 cluster block.  */
        eight_clusters_block = *(media_ptr -> fx_media_exfat_bitmap_cache + bitmap_offset);

        /* Check all 8 bits for 0x00 (all clusters in the block are free).  */
        if (eight_clusters_block == 0x00)
        {

            /* Cluster is free, return state.  */
            *cluster_state = FX_EXFAT_BITMAP_CLUSTER_FREE;
        }
        /* Check all 8 bits for 0xFF (all 8 clusters are occupied).  */
        else if (0xFF == eight_clusters_block)
        {

            /* Cluster is not free, return state.  */
            *cluster_state = FX_EXFAT_BITMAP_CLUSTER_OCCUPIED;
        }
        else
        {

            /* Check bit respondent for cluster state.  */
            cluster_shift = (UCHAR)((cluster - FX_FAT_ENTRY_START) % BITS_PER_BYTE);

            *cluster_state = (eight_clusters_block >> cluster_shift) & 0x1;
        }
    }

    /* Return status.  */
    return(status);
}

#endif /* FX_ENABLE_EXFAT */

