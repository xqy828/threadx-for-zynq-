/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2017 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** FileX Component                                                       */
/**                                                                       */
/**   Fault Tolerant                                                      */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define FX_SOURCE_CODE

#include "fx_api.h"
#include "fx_utility.h"
#include "fx_directory.h"
#include "fx_fault_tolerant.h"


#ifdef FX_ENABLE_FAULT_TOLERANT
/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _fx_fault_tolerant_enable                           PORTABLE C      */
/*                                                           5.5          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function enables the FileX Fault Tolerant feature. It first    */
/*    searches for a valid log file.  A valid log file indicates the      */
/*    previous write operation failed, and appropriate action now must    */
/*    be taken to restore the integrity of the file system.  Once the     */
/*    recovery effort is completed, the file system is properly restored. */
/*    An empty log file indicates the previous write operaiton was        */
/*    successfully completed and no action needs to be taken at this      */
/*    point.  If the file system does not have a log file, or the         */
/*    checksum is not valid, it is an indication either the file system   */
/*    is not under the protection of FileX Fault Tolerant.  A new log     */
/*    file is created.                                                    */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    media_ptr                             Media control block pointer   */
/*    memory_buffer                         Pointer to memory buffer.     */
/*    memory_size                           Size of memory buffer.        */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    return status                                                       */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _fx_fault_tolerant_calculate_checksum Compute Checksum of data      */
/*    _fx_fault_tolerant_apply_logs         Apply logs into file system   */
/*    _fx_fault_tolerant_recover            Recover FAT chain             */
/*    _fx_fault_tolerant_reset_log_file     Reset the log file            */
/*    _fx_fault_tolerant_read_log_file      Read log file to cache        */
/*    _fx_utility_exFAT_cluster_state_get   Get state of exFAT cluster    */
/*    _fx_utility_FAT_entry_read            Read a FAT entry              */
/*    _fx_utility_16_unsigned_read          Read a USHORT from memory     */
/*    _fx_utility_32_unsigned_read          Read a ULONG from memory      */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  11-01-2015     William E. Lamie         Initial Version 5.3           */
/*  04-15-2016     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  04-03-2017     William E. Lamie         Modified comment(s),          */
/*                                            fixed a bug that mutex was  */
/*                                            not released before return, */
/*                                            resulting in version 5.5    */
/*                                                                        */
/**************************************************************************/
UINT  _fx_fault_tolerant_enable(FX_MEDIA *media_ptr, VOID *memory_buffer, UINT memory_size)
{
ULONG                         start_cluster;
ULONG                         FAT_value;
UINT                          status;
ULONG                         checksum;
ULONG                         total_size;
FX_FAULT_TOLERANT_LOG_HEADER *log_header;
FX_FAULT_TOLERANT_FAT_CHAIN  *FAT_chain;

    /* Check cluster requirement. */
    if (media_ptr -> fx_media_bytes_per_sector * media_ptr -> fx_media_sectors_per_cluster < FX_FAULT_TOLERANT_MINIMAL_CLUSTER)
    {
        return(FX_NOT_ENOUGH_MEMORY);
    }

    /* Check buffer size requirement. */
    if (memory_size < FX_FAULT_TOLERANT_MINIMAL_BUFFER_SIZE)
    {
        return(FX_NOT_ENOUGH_MEMORY);
    }

    /* Protect against other threads accessing the media.  */
    FX_PROTECT

    /* Store memory buffer and size. */
    media_ptr -> fx_media_fault_tolerant_memory_buffer = (UCHAR *)memory_buffer;

    /* Read the boot sector from the device.  */
    media_ptr -> fx_media_driver_request =          FX_DRIVER_BOOT_READ;
    media_ptr -> fx_media_driver_status =           FX_IO_ERROR;
    media_ptr -> fx_media_driver_buffer =           (UCHAR *)memory_buffer;
    media_ptr -> fx_media_driver_sectors =          1;
    media_ptr -> fx_media_driver_sector_type =      FX_BOOT_SECTOR;

    /* If trace is enabled, insert this event into the trace buffer.  */
    FX_TRACE_IN_LINE_INSERT(FX_TRACE_INTERNAL_IO_DRIVER_BOOT_READ, media_ptr, memory_buffer, 0, 0, FX_TRACE_INTERNAL_EVENTS, 0, 0)

    /* Invoke the driver to read the boot sector.  */
    (media_ptr -> fx_media_driver_entry) (media_ptr);

    /* Determine if the boot sector was read correctly. */
    if (media_ptr -> fx_media_driver_status != FX_SUCCESS)
    {

        /* Release media protection.  */
        FX_UNPROTECT

        /* Return the boot sector error status.  */
        return(FX_BOOT_ERROR);
    }

    /* Check whether the boot index is used. */
    start_cluster = _fx_utility_32_unsigned_read((UCHAR *)memory_buffer + FX_FAULT_TOLERANT_BOOT_INDEX);
    if (start_cluster != 0)
    {

        /* The location of the fault tolerant log file is found.  Need to verify the integrity of the log file. */
        if ((start_cluster >= FX_FAT_ENTRY_START) && (start_cluster < media_ptr -> fx_media_fat_reserved))
        {

            /* Check whether this cluster is used. */
#ifdef FX_ENABLE_EXFAT
            if (media_ptr -> fx_media_FAT_type == FX_exFAT)
            {
            UCHAR cluste_state;

                /* Update Bitmap */
                status = _fx_utility_exFAT_cluster_state_get(media_ptr, start_cluster, &cluste_state);

                /* Check for a bad status.  */
                if (status != FX_SUCCESS)
                {

                    /* Release media protection.  */
                    FX_UNPROTECT

                    /* Return the bad status.  */
                    return(status);
                }

                if (cluste_state != FX_EXFAT_BITMAP_CLUSTER_OCCUPIED)
                {

                    /* Mark invalid. */
                    start_cluster = media_ptr -> fx_media_fat_reserved;
                }
            }
            else
            {
#endif /* FX_ENABLE_EXFAT */

                /* Read FAT entry.  */
                status =  _fx_utility_FAT_entry_read(media_ptr, start_cluster, &FAT_value);

                /* Check for a bad status.  */
                if (status != FX_SUCCESS)
                {

                    /* Release media protection.  */
                    FX_UNPROTECT

                    /* Return the bad status.  */
                    return(status);
                }

                if (FAT_value != media_ptr -> fx_media_fat_last)
                {

                    /* Mark invalid. */
                    start_cluster = media_ptr -> fx_media_fat_reserved;
                }
#ifdef FX_ENABLE_EXFAT
            }
#endif /* FX_ENABLE_EXFAT */

            /* Is this FAT entry occupied by log file? */
            if (start_cluster != media_ptr -> fx_media_fat_reserved)
            {

                /* Set the start cluster. */
                media_ptr -> fx_media_fault_tolerant_start_cluster = start_cluster;

                /* Read log file from file system to memory. */
                status = _fx_fault_tolerant_read_log_file(media_ptr);

                /* Check for good completion status.  */
                if (status !=  FX_SUCCESS)
                {

                    /* Release media protection.  */
                    FX_UNPROTECT

                    /* Return the error status.  */
                    return(status);
                }

                /* Set log header and FAT chain pointer. */
                log_header = (FX_FAULT_TOLERANT_LOG_HEADER *)media_ptr -> fx_media_fault_tolerant_memory_buffer;
                FAT_chain = (FX_FAULT_TOLERANT_FAT_CHAIN *)(media_ptr -> fx_media_fault_tolerant_memory_buffer +
                                                            FX_FAULT_TOLERANT_FAT_CHAIN_OFFSET);

                /* Verify ID field. */
                if (_fx_utility_32_unsigned_read((UCHAR *)&log_header -> fx_fault_tolerant_log_header_id) == FX_FAULT_TOLERANT_ID)
                {

                    /* Calculate checksum of log header. */
                    checksum = _fx_fault_tolerant_calculate_checksum((UCHAR *)log_header,
                                                                     FX_FAULT_TOLERANT_LOG_HEADER_SIZE);

                    if (checksum == 0)
                    {

                        /* Fault tolerant log file is valid. */
                        /* Initialize file size. */
                        total_size = _fx_utility_16_unsigned_read((UCHAR *)&log_header -> fx_fault_tolerant_log_header_total_size);
                        media_ptr -> fx_media_fault_tolerant_file_size = total_size;


                        /* Verify the checksum of the FAT chain. */
                        checksum = _fx_fault_tolerant_calculate_checksum((UCHAR *)FAT_chain,
                                                                         FX_FAULT_TOLERANT_FAT_CHAIN_SIZE);

                        if (checksum == 0)
                        {

                            /* Checksum of FAT chain is correct. */

                            if (total_size > (FX_FAULT_TOLERANT_LOG_CONTENT_OFFSET + FX_FAULT_TOLERANT_LOG_HEADER_SIZE))
                            {

                                /* Log content is present. */
                                /* Now verify the checksum of log content. */
                                checksum = _fx_fault_tolerant_calculate_checksum((media_ptr -> fx_media_fault_tolerant_memory_buffer +
                                                                                  FX_FAULT_TOLERANT_LOG_CONTENT_OFFSET),
                                                                                 (total_size - FX_FAULT_TOLERANT_LOG_CONTENT_OFFSET));
                                if (checksum == 0)
                                {

                                    /* Checksum of log content is correct. */

                                    /* This is the situation where the log file contains log entries.  This is an indication
                                       that previous write operation did not complete successfully.  Need to apply the log entries
                                       to recover the previous write operation, effectively to finish up the previous write operation. */
                                    status = _fx_fault_tolerant_apply_logs(media_ptr);
                                }
                            }
                            else
                            {

                                /* The log file does not contain log content but the FAT chain operation information is present.
                                   This is the situation where the FAT chain has been modified but the rest of the content of these
                                   clusters are not updated yet.  In this situation, the previous FAT chain operation needs to be
                                   reverted to restore the file system back to its state prior to the write operation. */
                                status = _fx_fault_tolerant_recover(media_ptr);
                            }

                            if (status !=  FX_SUCCESS)
                            {

                                /* Release media protection.  */
                                FX_UNPROTECT

                                /* Return the error status.  */
                                return(status);
                            }
                        }
                    }
                }
            }
            else
            {

                /* This FAT entry is not occupied by log file.   Set the flag to create a new log file. */
                start_cluster = 0;
            }
        }
        else
        {

            /* Not a valid cluster number. Set the flag to create a new log file. */
            start_cluster = 0;
        }
    }

    /* Check whether or not to create a log file. */
    if (start_cluster == 0)
    {

        /* Create log file. */
        status = _fx_fault_tolerant_create_log_file(media_ptr);

        if (status !=  FX_SUCCESS)
        {

            /* Release media protection.  */
            FX_UNPROTECT

            /* Return the error status.  */
            return(status);
        }
    }

    /* Reset log file. */
    status = _fx_fault_tolerant_reset_log_file(media_ptr);

    if (status !=  FX_SUCCESS)
    {

        /* Release media protection.  */
        FX_UNPROTECT

        /* Return the error status.  */
        return(status);
    }

    /* Mark fault tolerant feature is enabled. */
    media_ptr -> fx_media_fault_tolerant_enabled = FX_TRUE;

    /* Reset the transaction count. */
    media_ptr -> fx_media_fault_tolerant_transaction_count = 0;

    /* Release media protection.  */
    FX_UNPROTECT

    /* Return the error status.  */
    return(FX_SUCCESS);
}

#ifndef FX_DISABLE_INCLUDE_SOURCE_CODE
#include "fx_fault_tolerant_transaction_fail.c"
#endif

#endif /* FX_ENABLE_FAULT_TOLERANT */

