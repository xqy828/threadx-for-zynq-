/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2016 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/
/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Protocol version 6 Default Router Table (IPv6 router)      */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/
#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_ipv6.h"
#include "nx_nd_cache.h"
#include "nx_icmpv6.h"


#ifdef FEATURE_NX_IPV6
/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nxd_ipv6_prefix_router_timer_tick                   PORTABLE C     */
/*                                                           5.10         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    At every time tick, this function checks for time out expiration on */
/*    both the default router list and the prefix list tables bound to the*/
/*    supplied IP instance.                                               */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                IP instance pointer           */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    tx_mutex_get                          Obtain a protection mutex     */
/*    tx_mutex_put                          Release protection mutex      */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    _nx_ip_thread_entry                                                 */
/*                                                                        */
/*  NOTE                                                                  */
/*                                                                        */
/*    The nx_ip_protection mutex must be obtained before calling this     */
/*    function.                                                           */
/*                                                                        */
/*    This function cannot be called from ISR.                            */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-30-2007     Yuxin Zhou               Initial Version 5.2           */
/*  08-03-2009     Yuxin Zhou               Modified comments, resulting  */
/*                                            in version 5.3.             */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            modified struct field names */
/*                                            missing struct name prefix, */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s), clean up */
/*                                            the destination table when  */
/*                                            a router entry times out,   */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s),          */
/*                                            fixed compiler warnings,    */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            renamed symbols, resulting  */
/*                                            in version 5.9              */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*                                                                        */
/**************************************************************************/
VOID _nxd_ipv6_prefix_router_timer_tick(NX_IP *ip_ptr)
{

UINT                          i, table_size;
UINT                          j, dest_table_size;
ND_CACHE_ENTRY               *NDCacheEntry;
NX_IPV6_PREFIX_ENTRY         *tmp, *prefix_entry;
NX_IPV6_DEFAULT_ROUTER_ENTRY *rt_entry;


    /* Set a local variable for convenience. */
    table_size = ip_ptr -> nx_ipv6_default_router_table_size;

    /* Check each entry in the default router table. */
    for (i = 0; table_size && (i < NX_IPV6_DEFAULT_ROUTER_TABLE_SIZE); i++)
    {

        /* Set a local variable for convenience. */
        rt_entry = &ip_ptr -> nx_ipv6_default_router_table[i];

        /* Skip invalid or empty slots. */
        if ((rt_entry -> nx_ipv6_default_router_entry_flag & NX_IPV6_ROUTE_TYPE_VALID) == 0)
        {
            continue;
        }

        /* Keep track of valid entries we've checked. */
        table_size--;

        /* Has the entry on the current table entry expired? */
        if (rt_entry -> nx_ipv6_default_router_entry_life_time == 0)
        {

            /* Yes, the router has timed out. */

            /* Set a local variable for convenience. */
            dest_table_size = nx_ipv6_destination_table_size;

            /* Point to the nd_entry. */
            NDCacheEntry = rt_entry -> nx_ipv6_default_router_entry_neighbor_cache_ptr;

            /* Does this router have an entry in the ND cache table? */
            if (NDCacheEntry)
            {

                /* Loop through the whole table to match the IP address. */
                for (j = 0; dest_table_size && (j < NX_IPV6_DESTINATION_TABLE_SIZE); j++)
                {

                    /* Skip invalid entries. */
                    if (!nx_destination_table[j].nx_ipv6_destination_entry_valid)
                    {
                        continue;
                    }

                    /* Keep track of valid entries we have checked. */
                    dest_table_size--;

                    /* Check whether or not the address is the same. */
                    if (CHECK_IPV6_ADDRESSES_SAME(nx_destination_table[j].nx_ipv6_destination_entry_next_hop,
                                                  NDCacheEntry -> nx_nd_cache_dest_ip))
                    {

                        /* A matching entry is found.  Mark the entry as invalid. */
                        nx_destination_table[j].nx_ipv6_destination_entry_valid = 0;

                        /* Decrease the count of available destinations. */
                        nx_ipv6_destination_table_size--;
                    }
                }

                /* Yes, clear out that entry, we are invalidating this entry. */
                _nx_nd_cache_clear_IsRouter_field(rt_entry -> nx_ipv6_default_router_entry_neighbor_cache_ptr);
            }

            /* Invalidate the entry in the router table. */
            rt_entry -> nx_ipv6_default_router_entry_flag = 0;

            /* Decrease the IP instance default router count. */
            ip_ptr -> nx_ipv6_default_router_table_size--;
        }
        else
        {
            /* Is this a static router (infinite timeout)? */
            if (rt_entry -> nx_ipv6_default_router_entry_life_time != 0xFFFF)
            {

                /* No, so decrement the lifetime by one tick.*/
                rt_entry -> nx_ipv6_default_router_entry_life_time--;
            }
        }
    }

    /* Set a pointer to the first prefix entry in the IP prefix list. */
    prefix_entry = ip_ptr -> nx_ipv6_prefix_list_ptr;

    /* Loop through the entire list. */
    while (prefix_entry)
    {

        /* Set a placemarker at the current prefix. */
        tmp = prefix_entry;

        /* Get a pointer to the next prefix. */
        prefix_entry = prefix_entry -> nx_ipv6_prefix_entry_next;

        /* Skip the static entries. */
        if (tmp -> nx_ipv6_prefix_entry_valid_lifetime != (UINT)0xFFFFFFFF)
        {

            /* Has the prefix entry timeout expired? */
            if (tmp -> nx_ipv6_prefix_entry_valid_lifetime == 0)
            {

                /* Yes, so delete it from the list. */
                _nx_ipv6_prefix_list_delete_entry(ip_ptr, tmp);
            }
            else
            {

                /* Just decrement the time remaining. */
                tmp -> nx_ipv6_prefix_entry_valid_lifetime--;
            }
        }
    }

    return;
}

#endif /* FEATURE_NX_IPV6 */

