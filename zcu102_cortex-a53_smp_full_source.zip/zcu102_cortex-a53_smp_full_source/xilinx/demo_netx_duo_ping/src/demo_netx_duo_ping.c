/* Copyright (c) 1996-2018 by Express Logic Inc.

   This is a small network demonstration of the high-performance NetX TCP/IP stack running
   on top of ThreadX, which allows the user to ping the Zynq UltraSCale+ ZCU102 demo board.

*/

/* By default, enable DHCP for IP address. The IP address will be printed to the debugger console.  */
#define NX_ENABLE_DHCP

#include "tx_api.h"
#include "nx_api.h"
#include "tx_zynqmp.h"
#include "nx_driver_zynqmp_gem.h"
#include <stdlib.h>

/* XXX prevent xil_types.h from redefining LONG and ULONG types */
#define LONG LONG
#define ULONG ULONG

#include "xil_printf.h"

int IicPhyReset(void);


#ifdef NX_ENABLE_DHCP
#include "nxd_dhcp_client.h"
NX_DHCP           dhcp_client;
#endif
UCHAR             ip_address[4];
UCHAR             network_mask[4];
UCHAR             hardware_address[] = { 0x00, 0x0a, 0x35, 0x00, 0x01, 0x02 };

TX_THREAD         demo_thread;


/* Define the ThreadX and NetX object control blocks...  */

NX_PACKET_POOL    pool_0;
NX_IP             ip_0;


/* Define the IP thread's stack area.  */

ULONG             ip_thread_stack[2 * 1024 / sizeof(ULONG)];
ULONG             demo_thread_stack[4096 / sizeof(ULONG)];


/* Define packet pool for the demonstration. Packets must be 64-bytes aligned  */

#define NX_PACKET_SIZE      ((1536 + sizeof(NX_PACKET) + 63) & ~63)
#define NX_PACKET_POOL_SIZE (NX_PACKET_SIZE * 100)

UCHAR             packet_pool_area[NX_PACKET_POOL_SIZE] __attribute__ ((aligned (64)));


/* Define the ARP cache area.  */

ULONG             arp_space_area[512 / sizeof(ULONG)];


/* Define an error counter.  */

ULONG             error_counter;


/* Define the driver buffer descriptors */

#define NUM_RX_BDS    32
#define NUM_TX_BDS    64
#define BDS_SIZE      (NUM_RX_BDS + NUM_TX_BDS)*NX_DRIVER_ZYNQMP_GEM_DMABD_SIZE
#define BDS_ALIGN     NX_DRIVER_ZYNQMP_GEM_DMABD_ALIGNMENT

UCHAR driver_bds[BDS_SIZE] __attribute__ ((aligned (BDS_ALIGN)));


static  VOID thread_entry(ULONG thread_input);


int main()
{
    /* Enter the ThreadX kernel.  */
    tx_kernel_enter();
}


/* Define what the initial system looks like.  */

void    tx_application_define(void *first_unused_memory)
{

UINT  status;

    /* deassert PHY reset? */
    IicPhyReset();

    /* Create the main demo thread.  */
    tx_thread_create(&demo_thread, "Demo Thread", thread_entry,
                     0,  demo_thread_stack, sizeof(demo_thread_stack),
                     17, 17, TX_NO_TIME_SLICE, TX_AUTO_START);

    /* Initialize the NetX system.  */
    nx_system_initialize();

    /* Create a packet pool.  */
    status =  nx_packet_pool_create(&pool_0, "NetX Main Packet Pool", NX_PACKET_SIZE - sizeof(NX_PACKET), packet_pool_area , NX_PACKET_POOL_SIZE);

    /* Check for pool creation error.  */
    if (status)
        error_counter++;

    /* Create an IP instance.  */
    status = nx_ip_create(&ip_0,
                          "NetX IP Instance 0",
#ifdef NX_ENABLE_DHCP
                          IP_ADDRESS(0,0,0,0),
                          IP_ADDRESS(0,0,0,0),
#else
                          IP_ADDRESS(192, 2, 2, 149), /* Static IP Address goes here!  */
                          0xFFFFFF00UL,
#endif
                          &pool_0, nx_driver_zynqmp_gem3,
                          (UCHAR*)ip_thread_stack,
                          sizeof(ip_thread_stack),
                          1);

    /* Check for IP create errors.  */
    if (status)
        error_counter++;

    /* Enable ARP and supply ARP cache memory for IP Instance 0.  */
    status =  nx_arp_enable(&ip_0, (void *)arp_space_area, sizeof(arp_space_area));

    /* Check for ARP enable errors.  */
    if (status)
        error_counter++;

    /* Enable TCP traffic.  */
    status =  nx_tcp_enable(&ip_0);

    /* Check for TCP enable errors.  */
    if (status)
        error_counter++;

    /* Enable UDP traffic.  */
    status =  nx_udp_enable(&ip_0);

    /* Check for UDP enable errors.  */
    if (status)
        error_counter++;

    /* Enable ICMP.  */
    status =  nx_icmp_enable(&ip_0);

    /* Check for errors.  */
    if (status)
        error_counter++;

    /* Configure buffer descriptors */
    nx_driver_zynqmp_gem_dmabds_set(&ip_0, 0,
        driver_bds, NUM_RX_BDS, driver_bds + NUM_RX_BDS*NX_DRIVER_ZYNQMP_GEM_DMABD_SIZE, NUM_TX_BDS);

    /* set MAC address */
    nx_ip_interface_physical_address_set(&ip_0, 0,
        (ULONG)((hardware_address[0] <<  8) | (hardware_address[1])),
        (ULONG)((hardware_address[2] << 24) | (hardware_address[3] << 16) |
                (hardware_address[4] <<  8) | (hardware_address[5])), NX_TRUE);

}


static  VOID thread_entry(ULONG thread_input)
{

ULONG temp;
#ifdef NX_ENABLE_DHCP
ULONG actual_status;
UINT  status;

    xil_printf("DHCP In Progress...\r\n");

    /* Create the DHCP instance.  */
    nx_dhcp_create(&dhcp_client, &ip_0, "dhcp_client");

    /* Start the DHCP Client.  */
    nx_dhcp_start(&dhcp_client);

    /* Wait until address is solved. */
    while (1)
    {
        status = nx_ip_status_check(&ip_0, NX_IP_ADDRESS_RESOLVED, &actual_status, 1000);

        if (status)
        {
            /* Failed */
            xil_printf("Can't solve address...\r\n");
        }
        else
        {
            xil_printf("DHCP complete:\r\n");
            break;
        }
    }
#endif

    /* Get IP address. */
    nx_ip_address_get(&ip_0, (ULONG *) &ip_address[0], (ULONG *) &network_mask[0]);

    /* Convert IP address & network mask from little endian.  */
    temp =  *((ULONG *) &ip_address[0]);
    NX_CHANGE_ULONG_ENDIAN(temp);
    *((ULONG *) &ip_address[0]) =  temp;

    temp =  *((ULONG *) &network_mask[0]);
    NX_CHANGE_ULONG_ENDIAN(temp);
    *((ULONG *) &network_mask[0]) =  temp;

    /* Output IP address. */
    xil_printf("IP address: %d.%d.%d.%d\r\nMask: %d.%d.%d.%d\r\n",
           (UINT) (ip_address[0]),
           (UINT) (ip_address[1]),
           (UINT) (ip_address[2]),
           (UINT) (ip_address[3]),
           (UINT) (network_mask[0]),
           (UINT) (network_mask[1]),
           (UINT) (network_mask[2]),
           (UINT) (network_mask[3]));

}
