/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2017 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** FileX Component                                                       */
/**                                                                       */
/**   Utility                                                             */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/
#define FX_SOURCE_CODE


/* Include necessary system files.  */

#include "fx_api.h"


#ifdef FX_ENABLE_EXFAT
#include "fx_directory_exFAT.h"
#include "fx_utility.h"


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _fx_utility_exFAT_unicode_name_hash_get             PORTABLE C      */
/*                                                           5.5          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function returns hash of Unicode file name.                    */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    unicode_name                          Unicode file name             */
/*    unicode_length                        Unicode name length           */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    return name hash                                                    */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    _fx_directory_exFAT_entry_write                                     */
/*    _fx_directory_rename                                                */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  11-01-2015     Willam E. Lamie          Initial Version 5.3           */
/*  04-15-2016     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  04-03-2017     William E. Lamie         Modified comment(s),          */
/*                                            fixed compiler warnings,    */
/*                                            resulting in version 5.5    */
/*                                                                        */
/**************************************************************************/
USHORT  _fx_utility_exFAT_unicode_name_hash_get(CHAR *unicode_name, ULONG unicode_length)
{

USHORT hash;
USHORT upcased_char;

    /* Initialize hash to 0. */
    hash = 0;

    /* Is there a name?  */
    if (!unicode_name)
    {

        /* No, just return 0.  */
        return(0);
    }

    /* Create hash for name.  */
    while (unicode_length)
    {

        /* Get up-cased character.  */
        upcased_char = (USHORT)(_fx_utility_exFAT_upcase_get((USHORT)(*unicode_name | (*(unicode_name + 1) << 8))));

        /* Compute hash.  */
        hash = (USHORT)(((hash >> 1) | (hash << 15)) + (upcased_char & 0xFF));
        hash = (USHORT)(((hash >> 1) | (hash << 15)) + (upcased_char >> 8));

        /* Move to next character of the Unicode name.  */
        unicode_name = unicode_name + 2;

        /* Decrement length.  */
        unicode_length--;
    }

    /* Return the hash.  */
    return(hash);
}

#endif /* FX_ENABLE_EXFAT */

