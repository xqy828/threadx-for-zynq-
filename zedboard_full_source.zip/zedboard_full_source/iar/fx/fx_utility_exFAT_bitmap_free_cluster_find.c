/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2017 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** FileX Component                                                       */
/**                                                                       */
/**   Utility                                                             */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/
#define FX_SOURCE_CODE

/* Include necessary system files.  */


#include "fx_api.h"


#ifdef FX_ENABLE_EXFAT
#include "fx_system.h"
#include "fx_media.h"
#include "fx_utility.h"
#include "fx_directory_exFAT.h"


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _fx_utility_exFAT_bitmap_free_cluster_find          PORTABLE C      */
/*                                                           5.5          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function searches for a free cluster.                          */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    media_ptr                             Media control block pointer   */
/*    search_start_cluster                  Cluster number to begin search*/
/*    free_cluster                          ULONG pointer to store cluster*/
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    return status                                                       */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _fx_utility_exFAT_cluster_state_get   Get cluster state             */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    FileX System Functions                                              */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  11-01-2015     William E. Lamie         Initial Version 5.3           */
/*  04-15-2016     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  04-03-2017     William E. Lamie         Modified comment(s),          */
/*                                            unified the return value for*/
/*                                            exFAT and FAT,              */
/*                                            resulting in version 5.5    */
/*                                                                        */
/**************************************************************************/
UINT  _fx_utility_exFAT_bitmap_free_cluster_find(FX_MEDIA *media_ptr, ULONG search_start_cluster, ULONG *free_cluster)
{

UINT  status;
UCHAR cluster_state;
ULONG cluster = search_start_cluster;


    /* Search for a free cluster.  */
    while (cluster < media_ptr -> fx_media_total_clusters + FX_FAT_ENTRY_START)
    {

        /* Get the cluster state.  */
        status = _fx_utility_exFAT_cluster_state_get(media_ptr, cluster, &cluster_state);

        /* Check the status of the state get.  */
        if (status != FX_SUCCESS)
        {

            /* Media error or out of total clusters number - stop searching.  */
            return(status);
        }

        /* Is this cluster free?  */
        if (cluster_state == FX_EXFAT_BITMAP_CLUSTER_FREE)
        {

            /* Yes, finished the search.  */

            /* Return the cluster.  */
            *free_cluster = cluster;

            /* Return success.  */
            return(FX_SUCCESS);
        }

        /* Move to next cluster.  */
        cluster++;
    }

    /* See if there is anything to search in the beginning.  */
    if (search_start_cluster > FX_FAT_ENTRY_START)
    {

        /* Start at the beginning.  */
        cluster = FX_FAT_ENTRY_START;

        /* Loop to search clusters.  */
        while (cluster < search_start_cluster)
        {

            /* Get the cluster state.  */
            status = _fx_utility_exFAT_cluster_state_get(media_ptr, cluster, &cluster_state);
            if (status != FX_SUCCESS)
            {

                /* Media error or out of total clusters number - stop searching.  */
                return(status);
            }

            /* Is this cluster free?  */
            if (cluster_state == FX_EXFAT_BITMAP_CLUSTER_FREE)
            {

                /* Yes, finished the search.  */

                /* Return the cluster.  */
                *free_cluster = cluster;

                /* Return success.  */
                return(FX_SUCCESS);
            }

            /* Move to the next cluster.  */
            cluster++;
        }
    }

    /* No more free clusters, return error.  */
    return(FX_NO_MORE_SPACE);
}

#endif /* FX_ENABLE_EXFAT */

