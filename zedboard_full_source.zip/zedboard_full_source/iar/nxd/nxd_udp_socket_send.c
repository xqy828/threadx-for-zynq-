/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2017 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   User Datagram Protocol (UDP)                                        */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_udp.h"
#include "nx_ip.h"
#ifdef FEATURE_NX_IPV6
#include "nx_ipv6.h"
#endif /* FEATURE_NX_IPV6 */

#ifdef NX_IPSEC_ENABLE
#include "nx_ipsec.h"
#endif /* NX_IPSEC_ENABLE */

/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nxd_udp_socket_send                                PORTABLE C      */
/*                                                           5.10 SP2     */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function sends a UDP packet through the specified socket       */
/*    with the input IP address and port.                                 */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    socket_ptr                            Pointer to UDP socket         */
/*    packet_ptr                            Pointer to UDP packet         */
/*    ip_address                            IP address                    */
/*    port                                  16-bit UDP port number        */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                                Completion status             */
/*    NX_IPSEC_REJECTED                     Failed IPSec check            */
/*    NX_NOT_BOUND                          Socket not bound to a port    */
/*    NX_NO_INTERFACE_ADDRESS               Socket interface not marked   */
/*                                             valid                      */
/*  CALLS                                                                 */
/*                                                                        */
/*    _nx_ip_packet_send                    Send UDP packet over IPv4     */
/*    _nx_ipv6_packet_send                  Send UDP packet over IPv6     */
/*    nx_ip_checksum_compute                Compute UDP header checksum   */
/*    tx_mutex_get                          Get protection mutex          */
/*    tx_mutex_put                          Put protection mutex          */
/*    _nxd_ipv6_interface_find              Find interface for input      */
/*                                             address in IP address table*/
/*    [_nx_packet_egress_sa_lookup]         IPsec process                 */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-12-2005     William E. Lamie         Initial Version 5.0           */
/*  08-09-2007     William E. Lamie         Modified comment(s), and      */
/*                                            optimized the checksum      */
/*                                            logic, resulting in         */
/*                                            version 5.1                 */
/*  12-30-2007     Yuxin Zhou               Support for IPv6, resulting   */
/*                                            in version 5.2              */
/*  08-03-2009     William E. Lamie         Modified comment(s), added    */
/*                                            logic for trace support,    */
/*                                            and add IPSec support,      */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s), added    */
/*                                            checking for packet data    */
/*                                            overflow(pass beyond the    */
/*                                            end of the packet buffer),  */
/*                                            added support for multiple  */
/*                                            IPv6 global addresses,      */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Removed internal debug logic, */
/*                                            fixed IPv6 outgoing logic   */
/*                                            setting, modified struct    */
/*                                            field names missing struct  */
/*                                            name prefix, resulting in   */
/*                                            version 5.5                 */
/*  10-10-2011     Yuxin Zhou               Modified comment(s), added    */
/*                                            multihome support,          */
/*                                            added transmit checksum     */
/*                                            option, replaced automatic  */
/*                                            checksum if IPv6 enabled,   */
/*                                            added IPsec support,        */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s), fixed    */
/*                                            a typo for PENDING_IKEv2,   */
/*                                            modified the checksum logic */
/*                                            so that checksum for IPv6   */
/*                                            packets is alwasy computed, */
/*                                            renamed IKE to IKEv2, added */
/*                                            hardware capability support,*/
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s), and      */
/*                                            fixed source address        */
/*                                            selection for IPv6,         */
/*                                            optimized NX_PACKET_STRUCT, */
/*                                            optimized NX_UDP_SOCKET     */
/*                                            structure, fixed compiler   */
/*                                            warnings, resulting in      */
/*                                            version 5.8                 */
/*  02-22-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            supported packet debugging, */
/*                                            fixed statistics when IPv6  */
/*                                            address was not valid, fixed*/
/*                                            compiler warnings, resulting*/
/*                                            in version 5.9              */
/*  05-10-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            optimized the logic of      */
/*                                            checksum calculation,       */
/*                                            resulting in version 5.10   */
/*  04-03-2017     Yuxin Zhou               Modified comment(s), and      */
/*                                            fixed compiler errors,      */
/*                                            resulting in version 5.10SP2*/
/*                                                                        */
/**************************************************************************/
UINT  _nxd_udp_socket_send(NX_UDP_SOCKET *socket_ptr,
                           NX_PACKET     *packet_ptr,
                           NXD_ADDRESS   *ip_address,
                           UINT           port)
{
TX_INTERRUPT_SAVE_AREA

NX_IP         *ip_ptr;
NX_UDP_HEADER *udp_header_ptr;
ULONG         *ip_src_addr, *ip_dest_addr;
ULONG          next_hop_address;
NX_INTERFACE  *interface_ptr;
#ifdef FEATURE_NX_IPV6
UINT           status;
#endif /* FEATURE_NX_IPV6 */

#ifdef NX_IPSEC_ENABLE
VOID          *sa = NX_NULL;
ULONG          data_offset;
NXD_ADDRESS    src_addr;
UINT           ret;
#endif /* NX_IPSEC_ENABLE */

#ifdef TX_ENABLE_EVENT_TRACE
UINT           ip_address_log = 0;
#endif /* TX_ENABLE_EVENT_TRACE */

#if defined(NX_DISABLE_UDP_TX_CHECKSUM) || defined(NX_ENABLE_INTERFACE_CAPABILITY) || defined(NX_IPSEC_ENABLE)
UINT           compute_checksum = 1;
#endif /* defined(NX_DISABLE_UDP_TX_CHECKSUM) || defined(NX_ENABLE_INTERFACE_CAPABILITY) || defined(NX_IPSEC_ENABLE) */

#ifdef NX_DISABLE_UDP_TX_CHECKSUM
    /* Disable UDP TX checksum. */
    compute_checksum = 0;
#endif /* NX_DISABLE_UDP_TX_CHECKSUM */

    /* Lockout interrupts.  */
    TX_DISABLE

    /* Add debug information. */
    NX_PACKET_DEBUG(__FILE__, __LINE__, packet_ptr);

    /* Determine if the socket is currently bound to a UDP port.  */
    if (!socket_ptr ->  nx_udp_socket_bound_next)
    {

        /* Restore interrupts.  */
        TX_RESTORE

        /* Socket is not bound, return an error message.  */
        return(NX_NOT_BOUND);
    }

    /* Pickup the important information from the socket.  */

    /* Set up the pointer to the associated IP instance.  */
    ip_ptr =  socket_ptr -> nx_udp_socket_ip_ptr;

#ifdef TX_ENABLE_EVENT_TRACE

    /* For IPv4 packets, log the whole IP address. */
    if (ip_address -> nxd_ip_version == NX_IP_VERSION_V4)
    {
        ip_address_log = ip_address -> nxd_ip_address.v4;
    }

#ifdef FEATURE_NX_IPV6

    /* For IPv6 packets, log the least significant 32-bit of the IP address. */
    else
    {
        ip_address_log = ip_address -> nxd_ip_address.v6[3];
    }

#endif

    /* If trace is enabled, insert this event into the trace buffer.  */
    NX_TRACE_IN_LINE_INSERT(NX_TRACE_UDP_SOCKET_SEND, socket_ptr, packet_ptr, packet_ptr -> nx_packet_length, ip_address_log, NX_TRACE_UDP_EVENTS, 0, 0);

#endif /* TX_ENABLE_EVENT_TRACE */

    /* Restore interrupts.  */
    TX_RESTORE

#ifdef FEATURE_NX_IPV6
    if (ip_address -> nxd_ip_version == NX_IP_VERSION_V4)
    {
#endif /* FEATURE_NX_IPV6 */

        /* Look for a suitable interface. */
        _nx_ip_route_find(ip_ptr, ip_address -> nxd_ip_address.v4, &packet_ptr -> nx_packet_address.nx_packet_interface_ptr,
                          &next_hop_address);

        /* Check the packet interface.  */
        if (!packet_ptr -> nx_packet_address.nx_packet_interface_ptr)
        {

            /* None found; return the error status. */
            return(NX_IP_ADDRESS_ERROR);
        }

        interface_ptr = packet_ptr -> nx_packet_address.nx_packet_interface_ptr;
#ifdef FEATURE_NX_IPV6
    }
    else
    {
        if (packet_ptr -> nx_packet_address.nx_packet_ipv6_address_ptr == NX_NULL)
        {

            /* Determine if the IP instance has a matching address for the packet destination. */
            status = _nxd_ipv6_interface_find(ip_ptr, ip_address, &packet_ptr -> nx_packet_address.nx_packet_ipv6_address_ptr);

            /* If not, return the error status. */
            if (status != NX_SUCCESS)
            {
                return(status);
            }
        }

        /* Get the packet interface information. */
        interface_ptr = packet_ptr -> nx_packet_address.nx_packet_ipv6_address_ptr -> nxd_ipv6_address_attached;
    }
#endif /* FEATURE_NX_IPV6 */

#ifdef NX_IPSEC_ENABLE

    if (ip_address -> nxd_ip_version == NX_IP_VERSION_V4)
    {

        /* Copy IP version and address for internal IPSec (SA) processing. */
        src_addr.nxd_ip_version = NX_IP_VERSION_V4;
        src_addr.nxd_ip_address.v4 = interface_ptr -> nx_interface_ip_address;
    }

#ifdef FEATURE_NX_IPV6
    else
    {

        /* Handle for IPv6 packets. */
        src_addr.nxd_ip_version = NX_IP_VERSION_V6;
        COPY_IPV6_ADDRESS(packet_ptr -> nx_packet_address.nx_packet_ipv6_address_ptr -> nxd_ipv6_address, src_addr.nxd_ip_address.v6);
    }
#endif /* FEATURE_NX_IPV6 */

    /* Check for possible SA match. */
    if (ip_ptr -> nx_ip_packet_egress_sa_lookup != NX_NULL)               /* IPsec is enabled. */
    {
        /* If the SA has not been set. */
        ret = ip_ptr -> nx_ip_packet_egress_sa_lookup(ip_ptr,                                    /* IP ptr */
                                                      &src_addr,                                 /* src_addr */
                                                      ip_address,                                /* dest_addr */
                                                      NX_PROTOCOL_UDP,                           /* protocol */
                                                      socket_ptr -> nx_udp_socket_port,          /* src_port */
                                                      port,                                      /* dest_port */
                                                      &data_offset, &sa, 0);
        if (ret == NX_IPSEC_TRAFFIC_PROTECT)
        {

            /* Save the SA to the packet. */
            packet_ptr -> nx_packet_ipsec_sa_ptr = sa;
        }
        else if (ret == NX_IPSEC_TRAFFIC_DROP || ret == NX_IPSEC_TRAFFIC_PENDING_IKEV2)
        {
            return(NX_IPSEC_REJECTED);
        }
        else
        {
            /* Zero out sa information. */
            packet_ptr -> nx_packet_ipsec_sa_ptr = NX_NULL;
        }
    }

#endif /* NX_IPSEC_ENABLE */

    /* Prepend the UDP header to the packet.  First, make room for the UDP header.  */
    packet_ptr -> nx_packet_prepend_ptr =  packet_ptr -> nx_packet_prepend_ptr - sizeof(NX_UDP_HEADER);

    /* Set the correct IP version. */
    packet_ptr -> nx_packet_ip_version = (UCHAR)(ip_address -> nxd_ip_version);

    /* Find out the IP version, and tag the packet */
#ifdef FEATURE_NX_IPV6
    if (ip_address -> nxd_ip_version == NX_IP_VERSION_V4)
    {

        /* At this point packet_ptr->prepend_ptr points to UDP header */
        packet_ptr -> nx_packet_ip_header = packet_ptr -> nx_packet_prepend_ptr - sizeof(NX_IPV4_HEADER);
#endif /* FEATURE_NX_IPV6 */

        /* Fill in the IP src/dest address */
        ip_dest_addr = &ip_address -> nxd_ip_address.v4;
        ip_src_addr = &interface_ptr -> nx_interface_ip_address;
#ifdef FEATURE_NX_IPV6
    }
    else
    {

        if (packet_ptr -> nx_packet_address.nx_packet_ipv6_address_ptr -> nxd_ipv6_address_state != NX_IPV6_ADDR_STATE_VALID)
        {
            return(NX_NO_INTERFACE_ADDRESS);
        }

        /* At this point packet_ptr->prepend_ptr points to UDP header */
        packet_ptr -> nx_packet_ip_header = packet_ptr -> nx_packet_prepend_ptr - sizeof(NX_IPV6_HEADER);
        ip_dest_addr = &ip_address -> nxd_ip_address.v6[0];

        ip_src_addr = packet_ptr -> nx_packet_address.nx_packet_ipv6_address_ptr -> nxd_ipv6_address;
    }

#endif /* FEATURE_NX_IPV6 */

#ifndef NX_DISABLE_UDP_INFO
    /* Increment the total UDP packets sent count.  */
    ip_ptr -> nx_ip_udp_packets_sent++;

    /* Increment the total UDP bytes sent.  */
    ip_ptr -> nx_ip_udp_bytes_sent +=  packet_ptr -> nx_packet_length;

    /* Increment the total UDP packets sent count for this socket.  */
    socket_ptr -> nx_udp_socket_packets_sent++;

    /* Increment the total UDP bytes sent for this socket.  */
    socket_ptr -> nx_udp_socket_bytes_sent +=  packet_ptr -> nx_packet_length;
#endif

    /* Increase the packet length.  */
    packet_ptr -> nx_packet_length =  packet_ptr -> nx_packet_length + sizeof(NX_UDP_HEADER);

    /* Setup the UDP header pointer.  */
    /*lint -e{927} -e{826} suppress cast of pointer to pointer, since it is necessary  */
    udp_header_ptr =  (NX_UDP_HEADER *)packet_ptr -> nx_packet_prepend_ptr;

    /* Build the first 32-bit word of the UDP header.  */
    udp_header_ptr -> nx_udp_header_word_0 =
        (((ULONG)socket_ptr -> nx_udp_socket_port) << NX_SHIFT_BY_16) | (ULONG)port;

    /* Build the second 32-bit word of the UDP header.  */
    udp_header_ptr -> nx_udp_header_word_1 =  (packet_ptr -> nx_packet_length << NX_SHIFT_BY_16);

    /* If trace is enabled, insert this event into the trace buffer.  */
    NX_TRACE_IN_LINE_INSERT(NX_TRACE_INTERNAL_UDP_SEND, ip_ptr, socket_ptr, packet_ptr, udp_header_ptr -> nx_udp_header_word_0, NX_TRACE_INTERNAL_EVENTS, 0, 0);

    /* Endian swapping logic.  If NX_LITTLE_ENDIAN is specified, these macros will
       swap the endian of the UDP header.  */
    NX_CHANGE_ULONG_ENDIAN(udp_header_ptr -> nx_udp_header_word_0);
    NX_CHANGE_ULONG_ENDIAN(udp_header_ptr -> nx_udp_header_word_1);

    /* Determine if we need to compute the UDP checksum.

       Note that with IPv6, UDP packet checksum is mandatory. However if the underly device
       driver is able to compute UDP checksum in hardware, let the driver handle the checksum
       computation.
     */

    if ((!socket_ptr -> nx_udp_socket_disable_checksum) ||
        (ip_address -> nxd_ip_version == NX_IP_VERSION_V6))
    {
#ifdef NX_ENABLE_INTERFACE_CAPABILITY
        if (interface_ptr -> nx_interface_capability_flag & NX_INTERFACE_CAPABILITY_UDP_TX_CHECKSUM)
        {
            compute_checksum = 0;
        }
#endif /* NX_ENABLE_INTERFACE_CAPABILITY */

#ifdef NX_IPSEC_ENABLE
        /* In case this packet is going through the IPsec protected channel, the checksum would have to be computed
           in software even if the hardware checksum is available at driver layer.  The checksum value must be present
           in order when applying IPsec process. */

        if ((packet_ptr -> nx_packet_ipsec_sa_ptr != NX_NULL) && (((NX_IPSEC_SA *)(packet_ptr -> nx_packet_ipsec_sa_ptr)) -> nx_ipsec_sa_encryption_method != NX_CRYPTO_NONE))
        {
            compute_checksum = 1;
        }
#endif /* NX_IPSEC_ENABLE */

#if defined(NX_DISABLE_UDP_TX_CHECKSUM) || defined(NX_ENABLE_INTERFACE_CAPABILITY) || defined(NX_IPSEC_ENABLE)
        if (compute_checksum)
#endif /* defined(NX_DISABLE_UDP_TX_CHECKSUM) || defined(NX_ENABLE_INTERFACE_CAPABILITY) || defined(NX_IPSEC_ENABLE) */
        {

        ULONG checksum;

            /* Yes, we need to compute the UDP checksum.  */
            checksum = _nx_ip_checksum_compute(packet_ptr,
                                               NX_PROTOCOL_UDP,
                                               (UINT)packet_ptr -> nx_packet_length,
                                               ip_src_addr,
                                               ip_dest_addr);
            checksum = ~checksum & NX_LOWER_16_MASK;

            /* If the computed checksum is zero, it will be transmitted as all ones. */
            /* RFC 768, page 2. */
            if (checksum == 0)
            {
                checksum = 0xFFFF;
            }

            NX_CHANGE_ULONG_ENDIAN(udp_header_ptr -> nx_udp_header_word_1);

            udp_header_ptr -> nx_udp_header_word_1 = udp_header_ptr -> nx_udp_header_word_1 | checksum;

            NX_CHANGE_ULONG_ENDIAN(udp_header_ptr -> nx_udp_header_word_1);
        }
#ifdef NX_ENABLE_INTERFACE_CAPABILITY
        else
        {
            /* Set CHECKSUM flag so the driver would invoke the HW checksum. */
            packet_ptr -> nx_packet_interface_capability_flag |= NX_INTERFACE_CAPABILITY_UDP_TX_CHECKSUM;
        }
#endif
    }

    /* Get mutex protection.  */
    tx_mutex_get(&(ip_ptr -> nx_ip_protection), TX_WAIT_FOREVER);

    /* Send the UDP packet to the IPv4 component.  */
    if (ip_address -> nxd_ip_version == NX_IP_VERSION_V4)
    {

        /*lint -e{644} suppress variable might not be initialized, since "next_hop_address" was initialized in _nx_ip_route_find. */
        _nx_ip_packet_send(ip_ptr, packet_ptr, ip_address -> nxd_ip_address.v4,
                           socket_ptr -> nx_udp_socket_type_of_service,
                           socket_ptr -> nx_udp_socket_time_to_live,
                           NX_IP_UDP, socket_ptr -> nx_udp_socket_fragment_enable,
                           next_hop_address);
    }
#ifdef FEATURE_NX_IPV6
    else
    {

        /* Set the source IPv6 address */
        _nx_ipv6_packet_send(ip_ptr, packet_ptr, NX_PROTOCOL_UDP,
                             packet_ptr -> nx_packet_length, ip_ptr -> nx_ipv6_hop_limit,
                             ip_src_addr,
                             ip_dest_addr);
    }
#endif /* FEATURE_NX_IPV6 */

    /* Release mutex protection.  */
    tx_mutex_put(&(ip_ptr -> nx_ip_protection));

    /* Return a successful status.  */
    return(NX_SUCCESS);
}

