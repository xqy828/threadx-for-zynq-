/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Transmission Control Protocol (TCP)                                 */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_tcp.h"
#include "tx_thread.h"
#include "nx_ipv6.h"
#include "nx_ipv4.h"
#include "nx_ip.h"

/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nxd_tcp_client_socket_connect                     PORTABLE C       */
/*                                                           5.11 SP1     */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function handles the connect request for the supplied socket.  */
/*    If bound and not connected, this function will send the first SYN   */
/*    message to the specified server to initiate the connection process. */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    socket_ptr                            Pointer to TCP client socket  */
/*    server_ip                             IP address of server          */
/*    server_port                           Port number of server         */
/*    wait_option                           Suspension option             */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                                Completion status             */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _nx_tcp_socket_thread_suspend         Suspend thread for connection */
/*    _nx_tcp_packet_send_syn               Send SYN packet               */
/*    _nx_ip_route_find                     Find a suitable outgoing      */
/*                                            interface.                  */
/*    tx_mutex_get                          Obtain protection             */
/*    tx_mutex_put                          Release protection            */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-12-2005     William E. Lamie         Initial Version 5.0           */
/*  08-09-2007     William E. Lamie         Modified comment(s), and      */
/*                                            changed UL to ULONG cast,   */
/*                                            resulting in version 5.1    */
/*  12-30-2007     Yuxin Zhou               Modified comment(s), and      */
/*                                            added support for IPv6,     */
/*                                            resulting in version 5.2    */
/*  08-03-2009     William E. Lamie         Modified comment(s), and added*/
/*                                            logic for trace support,    */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Added support for multiple    */
/*                                            IPv6 global addresses,      */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Removed internal debug logic, */
/*                                            modified struct field names */
/*                                            missing struct name prefix, */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s), perform  */
/*                                            socket cleanup before       */
/*                                            sending the SYN packet, also*/
/*                                            make sure the destination   */
/*                                            host is reachable, resulting*/
/*                                            in version 5.6              */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s),          */
/*                                            fixed compiler warnings,    */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            fixed a bug in computing    */
/*                                            TCP header size, added      */
/*                                            support for TCP_TIMED_WAIT  */
/*                                            state, fixed an issue in    */
/*                                            handling destination address*/
/*                                            being loopback, simplified  */
/*                                            internal logic, resulting   */
/*                                            in version 5.9              */
/*  05-10-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            fixed lint warnings,        */
/*                                            removed unreachable code,   */
/*                                            optimized the logic for     */
/*                                            computing SYN packet size,  */
/*                                            added ASSERT macro,         */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s), and      */
/*                                            supported specified source  */
/*                                            interface for IPv6, added   */
/*                                            support for disabling       */
/*                                            IPv4 feature, improved      */
/*                                            internal logic, resulting in*/
/*                                            version 5.11                */
/*  12-15-2018     Yuxin Zhou               Modified comment(s), and      */
/*                                            fixed a packet leak issue,  */
/*                                            resulting in version 5.11SP1*/
/*                                                                        */
/**************************************************************************/
UINT  _nxd_tcp_client_socket_connect(NX_TCP_SOCKET *socket_ptr,
                                     NXD_ADDRESS *server_ip,
                                     UINT server_port,
                                     ULONG wait_option)
{

UINT          ip_header_size = 0;
NX_IP        *ip_ptr;
NX_INTERFACE *outgoing_interface = NX_NULL;

#ifdef FEATURE_NX_IPV6
UINT          status;
#endif /* FEATURE_NX_IPV6 */

#ifdef TX_ENABLE_EVENT_TRACE
ULONG         ip_address_log = 0;
#endif /* TX_ENABLE_EVENT_TRACE */

    /* Setup IP pointer.  */
    ip_ptr =  socket_ptr -> nx_tcp_socket_ip_ptr;

    /* Make sure the server IP address is accesible. */
#ifndef NX_DISABLE_IPV4
    if (server_ip -> nxd_ip_version == NX_IP_VERSION_V4)
    {
        if (_nx_ip_route_find(ip_ptr, server_ip -> nxd_ip_address.v4, &outgoing_interface, &socket_ptr -> nx_tcp_socket_next_hop_address) != NX_SUCCESS)
        {
            /* Return an IP address error code.  */
            return(NX_IP_ADDRESS_ERROR);
        }
    }
#endif /* !NX_DISABLE_IPV4  */

#ifdef FEATURE_NX_IPV6
    /* For IPv6 connections, find a suitable outgoing interface, based on the TCP peer address. */
    if (server_ip -> nxd_ip_version == NX_IP_VERSION_V6)
    {

        status = _nxd_ipv6_interface_find(ip_ptr, server_ip -> nxd_ip_address.v6,
                                          &socket_ptr -> nx_tcp_socket_ipv6_addr,
                                          NX_NULL);

        if (status != NX_SUCCESS)
        {
            return(status);
        }

        outgoing_interface = socket_ptr -> nx_tcp_socket_ipv6_addr -> nxd_ipv6_address_attached;
    }
#endif /* FEATURE_NX_IPV6 */

#ifdef TX_ENABLE_EVENT_TRACE
#ifndef NX_DISABLE_IPV4
    if (server_ip -> nxd_ip_version == NX_IP_VERSION_V4)
    {
        ip_address_log = server_ip -> nxd_ip_address.v4;
    }
#endif /* !NX_DISABLE_IPV4  */

#ifdef FEATURE_NX_IPV6
    if (server_ip -> nxd_ip_version == NX_IP_VERSION_V6)
    {
        ip_address_log = server_ip -> nxd_ip_address.v6[3];
    }
#endif /* FEATURE_NX_IPV6 */

    /* If trace is enabled, insert this event into the trace buffer.  */
    NX_TRACE_IN_LINE_INSERT(NX_TRACE_TCP_CLIENT_SOCKET_CONNECT, ip_ptr, socket_ptr, ip_address_log, server_port, NX_TRACE_TCP_EVENTS, 0, 0);
#endif /* TX_ENABLE_EVENT_TRACE */

    /* Obtain the IP mutex so we initiate the connect.  */
    tx_mutex_get(&(ip_ptr -> nx_ip_protection), TX_WAIT_FOREVER);

    /* Determine if the socket has already been bound to port or if a socket bind is
       already pending from another thread.  */
    if (!socket_ptr -> nx_tcp_socket_bound_next)
    {

        /* Release protection.  */
        tx_mutex_put(&(ip_ptr -> nx_ip_protection));

        /* Return a not bound error code.  */
        return(NX_NOT_BOUND);
    }

    /* Determine if the socket is in a pre-connection state.  */
    if ((socket_ptr -> nx_tcp_socket_state != NX_TCP_CLOSED) && (socket_ptr -> nx_tcp_socket_state != NX_TCP_TIMED_WAIT))
    {

        /* Release protection.  */
        tx_mutex_put(&(ip_ptr -> nx_ip_protection));

        /* Return a not closed error code.  */
        return(NX_NOT_CLOSED);
    }

#ifndef NX_DISABLE_TCP_INFO

    /* Increment the active connections count.  */
    ip_ptr -> nx_ip_tcp_active_connections++;

    /* Increment the TCP connections count.  */
    ip_ptr -> nx_ip_tcp_connections++;
#endif

    /* If trace is enabled, insert this event into the trace buffer.  */
    NX_TRACE_IN_LINE_INSERT(NX_TRACE_INTERNAL_TCP_STATE_CHANGE, ip_ptr, socket_ptr, socket_ptr -> nx_tcp_socket_state, NX_TCP_SYN_SENT, NX_TRACE_INTERNAL_EVENTS, 0, 0);

    /* Move the TCP state to Sequence Sent, the next state of an active open.  */
    socket_ptr -> nx_tcp_socket_state =  NX_TCP_SYN_SENT;

    /* Save the server port and server IP address.  */
    socket_ptr -> nx_tcp_socket_connect_ip.nxd_ip_version       = server_ip -> nxd_ip_version;

#ifndef NX_DISABLE_IPV4
    if (server_ip -> nxd_ip_version == NX_IP_VERSION_V4)
    {

        /* copy the IPv4 address */
        socket_ptr -> nx_tcp_socket_connect_ip.nxd_ip_address.v4 = server_ip -> nxd_ip_address.v4;

        ip_header_size = (UINT)sizeof(NX_IPV4_HEADER);
    }
#endif /* !NX_DISABLE_IPV4  */

#ifdef FEATURE_NX_IPV6
    if (server_ip -> nxd_ip_version == NX_IP_VERSION_V6)
    {
        COPY_IPV6_ADDRESS(server_ip -> nxd_ip_address.v6,
                          socket_ptr -> nx_tcp_socket_connect_ip.nxd_ip_address.v6);

        ip_header_size = (UINT)sizeof(NX_IPV6_HEADER);
    }
#endif /* FEATURE_NX_IPV6 */

    socket_ptr -> nx_tcp_socket_connect_port = server_port;

    /* Outgoing interface must not be null. */
    NX_ASSERT(outgoing_interface != NX_NULL);

    /* Initialize the maximum segment size based on the interface MTU. */
    /*lint -e{644} suppress variable might not be initialized, since "outgoing_interface" was initialized by _nx_ip_route_find or _nxd_ipv6_interface_find. */
    if (outgoing_interface -> nx_interface_ip_mtu_size < (ip_header_size + NX_TCP_SYN_SIZE))
    {

        /* Interface MTU size is smaller than IP and TCP header size.  Invalid interface! */

#ifndef NX_DISABLE_TCP_INFO

        /* Reduce the active connections count.  */
        ip_ptr -> nx_ip_tcp_active_connections--;

        /* Reduce the TCP connections count.  */
        ip_ptr -> nx_ip_tcp_connections--;
#endif

        /* Restore the socket state. */
        socket_ptr -> nx_tcp_socket_state = NX_TCP_CLOSED;

        /* Reset server port and server IP address. */
        memset(&socket_ptr -> nx_tcp_socket_connect_ip, 0, sizeof(NXD_ADDRESS));
        socket_ptr -> nx_tcp_socket_connect_port = 0;

        /* Reset the next_hop_address information. */
        socket_ptr -> nx_tcp_socket_next_hop_address = 0;

        /* Release protection.  */
        tx_mutex_put(&(ip_ptr -> nx_ip_protection));


        /* Return an IP address error code.  */
        return(NX_INVALID_INTERFACE);
    }

    socket_ptr -> nx_tcp_socket_connect_interface = outgoing_interface;

    /* Setup the initial sequence number.  */
    if (socket_ptr -> nx_tcp_socket_tx_sequence == 0)
    {
        socket_ptr -> nx_tcp_socket_tx_sequence =  (((ULONG)NX_RAND()) << NX_SHIFT_BY_16) & 0xFFFFFFFF;
        socket_ptr -> nx_tcp_socket_tx_sequence |= (ULONG)NX_RAND();
    }
    else
    {
        socket_ptr -> nx_tcp_socket_tx_sequence =  socket_ptr -> nx_tcp_socket_tx_sequence + ((ULONG)(((ULONG)0x10000))) + ((ULONG)NX_RAND());
    }

    /* Ensure the rx window size logic is reset.  */
    socket_ptr -> nx_tcp_socket_rx_window_current =    socket_ptr -> nx_tcp_socket_rx_window_default;
    socket_ptr -> nx_tcp_socket_rx_window_last_sent =  socket_ptr -> nx_tcp_socket_rx_window_default;

    /* Clear the FIN received flag.  */
    socket_ptr -> nx_tcp_socket_fin_received =  NX_FALSE;
    socket_ptr -> nx_tcp_socket_fin_acked =  NX_FALSE;

    /* Increment the sequence number.  */
    socket_ptr -> nx_tcp_socket_tx_sequence++;

    /* Setup a timeout so the connection attempt can be sent again.  */
    socket_ptr -> nx_tcp_socket_timeout =          socket_ptr -> nx_tcp_socket_timeout_rate;
    socket_ptr -> nx_tcp_socket_timeout_retries =  0;

    /* CLEANUP: In case any existing packets on socket's receive queue.  */
    if (socket_ptr -> nx_tcp_socket_receive_queue_count)
    {

        /* Remove all packets on the socket's receive queue.  */
        _nx_tcp_socket_receive_queue_flush(socket_ptr);
    }

    /* CLEANUP: Clean up any existing socket data before making a new connection. */
    socket_ptr -> nx_tcp_socket_tx_window_congestion = 0;
    socket_ptr -> nx_tcp_socket_tx_outstanding_bytes = 0;
    socket_ptr -> nx_tcp_socket_packets_sent         = 0;
    socket_ptr -> nx_tcp_socket_bytes_sent           = 0;
    socket_ptr -> nx_tcp_socket_packets_received     = 0;
    socket_ptr -> nx_tcp_socket_bytes_received       = 0;
    socket_ptr -> nx_tcp_socket_retransmit_packets   = 0;
    socket_ptr -> nx_tcp_socket_checksum_errors      = 0;
    socket_ptr -> nx_tcp_socket_transmit_sent_head   = NX_NULL;
    socket_ptr -> nx_tcp_socket_transmit_sent_tail   = NX_NULL;
    socket_ptr -> nx_tcp_socket_transmit_sent_count  = 0;
    socket_ptr -> nx_tcp_socket_receive_queue_count  = 0;
    socket_ptr -> nx_tcp_socket_receive_queue_head   = NX_NULL;
    socket_ptr -> nx_tcp_socket_receive_queue_tail   = NX_NULL;

    /* Send the SYN message.  */
    _nx_tcp_packet_send_syn(socket_ptr, (socket_ptr -> nx_tcp_socket_tx_sequence - 1));

    /* Optionally suspend the thread.  If timeout occurs, return a connection timeout status.  If
       immediate response is selected, return a connection in progress status.  Only on a real
       connection should success be returned.  */
    if ((wait_option) && (_tx_thread_current_ptr != &(ip_ptr -> nx_ip_thread)))
    {

        /* Suspend the thread on this socket's connection attempt.  */
        /* Note: the IP protection mutex is released inside _nx_tcp_socket_thread_suspend().  */

        _nx_tcp_socket_thread_suspend(&(socket_ptr -> nx_tcp_socket_connect_suspended_thread), _nx_tcp_connect_cleanup, socket_ptr, &(ip_ptr -> nx_ip_protection), wait_option);

        /* Just return the completion code.  */
        return(_tx_thread_current_ptr -> tx_thread_suspend_status);
    }
    else
    {

        /* No suspension is request, just release protection and return to the caller.  */

        /* Release the IP protection.  */
        tx_mutex_put(&(ip_ptr -> nx_ip_protection));

        /* Return in-progress completion status.  */
        return(NX_IN_PROGRESS);
    }
}

