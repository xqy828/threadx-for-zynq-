/**************************************************************************/
/*                                                                        */
/*            Copyright (c)  1996-2018 by Express Logic Inc.              */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Protocol (IP)                                              */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_ip.h"

#ifndef NX_DISABLE_IPV4
/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_ip_route_find                                   PORTABLE C      */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function finds an outgoing interface and the next hop address  */
/*     for a given destination address.  Caller may also set desired      */
/*     interface information in the ip_interface_ptr input.  For multicast*/
/*     or limited broadcast, this routine uses primary interface if       */
/*     a hint was not set by the caller.  For directed broadcast or       */
/*     unicast destinations, the hint is ignored and the proper outgoing  */
/*     interface is selected.                                             */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                IN              Pointer to IP instance        */
/*    destination_address   IN              Destination address           */
/*    ip_interface_ptr      OUT             Interface to use, must point  */
/*                                            to valid storage space.     */
/*    next_hop_address      OUT             IP address for the next hop,  */
/*                                            must point to valid storage */
/*                                            space.                      */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    NX_SUCCESS                            Operation was successful      */
/*    NX_IP_ADDRESS_ERROR                   No suitable interface found   */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    _nx_arp_dynamic_entry_set.c           ARP entry set                 */
/*    _nx_icmp_ping                         Transmit ICMP echo request    */
/*    _nx_ip_packet_send                    IP packet transmit            */
/*    _nx_tcp_client_socket_connect         TCP Client socket connection  */
/*    _nx_udp_socket_send                   UDP packet send               */
/*                                                                        */
/*  NOTE:                                                                 */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  10-10-2011     Yuxin Zhou               Initial Version 5.6           */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s), and      */
/*                                            fixed a bug in loopback     */
/*                                            interface processing,skipped*/
/*                                            interface which is down when*/
/*                                            finding route and gateway,  */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            optimized search operation  */
/*                                            for loopback address, fixed */
/*                                            a bug where the loopback    */
/*                                            interface was used for      */
/*                                            multicast or broadcast      */
/*                                            destinations, supported for */
/*                                            IPv4 link-local address,    */
/*                                            verified whether or not a   */
/*                                            router was reachable,       */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            fixed a bug that destination*/
/*                                            address is one of the local */
/*                                            interface addresses,        */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s), added    */
/*                                            support for disabling IPv4, */
/*                                            resulting in version 5.11   */
/*                                                                        */
/**************************************************************************/
ULONG  _nx_ip_route_find(NX_IP *ip_ptr, ULONG destination_address, NX_INTERFACE **ip_interface_ptr, ULONG *next_hop_address)
{

NX_INTERFACE *interface_ptr;
ULONG         i;

    /* Initialize the next hop address. */
    *next_hop_address = 0;

    /* Determine if the destination_address is multicast or directed broadcast. */
    if (((destination_address & NX_IP_CLASS_D_MASK) == NX_IP_CLASS_D_TYPE) ||
        (destination_address  == NX_IP_LIMITED_BROADCAST))
    {

        *next_hop_address = destination_address;

        /* If caller did not set the ip_interface value, use
           the primary interface for transmission.  */
        if (*ip_interface_ptr == NX_NULL)
        {

            /* Find an interface which is up. */
            for (i = 0; i < NX_MAX_PHYSICAL_INTERFACES; i++)
            {

                if (ip_ptr -> nx_ip_interface[i].nx_interface_link_up)
                {
                    *ip_interface_ptr = &(ip_ptr -> nx_ip_interface[i]);
                    return(NX_SUCCESS);
                }
            }
        }
        /* If the specified interface is up, return success. */
        else if ((*ip_interface_ptr) -> nx_interface_link_up)
        {
            return(NX_SUCCESS);
        }

        /* No available interface. */
        return(NX_IP_ADDRESS_ERROR);
    }

    /* Search through the interfaces associated with the IP instance,
       check if the the destination address is one of the local interface addresses. */
    for (i = 0; i < NX_MAX_PHYSICAL_INTERFACES; i++)
    {

        /* Use a local variable for convenience. */
        interface_ptr = &(ip_ptr -> nx_ip_interface[i]);

        /* Check for a valid interface that maps onto the same network domain as the destination address. */
        if ((interface_ptr -> nx_interface_valid) &&
            (interface_ptr -> nx_interface_link_up) &&
            (interface_ptr -> nx_interface_ip_address == destination_address) &&
            ((*ip_interface_ptr == NX_NULL) ||
             (*ip_interface_ptr == interface_ptr)))
        {

            /* Yes, use the entry information for interface and next hop. */
            *ip_interface_ptr = interface_ptr;
            *next_hop_address = destination_address;
            return(NX_SUCCESS);
        }
    }

#ifdef NX_ENABLE_IP_STATIC_ROUTING

    /* Search through the routing table for a suitable interface. */
    for (i = 0; i < ip_ptr -> nx_ip_routing_table_entry_count; i++)
    {

        /* Get the interface. */
        interface_ptr = ip_ptr -> nx_ip_routing_table[i].nx_ip_routing_entry_ip_interface;

        /* Skip interface that is not up. */
        if (interface_ptr -> nx_interface_link_up == NX_FALSE)
        {
            continue;
        }

        /* Does this table entry match the destination table network domain?*/
        if (ip_ptr -> nx_ip_routing_table[i].nx_ip_routing_dest_ip ==
            (destination_address & ip_ptr -> nx_ip_routing_table[i].nx_ip_routing_net_mask))
        {

            /* Yes, is next hop address still reachable? */
            if (interface_ptr -> nx_interface_ip_network !=
                (ip_ptr -> nx_ip_routing_table[i].nx_ip_routing_next_hop_address &
                 interface_ptr -> nx_interface_ip_network_mask))
            {
                continue;
            }

            /* Use the entry information for interface and next hop. */
            if (*ip_interface_ptr == NX_NULL)
            {
                *ip_interface_ptr = interface_ptr;
            }
            else if (*ip_interface_ptr != interface_ptr)
            {
                continue;
            }

            *next_hop_address = ip_ptr -> nx_ip_routing_table[i].nx_ip_routing_next_hop_address;

            return(NX_SUCCESS);
        }
    }

#endif /* NX_ENABLE_IP_STATIC_ROUTING */

    /* Search through the interfaces associated with the IP instance,
       check if the entry exists. */
    for (i = 0; i < NX_MAX_IP_INTERFACES; i++)
    {

        /* Use a local variable for convenience. */
        interface_ptr = &(ip_ptr -> nx_ip_interface[i]);

        /* Check for a valid interface that maps onto the same network domain as the destination address. */
        if ((interface_ptr -> nx_interface_valid) &&
            (interface_ptr -> nx_interface_link_up) &&
            ((interface_ptr -> nx_interface_ip_network_mask & destination_address) == interface_ptr -> nx_interface_ip_network))
        {

            /* Yes, use the entry information for interface and next hop. */
            if (*ip_interface_ptr == NX_NULL)
            {
                *ip_interface_ptr = interface_ptr;
            }
            /* Match loopback interface.  */
            /* Suppress constant value, since "NX_MAX_IP_INTERFACES" can be redefined. */
#if (NX_MAX_IP_INTERFACES == (NX_MAX_PHYSICAL_INTERFACES + 1))
            else if (i == NX_MAX_PHYSICAL_INTERFACES)
            {
                *ip_interface_ptr = interface_ptr;
            }
#endif
            else if (*ip_interface_ptr != interface_ptr)
            {
                continue;
            }

            *next_hop_address = destination_address;

            return(NX_SUCCESS);
        }
    }

    /* Search the interfaces for IPv4 Link-Local Address according to RFC3927, section2.6.  */
    /* Determine if destination addrss is link-local address(169.254/16 Hexadecimal:0xA9FE0000).  */
    if ((destination_address & 0xFFFF0000) == 0xA9FE0000)
    {

        /* Yes, check if the interface is set.  */
        if (*ip_interface_ptr)
        {

            /* Determine if the interface is valid.  */
            if (((*ip_interface_ptr) -> nx_interface_valid) &&
                ((*ip_interface_ptr) -> nx_interface_link_up))
            {

                /* Set the next hop address.  */
                *next_hop_address = destination_address;

                return(NX_SUCCESS);
            }
        }
        else
        {

            /* Search through the interfaces associated with the IP instance, set the inteface as first valid interface.  */
            for (i = 0; i < NX_MAX_IP_INTERFACES; i++)
            {

                /* Check for a valid interface that the address is link-local address.  */
                if ((ip_ptr -> nx_ip_interface[i].nx_interface_valid) &&
                    (ip_ptr -> nx_ip_interface[i].nx_interface_link_up))
                {

                    /* Yes, use the entry information for interface and next hop. */
                    *ip_interface_ptr = &(ip_ptr -> nx_ip_interface[i]);
                    *next_hop_address = destination_address;

                    return(NX_SUCCESS);
                }
            }
        }
    }

    /* Does the IP instance have a gateway? */
    if ((ip_ptr -> nx_ip_gateway_address) &&
        (ip_ptr -> nx_ip_gateway_interface) &&
        (ip_ptr -> nx_ip_gateway_interface -> nx_interface_link_up))
    {

        /* Get the interface. */
        interface_ptr = ip_ptr -> nx_ip_gateway_interface;

        /* Yes, is gateway address still reachable? */
        if (interface_ptr -> nx_interface_ip_network !=
            (ip_ptr -> nx_ip_gateway_address &
             interface_ptr -> nx_interface_ip_network_mask))
        {
            return(NX_IP_ADDRESS_ERROR);
        }

        /* Use the gateway as default. */
        if (*ip_interface_ptr == NX_NULL)
        {
            *ip_interface_ptr = interface_ptr;
        }
        else if (*ip_interface_ptr != interface_ptr)
        {
            return(NX_IP_ADDRESS_ERROR);
        }

        *next_hop_address = ip_ptr -> nx_ip_gateway_address;

        return(NX_SUCCESS);
    }

    /* Determine if source addrss is link-local address(169.254/16 Hexadecimal:0xA9FE0000).  */
    if (*ip_interface_ptr)
    {

        /* Determine if the interface is valid and the address of interface is link-local address.  */
        if (((*ip_interface_ptr) -> nx_interface_valid) &&
            ((*ip_interface_ptr) -> nx_interface_link_up) &&
            (((*ip_interface_ptr) -> nx_interface_ip_address & 0xFFFF0000) == 0xA9FE0000))
        {

            /* Set the next hop address.  */
            *next_hop_address = destination_address;

            return(NX_SUCCESS);
        }
    }
    else
    {

        /* Search through the interfaces associated with the IP instance,
           check if interface is valid and the address of interface is link-local address. */
        for (i = 0; i < NX_MAX_IP_INTERFACES; i++)
        {

            /* Use a local variable for convenience. */
            interface_ptr = &(ip_ptr -> nx_ip_interface[i]);

            /* Check for a valid interface that the address is link-local address.  */
            if ((interface_ptr -> nx_interface_valid) &&
                (interface_ptr -> nx_interface_link_up) &&
                ((interface_ptr -> nx_interface_ip_address & 0xFFFF0000) == 0xA9FE0000))
            {

                /* Yes, use the entry information for interface and next hop. */
                *ip_interface_ptr = interface_ptr;
                *next_hop_address = destination_address;

                return(NX_SUCCESS);
            }
        }
    }

    /* Cannot find a proper way to transmit this packet.
       Return the error status. */
    return(NX_IP_ADDRESS_ERROR);
}
#endif /* NX_DISABLE_IPV4 */

