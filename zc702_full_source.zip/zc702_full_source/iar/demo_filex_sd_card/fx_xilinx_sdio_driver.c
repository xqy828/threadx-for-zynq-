/**************************************************************************/ 
/*                                                                        */ 
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */ 
/*  This software is copyrighted by and is the sole property of Express   */ 
/*  Logic, Inc.  All rights, title, ownership, or other interests         */ 
/*  in the software remain the property of Express Logic, Inc.  This      */ 
/*  software may only be used in accordance with the corresponding        */ 
/*  license agreement.  Any unauthorized use, duplication, transmission,  */ 
/*  distribution, or disclosure of this software is expressly forbidden.  */ 
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */ 
/*  written consent of Express Logic, Inc.                                */ 
/*                                                                        */ 
/*  Express Logic, Inc. reserves the right to modify this software        */ 
/*  without notice.                                                       */ 
/*                                                                        */ 
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */ 
/** FileX Component                                                       */ 
/**                                                                       */
/**   Xilinx SDIO Driver                                                  */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/


/* Include necessary system files.  */


#include "tx_api.h"
#include "fx_api.h"
#include "xsdps.h"


XSdPs_Config * SD_ConfigPtr;

XSdPs SD_Instance;
UINT    _fx_partition_offset_calculate(void  *partition_sector, UINT partition,
									 ULONG *partition_start, ULONG *partition_size);

/**************************************************************************/ 
/*                                                                        */ 
/*  FUNCTION                                               RELEASE        */ 
/*                                                                        */ 
/*    _fx_xilinx_sdio_driver                              PORTABLE C      */
/*                                                           5.0          */ 
/*  AUTHOR                                                                */ 
/*                                                                        */ 
/*    William E. Lamie, Express Logic, Inc.                               */ 
/*                                                                        */ 
/*  DESCRIPTION                                                           */ 
/*                                                                        */ 
/*    This function is the entry point to the Xilinx SDIO disk driver.    */
/*    It relies on the xilinx peripheral BSP from Xilinx.                 */
/*                                                                        */ 
/*  INPUT                                                                 */ 
/*                                                                        */ 
/*    media_ptr                             Media control block pointer   */ 
/*                                                                        */ 
/*  OUTPUT                                                                */ 
/*                                                                        */ 
/*    None                                                                */ 
/*                                                                        */ 
/*  CALLS                                                                 */ 
/*                                                                        */ 
/*    _fx_utility_memory_copy               Copy sector memory            */ 
/*    _fx_utility_16_unsigned_read          Read 16-bit unsigned          */ 
/*                                                                        */ 
/*  CALLED BY                                                             */ 
/*                                                                        */ 
/*    FileX System Functions                                              */ 
/*                                                                        */ 
/*  RELEASE HISTORY                                                       */ 
/*                                                                        */ 
/*    DATE              NAME                      DESCRIPTION             */ 
/*                                                                        */ 
/*  04-01-2018     William E. Lamie         Initial Version 5.0           */
/*                                                                        */ 
/**************************************************************************/ 
VOID  _fx_xilinx_sdio_driver(FX_MEDIA *media_ptr)
{

UINT        status;
uint8_t     SDIO_Status;
ULONG       partition_start;
ULONG       partition_size;


    /* There are several useful/important pieces of information contained in the media
       structure, some of which are supplied by FileX and others are for the driver to
       setup. The following is a summary of the necessary FX_MEDIA structure members:
       
            FX_MEDIA Member                              Meaning
                                        
        fx_media_driver_request             FileX request type. Valid requests from FileX are 
                                            as follows:

                                                    FX_DRIVER_READ
                                                    FX_DRIVER_WRITE                 
                                                    FX_DRIVER_FLUSH
                                                    FX_DRIVER_ABORT
                                                    FX_DRIVER_INIT
                                                    FX_DRIVER_BOOT_READ
                                                    FX_DRIVER_RELEASE_SECTORS
                                                    FX_DRIVER_BOOT_WRITE
                                                    FX_DRIVER_UNINIT

        fx_media_driver_status              This value is RETURNED by the driver. If the 
                                            operation is successful, this field should be
                                            set to FX_SUCCESS for before returning. Otherwise,
                                            if an error occurred, this field should be set
                                            to FX_IO_ERROR. 

        fx_media_driver_buffer              Pointer to buffer to read or write sector data.
                                            This is supplied by FileX.

        fx_media_driver_logical_sector      Logical sector FileX is requesting.

        fx_media_driver_sectors             Number of sectors FileX is requesting.


       The following is a summary of the optional FX_MEDIA structure members:
       
            FX_MEDIA Member                              Meaning
                                        
        fx_media_driver_info                Pointer to any additional information or memory.
                                            This is optional for the driver use and is setup
                                            from the fx_media_open call. The RAM disk uses
                                            this pointer for the RAM disk memory itself.

        fx_media_driver_write_protect       The DRIVER sets this to FX_TRUE when media is write 
                                            protected. This is typically done in initialization, 
                                            but can be done anytime.

        fx_media_driver_free_sector_update  The DRIVER sets this to FX_TRUE when it needs to 
                                            know when clusters are released. This is important
                                            for FLASH wear-leveling drivers.

        fx_media_driver_system_write        FileX sets this flag to FX_TRUE if the sector being
                                            written is a system sector, e.g., a boot, FAT, or 
                                            directory sector. The driver may choose to use this
                                            to initiate error recovery logic for greater fault
                                            tolerance.

        fx_media_driver_data_sector_read    FileX sets this flag to FX_TRUE if the sector(s) being
                                            read are file data sectors, i.e., NOT system sectors.

        fx_media_driver_sector_type         FileX sets this variable to the specific type of 
                                            sector being read or written. The following sector
                                            types are identified:

                                                    FX_UNKNOWN_SECTOR 
                                                    FX_BOOT_SECTOR
                                                    FX_FAT_SECTOR
                                                    FX_DIRECTORY_SECTOR
                                                    FX_DATA_SECTOR  
    */

    /* Process the driver request specified in the media control block.  */
    switch(media_ptr -> fx_media_driver_request)
    {

        case FX_DRIVER_READ:
        {

            SDIO_Status = XSdPs_ReadPolled(&SD_Instance,
            							(media_ptr -> fx_media_driver_logical_sector + media_ptr -> fx_media_hidden_sectors),	/* SD card address     */
										media_ptr -> fx_media_driver_sectors,													/* Number of sectors   */
										(u8 *)media_ptr -> fx_media_driver_buffer);												/* Destination buffer  */
            /* Check status of SDIO Read.  */
            if (SDIO_Status == XST_SUCCESS)
            {
                /* Successful driver request.  */
                media_ptr -> fx_media_driver_status =  FX_SUCCESS;
            }
            else {
                /* Unsuccessful driver request.  */
                media_ptr -> fx_media_driver_status =  FX_IO_ERROR;
                break;
            }

            break;

        }
        
        case FX_DRIVER_WRITE:
        {

            SDIO_Status = XSdPs_WritePolled(&SD_Instance,
											(media_ptr -> fx_media_driver_logical_sector + media_ptr -> fx_media_hidden_sectors),
											media_ptr -> fx_media_driver_sectors,
											(u8 *)media_ptr -> fx_media_driver_buffer);
            /* Check status of SDIO Write.  */
            if (SDIO_Status == XST_SUCCESS)
            {
                /* Successful driver request.  */
                media_ptr -> fx_media_driver_status =  FX_SUCCESS;
            }
            else {
                /* Unsuccessful driver request.  */
                media_ptr -> fx_media_driver_status =  FX_IO_ERROR;
                break;
            }

            break;

        }

        case FX_DRIVER_FLUSH:
        {

            /* Return driver success.  */
            media_ptr -> fx_media_driver_status =  FX_SUCCESS;
            break;
        }

        case FX_DRIVER_ABORT:
        {

            /* Return driver success.  */
            media_ptr -> fx_media_driver_status =  FX_SUCCESS;
            break;
        }

    case FX_DRIVER_INIT:
        {
            /*get sd card config*/
			SD_ConfigPtr = XSdPs_LookupConfig(XPAR_PS7_SD_0_DEVICE_ID);
			/*initialize sd card instance*/
            XSdPs_CfgInitialize(&SD_Instance ,SD_ConfigPtr,SD_ConfigPtr -> BaseAddress);

            SDIO_Status = XSdPs_CardInitialize(&SD_Instance);

            /* Check status of SDIO Initialize.  */
            if (SDIO_Status == XST_SUCCESS)
                /* Successful driver request.  */
                media_ptr -> fx_media_driver_status =  FX_SUCCESS;
            else
                /* Unsuccessful driver request.  */
                media_ptr -> fx_media_driver_status =  FX_IO_ERROR;
            
            break;
        }

        case FX_DRIVER_UNINIT:
        {

            /* There is nothing to do in this case for the RAM driver.  For actual
               devices some shutdown processing may be necessary.  */

            /* Successful driver request.  */
            media_ptr -> fx_media_driver_status =  FX_SUCCESS;
            break;
        }

        case FX_DRIVER_BOOT_READ:
        {
            SDIO_Status = XSdPs_ReadPolled(&SD_Instance,0,1,(u8 *)media_ptr -> fx_media_driver_buffer);
            /* Check status of SDIO Read.  */
            if (SDIO_Status != XST_SUCCESS)
            {
                /* Unsuccessful driver request.  */
                media_ptr -> fx_media_driver_status =  FX_IO_ERROR;
                return;
            }

            /* Determine if we have the parition... */
            partition_start =  0;
            
            status =  _fx_partition_offset_calculate(media_ptr -> fx_media_driver_buffer, 0,
                                                                &partition_start, &partition_size);

            /* Check partition read error.  */
            if (status)
            {
                /* Unsuccessful driver request.  */
                media_ptr -> fx_media_driver_status =  FX_IO_ERROR;
                return;
            }

            /* Now determine if there is a partition...   */
            if (partition_start)
            {
                
                SDIO_Status = XSdPs_ReadPolled(&SD_Instance,partition_start,1,(u8 *)media_ptr -> fx_media_driver_buffer);
                /* Check status of SDIO Read.  */
                if (SDIO_Status != XST_SUCCESS)
                {

                    /* Unsuccessful driver request.  */
                    media_ptr -> fx_media_driver_status =  FX_IO_ERROR;
                    return;
                }
                
            }

            /* Successful driver request.  */
            media_ptr -> fx_media_driver_status =  FX_SUCCESS;
            break;
        }

        case FX_DRIVER_BOOT_WRITE:
        {

        	SDIO_Status = XSdPs_WritePolled(&SD_Instance,(media_ptr -> fx_media_hidden_sectors ),1,(u8 *)media_ptr -> fx_media_driver_buffer);


            /* Check status of SDIO Write.  */
            if (SDIO_Status == XST_SUCCESS)
            {
                /* Successful driver request.  */
                media_ptr -> fx_media_driver_status =  FX_SUCCESS;
            }
            else {
                /* Unsuccessful driver request.  */
                media_ptr -> fx_media_driver_status =  FX_IO_ERROR;
                break;
            }

            break ;
        }

        default:
        {

            /* Invalid driver request.  */
            media_ptr -> fx_media_driver_status =  FX_IO_ERROR;
            break;
        }
    }
}
