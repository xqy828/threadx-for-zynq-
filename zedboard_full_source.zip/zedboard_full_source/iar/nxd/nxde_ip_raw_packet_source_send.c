/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2016 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Protocol (IP)                                              */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_ip.h"
#include "nx_ipv6.h"

/* Bring in externs for caller checking code.  */

NX_CALLER_CHECKING_EXTERNS

/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nxde_ip_raw_packet_source_send                     PORTABLE C      */
/*                                                           5.10         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function does error checking for the raw IP packet send serivce*/
/*    out the specified IP source.                                        */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                Pointer to IP control block   */
/*    packet_ptr                            Pointer to packet to send     */
/*    destination_ip                        Destination IP address        */
/*    address_index                         Index to the IPv6 address     */
/*    protocol                              Value for the protocol field  */
/*    ttl                                   Value for ttl or hop limit    */
/*    tos                                   Value for tos or traffic      */
/*                                            class and flow label        */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    NX_PTR_ERROR                          Invalid pointer input         */
/*    NX_NOT_ENABLED                        Raw packet send not enabled   */
/*    NX_IP_ADDRESS_ERROR                   Invalid input address         */
/*    NX_INVALID_INTERFACE                  Invalid interface input       */
/*    status                                Completion status             */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    nxd_ip_raw_packet_source_send         Actual raw packet send service*/
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application                                                         */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  10-10-2011     Yuxin Zhou               Initial Version 5.6           */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            added tos and ttl to nxd    */
/*                                            raw packet send service,    */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s), and      */
/*                                            fixed address_index check,  */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            fixed address index check   */
/*                                            for loopback interface,     */
/*                                            added the check for packet  */
/*                                            internal points, resulting  */
/*                                            in version 5.9              */
/*  05-10-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            fixed lint warnings,        */
/*                                            resulting in version 5.10   */
/*                                                                        */
/**************************************************************************/
UINT  _nxde_ip_raw_packet_source_send(NX_IP *ip_ptr, NX_PACKET *packet_ptr,
                                      NXD_ADDRESS *destination_ip, UINT address_index, ULONG protocol, UINT ttl, ULONG tos)
{

UINT status;

    /* Check for invalid input pointers.  */
    if ((ip_ptr == NX_NULL) || (packet_ptr == NX_NULL) || (destination_ip == NX_NULL))
    {
        return(NX_PTR_ERROR);
    }

    /* Determine if raw IP packet sending/receiving is enabled.  */
    if (!ip_ptr -> nx_ip_raw_ip_processing)
    {
        return(NX_NOT_ENABLED);
    }

    /* Check that the destination address version is either IPv4 or IPv6. */
    if ((destination_ip -> nxd_ip_version != NX_IP_VERSION_V4) &&
        (destination_ip -> nxd_ip_version != NX_IP_VERSION_V6))
    {
        return(NX_IP_ADDRESS_ERROR);
    }

    if (destination_ip -> nxd_ip_version == NX_IP_VERSION_V4)
    {

        if (destination_ip -> nxd_ip_address.v4 == 0)
        {
            return(NX_IP_ADDRESS_ERROR);
        }

        /* Check for valid interface. */
        if (address_index >= NX_MAX_IP_INTERFACES)
        {
            return(NX_INVALID_INTERFACE);
        }

        /* Check for an invalid packet prepend pointer for IPv4 packet.  */
        /*lint -e{946} suppress pointer subtraction, since it is necessary. */
        if ((packet_ptr -> nx_packet_prepend_ptr - sizeof(NX_IPV4_HEADER)) < packet_ptr -> nx_packet_data_start)
        {
            return(NX_UNDERFLOW);
        }
    }

#ifdef FEATURE_NX_IPV6
    else
    {

        /* destination_ip -> nxd_ip_version == NX_IP_VERSION_V6.  */
        /* Check for valid destination address. */
        if (CHECK_UNSPECIFIED_ADDRESS(&destination_ip -> nxd_ip_address.v6[0]))
        {
            return(NX_IP_ADDRESS_ERROR);
        }

        /* Check for valid interface. */
        if (address_index >= NX_MAX_IPV6_ADDRESSES)
        {
            return(NX_IP_ADDRESS_ERROR);
        }

        /* Check for an invalid packet prepend pointer for IPv6 packet.  */
        /*lint -e{946} suppress pointer subtraction, since it is necessary. */
        if ((packet_ptr -> nx_packet_prepend_ptr - sizeof(NX_IPV6_HEADER)) < packet_ptr -> nx_packet_data_start)
        {
            return(NX_UNDERFLOW);
        }
    }
#endif /* FEATURE_NX_IPV6 */

    /* Check for an invalid packet append pointer.  */
    /*lint -e{946} suppress pointer subtraction, since it is necessary. */
    if (packet_ptr -> nx_packet_append_ptr > packet_ptr -> nx_packet_data_end)
    {
        return(NX_OVERFLOW);
    }

    /* Check for appropriate caller.  */
    NX_THREADS_ONLY_CALLER_CHECKING

    /* Call the actual service. */
    status = _nxd_ip_raw_packet_source_send(ip_ptr, packet_ptr, destination_ip, address_index, protocol, ttl, tos);

    /* Return completion status. */
    return(status);
}

