/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Control Message Protocol (ICMP)                            */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_ip.h"
#include "nx_icmp.h"


/* Bring in externs for caller checking code.  */

NX_CALLER_CHECKING_EXTERNS


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nxde_icmp_source_ping                              PORTABLE C      */
/*                                                           5.11 SP1     */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function checks for errors in the dual stack (IPv4 or IPv6     */
/*    ICMP ping service.                                                  */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                Pointer to IP instance        */
/*    ip_address                            IP address to ping            */
/*    address_index                         Index of IPv4 or IPv6 address */
/*                                            to use as the source address*/
/*    data_ptr                              User Data pointer             */
/*    data_size                             Size of User Data             */
/*    response_ptr                          Pointer to Response Packet    */
/*    wait_option                           Suspension option             */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _nxd_icmp_source_ping                 Actual ICMP ping function     */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  10-10-2011     Yuxin Zhou               Initial Version 5.6           */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s), checked  */
/*                                            interface validity,         */
/*                                            fixed compiler warnings,    */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            fixed address index check   */
/*                                            for loopback interface,     */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            removed unreachable code,   */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s), and      */
/*                                            merged IPv6 loopback address*/
/*                                            with normal IPv6 address,   */
/*                                            supported disabling IPv4,   */
/*                                            resulting in version 5.11   */
/*  12-15-2018     Yuxin Zhou               Modified comment(s), and      */
/*                                            supported for 64-bit mode,  */
/*                                            resulting in version 5.11SP1*/
/*                                                                        */
/**************************************************************************/
UINT  _nxde_icmp_source_ping(NX_IP *ip_ptr, NXD_ADDRESS *ip_address, UINT address_index,
                             CHAR *data_ptr, ULONG data_size,
                             NX_PACKET **response_ptr, ULONG wait_option)
{

UINT status;


    /* Check for invalid input pointers.  */
    if ((ip_ptr == NX_NULL) || (ip_ptr -> nx_ip_id != NX_IP_ID) || (response_ptr == NX_NULL))
    {
        return(NX_PTR_ERROR);
    }

    /* Check for invalid IP address.  */
    if (ip_address == NX_NULL)
    {
        return(NX_IP_ADDRESS_ERROR);
    }

    /* Check for invalid version. */
    if ((ip_address -> nxd_ip_version != NX_IP_VERSION_V4) &&
        (ip_address -> nxd_ip_version != NX_IP_VERSION_V6))
    {

        return(NX_IP_ADDRESS_ERROR);
    }

#ifndef NX_DISABLE_IPV4
    /* Check to see if ICMP is enabled.  */
    if (ip_address -> nxd_ip_version == NX_IP_VERSION_V4)
    {
        if (address_index >= NX_MAX_IP_INTERFACES)
        {
            return(NX_INVALID_INTERFACE);
        }


        /* Cast the function pointer into a ULONG. Since this is exactly what we wish to do, disable the lint warning with the following comment:  */
        /*lint -e{923} suppress cast of pointer to ULONG.  */
        if ((ALIGN_TYPE)ip_ptr -> nx_ip_icmpv4_packet_process == NX_NULL)
        {

            return(NX_NOT_ENABLED);
        }
    }
#endif /* NX_DISABLE_IPV4  */

#ifdef FEATURE_NX_IPV6
    if (ip_address -> nxd_ip_version == NX_IP_VERSION_V6)
    {
        if ((address_index >= (NX_MAX_IPV6_ADDRESSES + NX_LOOPBACK_IPV6_ENABLED)) ||
            (ip_ptr -> nx_ipv6_address[address_index].nxd_ipv6_address_attached == NX_NULL) ||
            (ip_ptr -> nx_ipv6_address[address_index].nxd_ipv6_address_valid == NX_FALSE))
        {
            return(NX_INVALID_INTERFACE);
        }

        /* Cast the function pointer into a ULONG. Since this is exactly what we wish to do, disable the lint warning with the following comment:  */
        /*lint -e{923} suppress cast of pointer to ULONG.  */
        if (((ALIGN_TYPE)ip_ptr -> nx_ip_icmpv6_packet_process == NX_NULL) ||
            ((ALIGN_TYPE)ip_ptr -> nx_ipv6_packet_receive == NX_NULL))
        {

            return(NX_NOT_ENABLED);
        }
    }
#endif /* FEATURE_NX_IPV6 */

    /* Check for appropriate caller.  */
    NX_THREADS_ONLY_CALLER_CHECKING

    /* Call actual ICMP ping function.  */
    status =  _nxd_icmp_source_ping(ip_ptr, ip_address, address_index, data_ptr, data_size,
                                    response_ptr, wait_option);

    /* Return completion status.  */
    return(status);
}

