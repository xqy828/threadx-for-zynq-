/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Ethernet driver for Xilinx Zynq UltraScale+ MPSoC GEM               */
/**                                                                       */
/**   Support for Ethernet PHY:                                           */
/**     Marvell 88E151x                                                   */
/**     TI DP83867                                                        */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_DRIVER_SOURCE
#include "nx_driver_zynqmp_gem.h"
#include "tx_zynqmp.h"


/* list of supported PHYs */
#define PHY_ID_UNKNOWN              0
#define PHY_ID_MARVELL_88E151x      1
#define PHY_ID_TI_DP83867           2

/* TI PHY registers */
#define PHY_REGCR             0x0D
#define PHY_ADDAR             0x0E
#define PHY_RGMIIDCTL         0x86
#define PHY_RGMIICTL          0x32
#define PHY_TI_CR             0x10
#define PHY_TI_CFG4           0x31
#define PHY_REGCR_ADDR        0x001F
#define PHY_REGCR_DATA        0x401F
#define PHY_TI_CRVAL          0x5048
#define PHY_TI_CFG4RESVDBIT7  0x80


/* check if the PHY is supported */
static USHORT get_phy_id(NX_DRIVER_INFORMATION *driver_ptr, UINT addr)
{
    UINT phy_id;

    /* get PHY identifier */
    phy_id = (nx_driver_zynqmp_mii_read(driver_ptr, addr, 2) << 16) | /* PHY Identifier 1 */
              nx_driver_zynqmp_mii_read(driver_ptr, addr, 3);         /* PHY Identifier 2 */

    /* check vendor OUI */
    switch (phy_id & 0xfffffc00u)
    {

    case 0x01410c00:  /* Marvell */

        if ((phy_id & 0x3f0) == 0x1d0)
        {
            return PHY_ID_MARVELL_88E151x;
        }
        break;

    case 0x2000a000:  /* TI */

        if ((phy_id & 0x3f0) == 0x230)
        {
            return PHY_ID_TI_DP83867;
        }
        break;

    default:          /* Unknown vendor */

        break;

    }

    return PHY_ID_UNKNOWN;
}


/* configure TI PHY */
static void phy_ti_reset(NX_DRIVER_INFORMATION *driver_ptr, UINT addr)
{
    UINT val;

    /* reset PHY */
    val = nx_driver_zynqmp_mii_read(driver_ptr, addr, 0x1f);
    val |= 0x4000;
    nx_driver_zynqmp_mii_write(driver_ptr, addr, 0x1f, val);
    val = nx_driver_zynqmp_mii_read(driver_ptr, addr, 0);
    val |= 0x8000;
    nx_driver_zynqmp_mii_write(driver_ptr, addr, 0, val);

    /* wait for completion */
    tx_zynqmp_udelay(1000);

    /* fifo depth */
    nx_driver_zynqmp_mii_write(driver_ptr, addr, PHY_TI_CR, PHY_TI_CRVAL);

    /* tx/rx tuning: */
    /* set RGMIIDCTL */
	  nx_driver_zynqmp_mii_write(driver_ptr, addr, PHY_REGCR, PHY_REGCR_ADDR);
	  nx_driver_zynqmp_mii_write(driver_ptr, addr, PHY_ADDAR, PHY_RGMIIDCTL);
	  nx_driver_zynqmp_mii_write(driver_ptr, addr, PHY_REGCR, PHY_REGCR_DATA);
	  nx_driver_zynqmp_mii_write(driver_ptr, addr, PHY_ADDAR, 0xA8);
    /* set RGMIICTL */
    nx_driver_zynqmp_mii_write(driver_ptr, addr, PHY_REGCR, PHY_REGCR_ADDR);
    nx_driver_zynqmp_mii_write(driver_ptr, addr, PHY_ADDAR, PHY_RGMIICTL);
    nx_driver_zynqmp_mii_write(driver_ptr, addr, PHY_REGCR, PHY_REGCR_DATA);
    nx_driver_zynqmp_mii_write(driver_ptr, addr, PHY_ADDAR, 0xD3);

    /* SW workaround for unstable link when RX_CTRL is not STRAP MODE 3 or 4 */
    nx_driver_zynqmp_mii_write(driver_ptr, addr, PHY_REGCR, PHY_REGCR_ADDR);
    nx_driver_zynqmp_mii_write(driver_ptr, addr, PHY_ADDAR, PHY_TI_CFG4);
    nx_driver_zynqmp_mii_write(driver_ptr, addr, PHY_REGCR, PHY_REGCR_DATA);
    val = nx_driver_zynqmp_mii_read(driver_ptr, addr, PHY_ADDAR);
    val &= ~PHY_TI_CFG4RESVDBIT7;
    nx_driver_zynqmp_mii_write(driver_ptr, addr, PHY_REGCR, PHY_REGCR_ADDR);
    nx_driver_zynqmp_mii_write(driver_ptr, addr, PHY_ADDAR, PHY_TI_CFG4);
    nx_driver_zynqmp_mii_write(driver_ptr, addr, PHY_REGCR, PHY_REGCR_DATA);
    nx_driver_zynqmp_mii_write(driver_ptr, addr, PHY_ADDAR, val);

    /* start auto-negociation */
    nx_driver_zynqmp_mii_write(driver_ptr, addr, 0, 0x1000);
}


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    nx_driver_zynqmp_phy_reset               Zynq UltraScale+ MPSoC/GNU */
/*                                                           5.0          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Regis Feneon, Express Logic France.                                 */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function detects the type of PHY, resets the link and          */
/*      starts auto-negociation.                                          */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    driver_ptr                            The driver instance           */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    nx_driver_zynqmp_mii_read/write       Access to PHY registers       */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    nx_driver_entry                       Driver entry point            */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  07-01-2018     Regis Feneon             Initial Version 5.0           */
/*                                                                        */
/**************************************************************************/
UINT nx_driver_zynqmp_phy_reset(NX_DRIVER_INFORMATION *driver_ptr)
{

    if (driver_ptr->nx_driver_information_phy_addr >= 32)
    {
        USHORT addr;

        /* try to auto-detect PHY address */
        for (addr = 0; addr < 32; addr++)
        {
            USHORT id;

            /* check if a known PHY is at this address */
            id = get_phy_id(driver_ptr, addr);
            if (id != PHY_ID_UNKNOWN)
            {
                driver_ptr->nx_driver_information_phy_id    = id;
                driver_ptr->nx_driver_information_phy_addr  = addr;
                break;
            }
        }
        if (addr >= 32)
        {
            /* valid PHY not found... */
            driver_ptr->nx_driver_information_phy_id = PHY_ID_UNKNOWN;
        }
    }
    else
    {
        /* get type of PHY */
        driver_ptr->nx_driver_information_phy_id = get_phy_id(driver_ptr, driver_ptr->nx_driver_information_phy_addr);
    }
    if (driver_ptr->nx_driver_information_phy_id == PHY_ID_UNKNOWN)
    {
        /* Unknown PHY */
        return NX_DRIVER_ERROR;
    }

    if (driver_ptr->nx_driver_information_phy_id == PHY_ID_TI_DP83867)
    {
        /* special initialization for TI PHY */
        phy_ti_reset(driver_ptr, driver_ptr->nx_driver_information_phy_addr);
    }
    else
    {
        /* write to Basic Control Register (Register 0) */
        /* enable auto-negociation mode and reset PHY */
        /* bit 15 Reset, */
        /* bit 12 Auto-Negociation Enable */
        nx_driver_zynqmp_mii_write(driver_ptr, driver_ptr->nx_driver_information_phy_addr, 0, 0x9000);
    }

    /* start reading Basic Status Register for link status (Register 1) */
    nx_driver_zynqmp_mii_read_async(driver_ptr, driver_ptr->nx_driver_information_phy_addr, 1);

    /* return success */
    return NX_SUCCESS;
}


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    nx_driver_zynqmp_phy_status              Zynq UltraScale+ MPSoC/GNU */
/*                                                           5.0          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Regis Feneon, Express Logic France.                                 */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function returns the current link configuration.               */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    driver_ptr                            The driver instance           */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    The current link configuration                                      */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    nx_driver_zynqmp_mii_read             Read PHY registers            */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    nx_driver_entry                       Driver entry point            */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  07-01-2018     Regis Feneon             Initial Version 5.0           */
/*                                                                        */
/**************************************************************************/
UINT nx_driver_zynqmp_phy_status(NX_DRIVER_INFORMATION *driver_ptr)
{
    UINT status, link;

    /* get read status async result */
    if (nx_driver_zynqmp_mii_read_async_get(driver_ptr, &status) != NX_SUCCESS)
    {
        /* not ready, return previous link state */
        return driver_ptr->nx_driver_information_link;
    }

    /* check if link status has changed */
    if (driver_ptr->nx_driver_information_link == NX_DRIVER_LINK_DOWN &&
        (status & 0x0004) != 0)
    {

        /* link is up, get link configuration */
        switch (driver_ptr->nx_driver_information_phy_id)
        {

        case PHY_ID_MARVELL_88E151x:
        case PHY_ID_TI_DP83867:

            /* read Copper Specific Status Register 1 (Register 17) */
            status = nx_driver_zynqmp_mii_read(driver_ptr, driver_ptr->nx_driver_information_phy_addr, 17);

            /* check if link is up */
            /* bit 10 Copper Link (real time), 1 = Link up, 0 = Link down */
            if (!(status & 0x0400))
            {
                link = NX_DRIVER_LINK_DOWN;
                break;
            }

            /* get link speed */
            /* bits 15:14 Speed, 11 = reserved, 10 = 1000 Mbps, 01 = 100 Mbps, 00 = 10 Mbps */
            switch (status & 0xc000)
            {
            case 0x8000:
                link = NX_DRIVER_LINK_SPEED_1000;
                break;
            case 0x4000:
                link = NX_DRIVER_LINK_SPEED_100;
                break;
            case 0x0000:
                link = NX_DRIVER_LINK_SPEED_10;
                break;
            default:
                /* XXX invalid configuration */
                link = NX_DRIVER_LINK_DOWN;
                break;
            }
            if (link == NX_DRIVER_LINK_DOWN)
            {
                break;
            }

            /* get duplex mode */
            /* bit 13 Duplex, 1 = Full-duplex, 0 = Half-duplex */
            if (status & 0x2000)
            {
                link |= NX_DRIVER_LINK_FULLDUPLEX;
            }

            break;

        default:

            /* XXX invalid PHY */
            link = NX_DRIVER_LINK_DOWN;
            break;

        }

    }
    else if (driver_ptr->nx_driver_information_link != NX_DRIVER_LINK_DOWN &&
             (status & 0x0004) == 0)
    {
        /* link is down */
        link = NX_DRIVER_LINK_DOWN;
    }
    else
    {
        /* no change */
        link = driver_ptr->nx_driver_information_link;
    }

    /* start next read async operation */
    nx_driver_zynqmp_mii_read_async(driver_ptr, driver_ptr->nx_driver_information_phy_addr, 1);

    /* return link state */
    return link;
}
