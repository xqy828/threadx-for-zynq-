#ifndef COMMON_HARDWARE_CODE_HEADER
#define COMMON_HARDWARE_CODE_HEADER

#include "tx_api.h"
//#include "stm32f7xx_hal.h"


/* Define prototypes. */
VOID hardware_setup();

#endif
