/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Control Message Protocol (ICMP)                            */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_ipv6.h"
#include "nx_icmpv6.h"

#ifdef FEATURE_NX_IPV6

/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_icmpv6_validate_options                         PORTABLE C      */
/*                                                           5.11 SP1     */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function validates ICMPv6 additional options.                  */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    option                       Pointer to ICMPv6 option               */
/*    length                       Length of the Option field             */
/*    additional_check             Whether or not caller wishes to        */
/*                                    perform additoinal verification     */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    NX_SUCCESS                   Options are valid                      */
/*    NX_NOT_SUCCESS               Options are invalid                    */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    _nx_icmpv6_validate_neighbor_messages                               */
/*    _nx_icmpv6_validate_ra                                              */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-30-2007     Yuxin Zhou               Initial Version 5.2           */
/*  08-03-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            modified struct field names */
/*                                            missing struct name prefix, */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s), improved */
/*                                            packet length verification, */
/*                                            resulting in version 5.11   */
/*  12-15-2018     Yuxin Zhou               Modified comment(s), and      */
/*                                            supported for 64-bit mode,  */
/*                                            resulting in version 5.11SP1*/
/*                                                                        */
/**************************************************************************/
UINT _nx_icmpv6_validate_options(NX_ICMPV6_OPTION *option, INT length, INT additional_check)
{

UINT option_len;

    /* Parse all option headers from the ICMPv6 header. */
    while (length > 0)
    {
        /* Verify that the option length is not zero. */
        if (option -> nx_icmpv6_option_length == 0)
        {
            return(NX_NOT_SUCCESSFUL);
        }

        /* Also check for NO SOURCE LINK LAYER ADDRESS.  */
        if ((additional_check == NX_NO_SLLA) &&
            (option -> nx_icmpv6_option_type == 1))
        {

            return(NX_NOT_SUCCESSFUL);
        }

        /* Get the next option. */
        option_len = ((UINT)option -> nx_icmpv6_option_length) << 3;
        length -= (INT)option_len;

        /*lint -e{923} suppress cast between pointer and ULONG, since it is necessary  */
        option = (NX_ICMPV6_OPTION *)NX_UCHAR_POINTER_ADD(option, option_len);
    }

    if (length < 0)
    {

        /* Invalid packet length. */
        return(NX_NOT_SUCCESSFUL);
    }

    return(NX_SUCCESS);
}

#endif /* FEATURE_NX_IPV6 */

