/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Neighbor Discovery Cache                                            */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_ipv6.h"
#include "nx_nd_cache.h"

#ifdef FEATURE_NX_IPV6


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    nx_nd_cache_find_entry                              PORTABLE C      */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This internal function finds an entry in the ND cache that is       */
/*    mapped to the specified IPv6 address.                               */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                   IP instance pointer                        */
/*    dest_ip                  The IP address to match                    */
/*    nd_cache_entry           User specified storage space of pointer to */
/*                                the corresponding ND cache.             */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                   NX_SUCCESS: The ND cache entry is located. */
/*                                nd_cache_entry contains valid value.    */
/*                             NX_NOT_SUCCESSFUL:  The ND cache entry     */
/*                                cannot be found, or nd_cache_entry is   */
/*                                NULL.                                   */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-30-2007     Yuxin Zhou               Initial Version 5.2           */
/*  08-03-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            modified struct field names */
/*                                            missing struct name prefix, */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Added a check to make sure    */
/*                                            this function only operates */
/*                                            on an entry owned by ip_ptr,*/
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s), fixed    */
/*                                            a bug where an incorrect    */
/*                                            index value is used,        */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s), and      */
/*                                            fixed compiler warnings,    */
/*                                            removed mutex release that  */
/*                                            is not necessary,           */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            optimized the code,         */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s), and      */
/*                                            moved the destination table */
/*                                            to the IP structure,        */
/*                                            resulting in version 5.11   */
/*                                                                        */
/**************************************************************************/
UINT _nx_nd_cache_find_entry(NX_IP *ip_ptr,
                             ULONG *dest_ip, ND_CACHE_ENTRY **nd_cache_entry)
{
UINT i;
UINT index;

    /* Initialize the return value. */
    *nd_cache_entry = NX_NULL;

    /* Compute a simple hash based on the dest_ip */
    index = (UINT)((dest_ip[0] + dest_ip[1] + dest_ip[2] + dest_ip[3]) %
                   (NX_IPV6_NEIGHBOR_CACHE_SIZE));

    for (i = 0; i < NX_IPV6_NEIGHBOR_CACHE_SIZE; i++)
    {

        if ((ip_ptr -> nx_ipv6_nd_cache[index].nx_nd_cache_nd_status != ND_CACHE_STATE_INVALID) &&
            (ip_ptr -> nx_ipv6_nd_cache[index].nx_nd_cache_interface_ptr) &&
            (CHECK_IPV6_ADDRESSES_SAME(&ip_ptr -> nx_ipv6_nd_cache[index].nx_nd_cache_dest_ip[0], dest_ip)))
        {

            /* find the entry */
            *nd_cache_entry = &ip_ptr -> nx_ipv6_nd_cache[index];

            return(NX_SUCCESS);
        }

        index++;

        /* Check for overflow */
        if (index == NX_IPV6_NEIGHBOR_CACHE_SIZE)
        {
            index = 0;
        }
    }

    return(NX_NOT_SUCCESSFUL);
}

#endif /* FEATURE_NX_IPV6 */

