/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Group Management Protocol (IGMP)                           */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_igmp.h"

#ifndef NX_DISABLE_IPV4
/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_igmp_multicast_interface_join_internal          PORTABLE C      */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function handles the request to join the specified multicast   */
/*    group on a specified network device.                                */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                IP instance pointer           */
/*    group_address                         Multicast group to join       */
/*    interface_index                       Index to the interface        */
/*    update_time                           Update time                   */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                                Completion status             */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    tx_mutex_get                          Obtain protection mutex       */
/*    tx_mutex_put                          Release protection mutex      */
/*    (ip_link_driver)                      Associated IP link driver     */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  01-12-2015     Yuxin Zhou               Initial Version 5.8           */
/*  02-22-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s), added    */
/*                                            support for disabling IPv4, */
/*                                            resulting in version 5.11   */
/*                                                                        */
/**************************************************************************/
UINT  _nx_igmp_multicast_interface_join_internal(NX_IP *ip_ptr, ULONG group_address,
                                                 UINT interface_index, UINT update_time)
{

UINT          i;
UINT          first_free;
NX_IP_DRIVER  driver_request;
NX_INTERFACE *nx_interface;

    /* If trace is enabled, insert this event into the trace buffer.  */
    NX_TRACE_IN_LINE_INSERT(NX_TRACE_IGMP_MULTICAST_JOIN, ip_ptr, group_address, interface_index, 0, NX_TRACE_IGMP_EVENTS, 0, 0);

    /* Obtain the IP mutex so we can search the multicast join list.  */
    tx_mutex_get(&(ip_ptr -> nx_ip_protection), TX_WAIT_FOREVER);

    nx_interface = &ip_ptr -> nx_ip_interface[interface_index];

    /* Search the multicast join list for either the same group request.  */
    first_free =     NX_MAX_MULTICAST_GROUPS;

    for (i = 0; i < NX_MAX_MULTICAST_GROUPS; i++)
    {

        /* Determine if the specified entry is already in the multicast join list.  */
        if ((ip_ptr -> nx_ipv4_multicast_entry[i].nx_ipv4_multicast_join_list == group_address) &&
            (ip_ptr -> nx_ipv4_multicast_entry[i].nx_ipv4_multicast_join_interface_list == nx_interface))
        {

            /* Yes, we have found the same entry.  The only thing required in this
               case is to increment the join count and return.  */
            ip_ptr -> nx_ipv4_multicast_entry[i].nx_ipv4_multicast_join_count++;

            /* Release the IP protection.  */
            tx_mutex_put(&(ip_ptr -> nx_ip_protection));

            /* Return success!  */
            return(NX_SUCCESS);
        }

        /* Check for an empty entry.  */
        if ((ip_ptr -> nx_ipv4_multicast_entry[i].nx_ipv4_multicast_join_list == 0) &&
            (first_free == NX_MAX_MULTICAST_GROUPS))
        {

            /* Remember the first free entry.  */
            first_free =  i;
        }
    }

    /* At this point, we have a new entry.   First, check to see if there is an available
       entry.  */
    if (first_free == NX_MAX_MULTICAST_GROUPS)
    {

        /* Release the protection of the IP instance.  */
        tx_mutex_put(&(ip_ptr -> nx_ip_protection));

        /* Return an error code to indicate there are no more group addresses
           available.  */
        return(NX_NO_MORE_ENTRIES);
    }

    /* Register the new multicast group with the underlying driver to
       ensure that there is room for the new group at the hardware level.  */
    driver_request.nx_ip_driver_ptr                  =   ip_ptr;
    driver_request.nx_ip_driver_command              =   NX_LINK_MULTICAST_JOIN;
    driver_request.nx_ip_driver_physical_address_msw =   NX_IP_MULTICAST_UPPER;
    driver_request.nx_ip_driver_physical_address_lsw =   NX_IP_MULTICAST_LOWER | (group_address & NX_IP_MULTICAST_MASK);
    driver_request.nx_ip_driver_interface            =   nx_interface;

    /* If trace is enabled, insert this event into the trace buffer.  */
    NX_TRACE_IN_LINE_INSERT(NX_TRACE_INTERNAL_IO_DRIVER_MULTICAST_JOIN, ip_ptr, 0, 0, 0, NX_TRACE_INTERNAL_EVENTS, 0, 0);

    (nx_interface -> nx_interface_link_driver_entry)(&driver_request);

    /* Check the return driver status.   */
    /*lint -e{644} suppress variable might not be initialized, since "nx_ip_driver_status" was initialized in nx_interface_link_driver_entry. */
    if (driver_request.nx_ip_driver_status != NX_SUCCESS)
    {

        /* Release the protection of the IP instance.  */
        tx_mutex_put(&(ip_ptr -> nx_ip_protection));

        /* Return an error code to indicate there are no more group addresses
           available.  */
        return(NX_NO_MORE_ENTRIES);
    }

    /* Set it up in the IP control structures.  */
    ip_ptr -> nx_ipv4_multicast_entry[first_free].nx_ipv4_multicast_join_list =           group_address;
    ip_ptr -> nx_ipv4_multicast_entry[first_free].nx_ipv4_multicast_join_interface_list = nx_interface;
    ip_ptr -> nx_ipv4_multicast_entry[first_free].nx_ipv4_multicast_join_count =          1;
    ip_ptr -> nx_ipv4_multicast_entry[first_free].nx_ipv4_multicast_update_time =         update_time;   /* Update on next IGMP periodic  */
    ip_ptr -> nx_ipv4_multicast_entry[first_free].nx_ipv4_multicast_loopback_enable =     ip_ptr -> nx_ip_igmp_global_loopback_enable;

#ifndef NX_DISABLE_IGMP_INFO
    /* Increment the IGMP groups joined count.  */
    ip_ptr -> nx_ip_igmp_groups_joined++;
#endif

    /* Release the protection over the IP instance.  */
    tx_mutex_put(&(ip_ptr -> nx_ip_protection));

    /* Return a successful status!  */
    return(NX_SUCCESS);
}
#endif /* !NX_DISABLE_IPV4  */

