/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2017 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** FileX Component                                                       */
/**                                                                       */
/**   Unicode                                                             */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/


/**************************************************************************/
/*                                                                        */
/*  COMPONENT DEFINITION                                   RELEASE        */
/*                                                                        */
/*    fx_unicode.h                                        PORTABLE C      */
/*                                                           5.5          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This file defines the FileX Unicode component constants, data       */
/*    definitions, and external references.  It is assumed that fx_api.h  */
/*    (and fx_port.h) have already been included.                         */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-12-2005     William E. Lamie         Initial Version 5.0           */
/*  07-18-2007     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.1    */
/*  03-01-2009     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.2    */
/*  11-01-2015     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.3    */
/*  04-15-2016     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  04-03-2017     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.5    */
/*                                                                        */
/**************************************************************************/

#ifndef FX_UNICODE_H
#define FX_UNICODE_H


/* Define external data for the Unicode component.  */

extern UCHAR   _fx_unicode_temp_long_file_name[FX_MAX_LONG_NAME_LEN];
extern UCHAR _fx_unicode_search_name[FX_MAX_LONG_NAME_LEN * 2];


/* Define the external Unicode component function prototypes.  */

UINT  _fx_unicode_directory_create(FX_MEDIA *media_ptr, UCHAR *source_unicode_name, ULONG source_unicode_length,
                                   CHAR *short_name);
UINT  _fx_unicode_directory_rename(FX_MEDIA *media_ptr, UCHAR *old_unicode_name, ULONG old_unicode_length,
                                   UCHAR *new_unicode_name, ULONG new_unicode_length, CHAR *new_short_name);
UINT  _fx_unicode_file_create(FX_MEDIA *media_ptr, UCHAR *source_unicode_name, ULONG source_unicode_length,
                              CHAR *short_name);
ULONG _fx_unicode_length_get(UCHAR *unicode_name);
UINT  _fx_unicode_name_get(FX_MEDIA *media_ptr, CHAR *source_short_name,
                           UCHAR *destination_unicode_name, ULONG *destination_unicode_length);
UINT  _fx_unicode_file_rename(FX_MEDIA *media_ptr, UCHAR *old_unicode_name, ULONG old_unicode_length,
                              UCHAR *new_unicode_name, ULONG new_unicode_length, CHAR *new_short_name);
UINT  _fx_unicode_short_name_get(FX_MEDIA *media_ptr, UCHAR *source_unicode_name, ULONG source_unicode_length,
                                 CHAR *destination_short_name);

UINT _fxe_unicode_directory_create(FX_MEDIA *media_ptr, UCHAR *source_unicode_name, ULONG source_unicode_length,
                                   CHAR *short_name);
UINT _fxe_unicode_directory_rename(FX_MEDIA *media_ptr, UCHAR *old_unicode_name, ULONG old_unicode_length,
                                   UCHAR *new_unicode_name, ULONG new_unicode_length, CHAR *new_short_name);
UINT _fxe_unicode_file_create(FX_MEDIA *media_ptr, UCHAR *source_unicode_name, ULONG source_unicode_length,
                              CHAR *short_name);
UINT _fxe_unicode_file_rename(FX_MEDIA *media_ptr, UCHAR *old_unicode_name, ULONG old_unicode_length,
                              UCHAR *new_unicode_name, ULONG new_unicode_length, CHAR *new_short_name);
UINT _fxe_unicode_name_get(FX_MEDIA *media_ptr, CHAR *source_short_name,
                           UCHAR *destination_unicode_name, ULONG *destination_unicode_length);
UINT _fxe_unicode_short_name_get(FX_MEDIA *media_ptr, UCHAR *source_unicode_name, ULONG source_unicode_length,
                                 CHAR *destination_short_name);


/* Define the internal Unicode component function prototypes.  */

UINT _fx_unicode_directory_search(FX_MEDIA *media_ptr, FX_DIR_ENTRY *entry_ptr,
                                  UCHAR *short_name, UCHAR *unicode_name, ULONG *unicode_name_length);
UINT _fx_unicode_directory_entry_read(FX_MEDIA *media_ptr, FX_DIR_ENTRY *source_dir,
                                      ULONG *entry_ptr, FX_DIR_ENTRY *destination_ptr,
                                      UCHAR *unicode_name, ULONG *unicode_size);
UINT _fx_unicode_directory_entry_change(FX_MEDIA *media_ptr, FX_DIR_ENTRY *entry_ptr, UCHAR *unicode_name, ULONG unicode_name_length);


#endif

