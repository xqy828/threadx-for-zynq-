/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Control Message Protocol (ICMP)                            */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_icmp.h"
#include "nx_ip.h"


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_icmp_ping                                       PORTABLE C      */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function finds a suitable interface and calls interface ping.  */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                Pointer to IP instance        */
/*    ip_address                            IP address to ping            */
/*    data_ptr                              User Data pointer             */
/*    data_size                             Size of User Data             */
/*    response_ptr                          Pointer to Response Packet    */
/*    wait_option                           Suspension option             */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _nx_ip_route_find                     Find suitable interface       */
/*    _nx_icmp_interface_ping               Send ping packet              */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-12-2005     William E. Lamie         Initial Version 5.0           */
/*  08-09-2007     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.1    */
/*  12-30-2007     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.2    */
/*  08-03-2009     William E. Lamie         Modified comment(s), added    */
/*                                            logic for trace support,    */
/*                                            added support for IPSec,    */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Cleaned up code:              */
/*                                            NX_ICMP_PACKET now has IPsec*/
/*                                            header built-in, thus does  */
/*                                            require manual offset       */
/*                                            adjustment, resulting in    */
/*                                            version 5.4                 */
/*  06-01-2010     Yuxin Zhou               Removed internal debug logic, */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s), added    */
/*                                            multihome support, use      */
/*                                            NX_DISABLE_ICMP_TX_CHECKSUM */
/*                                            to allow hardware checksum, */
/*                                            added IPsec support,        */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s), fixed    */
/*                                            a typo for PENDING_IKEv2,   */
/*                                            separated ICMPv4 checksum   */
/*                                            control from ICMPv6 checksum*/
/*                                            control, changed references */
/*                                            to IKE to IKEv2,            */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s), added    */
/*                                            optimized NX_PACKET_STRUCT, */
/*                                            fixed compiler warnings,    */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            moved the logic to function */
/*                                            _nx_icmp_interface_ping,    */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s), added    */
/*                                            support for disabling IPv4, */
/*                                            resulting in version 5.11   */
/*                                                                        */
/**************************************************************************/
UINT  _nx_icmp_ping(NX_IP *ip_ptr, ULONG ip_address,
                    CHAR *data_ptr, ULONG data_size,
                    NX_PACKET **response_ptr, ULONG wait_option)
{

#ifndef NX_DISABLE_IPV4
ULONG         next_hop_address;
NX_INTERFACE *interface_ptr = NX_NULL;


    /* Find a suitable interface for sending the ping packet. */
    if (_nx_ip_route_find(ip_ptr, ip_address, &interface_ptr, &next_hop_address) != NX_SUCCESS)
    {

        /* No suitable interface configured. */
        /* Clear the destination pointer.  */
        *response_ptr =  NX_NULL;

        /* Return the error status. */
        return(NX_IP_ADDRESS_ERROR);
    }

    /* Call interface ping service. */
    /*lint -e{644} suppress variable might not be initialized, since "interface_ptr" and "next_hop_address" were initialized in _nx_ip_route_find. */
    return(_nx_icmp_interface_ping(ip_ptr, ip_address, interface_ptr, next_hop_address,
                                   data_ptr, data_size, response_ptr, wait_option));
#else /* NX_DISABLE_IPV4  */
    NX_PARAMETER_NOT_USED(ip_ptr);
    NX_PARAMETER_NOT_USED(ip_address);
    NX_PARAMETER_NOT_USED(data_ptr);
    NX_PARAMETER_NOT_USED(data_size);
    NX_PARAMETER_NOT_USED(response_ptr);
    NX_PARAMETER_NOT_USED(wait_option);

    return(NX_NOT_SUPPORTED);
#endif /* !NX_DISABLE_IPV4  */
}

