/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2017 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** FileX Component                                                       */
/**                                                                       */
/**   System                                                              */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define FX_SOURCE_CODE


/* Include necessary system files.  */

#include "fx_api.h"
#include "fx_system.h"


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _fxe_system_date_set                                PORTABLE C      */
/*                                                           5.5          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function checks for errors in the set system date call.        */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    year                                  Year (1980-2107)              */
/*    month                                 Month (1-12)                  */
/*    day                                   Day (1-28/29/30/31)           */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    FX_INVALID_YEAR                       Supplied year is invalid      */
/*    FX_INVALID_MONTH                      Supplied month is invalid     */
/*    FX_INVALID_DAY                        Supplied day is invalid       */
/*    status                                Actual completion status      */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _fx_system_date_set                   Actual system date set call   */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-12-2005     William E. Lamie         Initial Version 5.0           */
/*  07-18-2007     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.1    */
/*  03-01-2009     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.2    */
/*  11-01-2015     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.3    */
/*  04-15-2016     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  04-03-2017     William E. Lamie         Modified comment(s), and      */
/*                                            optimized error checking    */ 
/*                                            logic, resulting in         */ 
/*                                            version 5.5                 */
/*                                                                        */
/**************************************************************************/
UINT  _fxe_system_date_set(UINT year, UINT month, UINT day)
{

UINT  status;


    /* Check for invalid year.  */
    if ((year < FX_BASE_YEAR) || (year > FX_MAXIMUM_YEAR))
    {
        return(FX_INVALID_YEAR);
    }

    /* Check for invalid day.  */
    if (day < 1)
    {
        return(FX_INVALID_DAY);
    }

    /* Check for invalid day.  */
    switch (month)
    {

    case 1:
    {

        /* Check for 31 days.  */
        if (day > 31)
        {
            return(FX_INVALID_DAY);
        }
        break;
    }

    case 2:
    {

        /* Check for leap year.  */
        if ((year % 4) == 0)
        {

            /* Leap year, February has 29 days.  */
            if (day > 29)
            {
                return(FX_INVALID_DAY);
            }
        }
        else
        {

            /* Otherwise, non-leap year.  February has
               28 days.  */
            if (day > 28)
            {
                return(FX_INVALID_DAY);
            }
        }
        break;
    }

    case 3:
    {

        /* Check for 31 days.  */
        if (day > 31)
        {
            return(FX_INVALID_DAY);
        }
        break;
    }

    case 4:
    {

        /* Check for 30 days.  */
        if (day > 30)
        {
            return(FX_INVALID_DAY);
        }
        break;
    }

    case 5:
    {

        /* Check for 31 days.  */
        if (day > 31)
        {
            return(FX_INVALID_DAY);
        }
        break;
    }

    case 6:
    {

        /* Check for 30 days.  */
        if (day > 30)
        {
            return(FX_INVALID_DAY);
        }
        break;
    }

    case 7:
    {

        /* Check for 31 days.  */
        if (day > 31)
        {
            return(FX_INVALID_DAY);
        }
        break;
    }

    case 8:
    {

        /* Check for 31 days.  */
        if (day > 31)
        {
            return(FX_INVALID_DAY);
        }
        break;
    }

    case 9:
    {

        /* Check for 30 days.  */
        if (day > 30)
        {
            return(FX_INVALID_DAY);
        }
        break;
    }

    case 10:
    {

        /* Check for 31 days.  */
        if (day > 31)
        {
            return(FX_INVALID_DAY);
        }
        break;
    }

    case 11:
    {

        /* Check for 30 days.  */
        if (day > 30)
        {
            return(FX_INVALID_DAY);
        }
        break;
    }

    case 12:
    {

        /* Check for 31 days.  */
        if (day > 31)
        {
            return(FX_INVALID_DAY);
        }
        break;
    }
    
    default:
    
        /* Invalid month.  */
        return(FX_INVALID_MONTH);
    }

    /* Call actual system date set service.  */
    status =  _fx_system_date_set(year, month, day);

    /* Return status.  */
    return(status);
}

