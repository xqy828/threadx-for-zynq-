/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2016 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Address Resolution Protocol (ARP)                                   */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_arp.h"


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_arp_ip_address_find                             PORTABLE C      */
/*                                                           5.10         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function searches for the specified hardware address in the    */
/*    ARP lists.  If found, the associated IP address is returned.        */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                IP instance pointer           */
/*    ip_address                            IP Address return pointer     */
/*    physical_msw                          Physical address MSW          */
/*    physical_lsw                          Physical address LSW          */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                                Completion status             */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    tx_mutex_get                          Obtain protection mutex       */
/*    tx_mutex_put                          Release protection mutex      */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-12-2005     William E. Lamie         Initial Version 5.0           */
/*  08-09-2007     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.1    */
/*  12-30-2007     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.2    */
/*  08-03-2009     William E. Lamie         Modified comment(s), and added*/
/*                                            logic for trace support,    */
/*                                            resulting in version 5.2    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*                                                                        */
/**************************************************************************/
UINT  _nx_arp_ip_address_find(NX_IP *ip_ptr, ULONG *ip_address,
                              ULONG physical_msw, ULONG physical_lsw)
{

NX_ARP *arp_entry;
ULONG   count;

#ifdef TX_ENABLE_EVENT_TRACE
TX_TRACE_BUFFER_ENTRY *trace_event;
ULONG                  trace_timestamp;
#endif


    /* If trace is enabled, insert this event into the trace buffer.  */
    NX_TRACE_IN_LINE_INSERT(NX_TRACE_ARP_IP_ADDRESS_FIND, ip_ptr, 0, physical_msw, physical_lsw, NX_TRACE_ARP_EVENTS, &trace_event, &trace_timestamp);

    /* Obtain protection on this IP instance for access into the ARP static
       list.  */
    tx_mutex_get(&(ip_ptr -> nx_ip_protection), TX_WAIT_FOREVER);

    /* Search the static list for matching hardware mapping.  */
    arp_entry =  ip_ptr -> nx_ip_arp_static_list;
    while (arp_entry)
    {

        /* Determine if we have a hardware address match.  */
        if ((arp_entry -> nx_arp_physical_address_msw == physical_msw) &&
            (arp_entry -> nx_arp_physical_address_lsw == physical_lsw))
        {

            /* Yes, we have found the ARP entry we are looking for.  */
            break;
        }
        else
        {

            /* Determine if we are at the end of the list.  */
            if (arp_entry -> nx_arp_pool_next == ip_ptr -> nx_ip_arp_static_list)
            {

                /* Set the arp_entry to NULL to signify nothing was found and get
                   out of the search loop.  */
                arp_entry =  NX_NULL;
                break;
            }
            else
            {

                /* Just move to the next ARP entry on the static list.  */
                arp_entry =  arp_entry -> nx_arp_pool_next;
            }
        }
    }

    /* Determine if an entry has been found.  If so, we are finished and it needs to be
       returned to the caller.  */
    if (arp_entry)
    {

        /* Store the IP address in the return field.  */
        *ip_address =  arp_entry -> nx_arp_ip_address;

        /* Update the trace event with the status.  */
        NX_TRACE_EVENT_UPDATE(trace_event, trace_timestamp, NX_TRACE_ARP_IP_ADDRESS_FIND, 0, *ip_address, 0, 0);

        /* Release the protection on the ARP list.  */
        tx_mutex_put(&(ip_ptr -> nx_ip_protection));

        /* Return status to the caller.  */
        return(NX_SUCCESS);
    }

    /* Otherwise, we need to search the ARP dynamic list for a match.  */
    arp_entry =  ip_ptr -> nx_ip_arp_dynamic_list;
    count =      1;
    while (arp_entry)
    {

        /* Determine if we have a hardware address match.  */
        if ((arp_entry -> nx_arp_physical_address_msw == physical_msw) &&
            (arp_entry -> nx_arp_physical_address_lsw == physical_lsw))
        {

            /* Yes, we have found the ARP entry we are looking for.  */
            break;
        }
        else
        {

            /* Determine if we are at the end of the list of active ARP entries.  */
            if (count >=  ip_ptr -> nx_ip_arp_dynamic_active_count)
            {

                /* Set the arp_entry to NULL to signify nothing was found and get
                   out of the search loop.  */
                arp_entry =  NX_NULL;
                break;
            }
            else
            {

                /* Just move to the next ARP entry on the dynamic list.  */
                arp_entry =  arp_entry -> nx_arp_pool_next;

                /* Increment the active count.  */
                count++;
            }
        }
    }

    /* Determine if an entry has been found.  If so, we are finished and it needs to be
       returned to the caller.  */
    if (arp_entry)
    {

        /* Store the IP address in the return fields.  */
        *ip_address =  arp_entry -> nx_arp_ip_address;

        /* Update the trace event with the status.  */
        NX_TRACE_EVENT_UPDATE(trace_event, trace_timestamp, NX_TRACE_ARP_IP_ADDRESS_FIND, 0, *ip_address, 0, 0);

        /* Release the protection on the ARP list.  */
        tx_mutex_put(&(ip_ptr -> nx_ip_protection));

        /* Return status to the caller.  */
        return(NX_SUCCESS);
    }
    else
    {

        /* Release the protection on the ARP list.  */
        tx_mutex_put(&(ip_ptr -> nx_ip_protection));

        /* Return status to the caller.  */
        return(NX_ENTRY_NOT_FOUND);
    }
}

