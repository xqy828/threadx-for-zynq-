/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2016 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Control Message Protocol (ICMP)                            */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_packet.h"
#include "nx_ip.h"
#include "nx_icmp.h"

#ifdef NX_IPSEC_ENABLE
#include "nx_ipsec.h"
#endif /* NX_IPSEC_ENABLE */


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_icmpv4_packet_process                           PORTABLE C      */
/*                                                           5.10 SP1     */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function processes the ICMPv4 received packet and lifts any    */
/*    associated threads suspended on it.                                 */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                Pointer to IP control block   */
/*    packet_ptr                            ICMP packet pointer           */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _nx_ip_checksum_compute               Compute checksum              */
/*    _nx_ip_packet_send                    Send ICMP packet out          */
/*    _nx_packet_release                    Release packet to packet pool */
/*    _tx_thread_system_resume              Resume suspended thread       */
/*    _tx_thread_system_preempt_check       Check for preemption          */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    _nx_icmp_packet_process               Main ICMP packet pocess       */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-12-2005     William E. Lamie         Initial Version 5.0           */
/*  08-09-2007     William E. Lamie         Modified comment(s), and      */
/*                                            removed ICMP header on echo */
/*                                            response packet, resulting  */
/*                                            in version 5.1              */
/*  12-30-2007     Yuxin Zhou               Modified comment(s), and      */
/*                                            added support for IPv6,     */
/*                                            resulting in version 5.2    */
/*  08-03-2009     William E. Lamie         Modified comment(s), added    */
/*                                            logic for trace support,    */
/*                                            added support for IPSec,    */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Removed internal debug logic, */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s), added    */
/*                                            multihome support, use      */
/*                                            NX_DISABLE_ICMP_TX_CHECKSUM */
/*                                            to allow hardware checksum, */
/*                                            added IPsec support,        */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s), fixed    */
/*                                            a typo for PENDING_IKEv2,   */
/*                                            separated ICMPv4 checksum   */
/*                                            control from ICMPv6 checksum*/
/*                                            control, changed references */
/*                                            to IKE to IKEv2,            */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s), added    */
/*                                            support for IP forwarding,  */
/*                                            optimized NX_PACKET_STRUCT, */
/*                                            fixed checksum zero for     */
/*                                            echo reply packet, fixed    */
/*                                            compiler warnings,          */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s), added    */
/*                                            support for packet          */
/*                                            debugging, split the funcion*/
/*                                            into two: process echo      */
/*                                            reply and echo request,     */
/*                                            renamed symbols, fixed      */
/*                                            compiler warnings, resulting*/
/*                                            in version 5.9              */
/*  05-10-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            optimized the logic of      */
/*                                            checksum calculation,       */
/*                                            resulting in version 5.10   */
/*  12-21-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            fixed compiler errors when  */
/*                                            event trace is enabled,     */
/*                                            resulting in version 5.10SP1*/
/*                                                                        */
/**************************************************************************/
VOID  _nx_icmpv4_packet_process(NX_IP *ip_ptr, NX_PACKET *packet_ptr)
{

NX_ICMPV4_HEADER *header_ptr;
USHORT            checksum;
#if defined(NX_DISABLE_ICMPV4_RX_CHECKSUM) || defined(NX_ENABLE_INTERFACE_CAPABILITY) || defined(NX_IPSEC_ENABLE)
UINT              compute_checksum = 1;
#endif /* defined(NX_DISABLE_ICMPV4_RX_CHECKSUM) || defined(NX_ENABLE_INTERFACE_CAPABILITY) || defined(NX_IPSEC_ENABLE) */
#ifdef TX_ENABLE_EVENT_TRACE
NX_IPV4_HEADER   *ip_header_ptr;
#endif /* TX_ENABLE_EVENT_TRACE */


    /* Add debug information. */
    NX_PACKET_DEBUG(__FILE__, __LINE__, packet_ptr);

    /* Point to the ICMP message header.  */
    /*lint -e{927} -e{826} suppress cast of pointer to pointer, since it is necessary  */
    header_ptr =  (NX_ICMPV4_HEADER *)packet_ptr -> nx_packet_prepend_ptr;

#ifdef NX_DISABLE_ICMPV4_RX_CHECKSUM
    compute_checksum = 0;
#endif /* NX_DISABLE_ICMPV4_RX_CHECKSUM */

#ifdef NX_ENABLE_INTERFACE_CAPABILITY
    if (packet_ptr -> nx_packet_address.nx_packet_interface_ptr -> nx_interface_capability_flag & NX_INTERFACE_CAPABILITY_ICMPV4_RX_CHECKSUM)
    {
        compute_checksum = 0;
    }
#endif /* NX_ENABLE_INTERFACE_CAPABILITY */
#ifdef NX_IPSEC_ENABLE
    if ((packet_ptr -> nx_packet_ipsec_sa_ptr != NX_NULL) && (((NX_IPSEC_SA *)(packet_ptr -> nx_packet_ipsec_sa_ptr)) -> nx_ipsec_sa_encryption_method != NX_CRYPTO_NONE))
    {
        compute_checksum = 1;
    }
#endif
#if defined(NX_DISABLE_ICMPV4_RX_CHECKSUM) || defined(NX_ENABLE_INTERFACE_CAPABILITY) || defined(NX_IPSEC_ENABLE)
    if (compute_checksum)
#endif /* defined(NX_DISABLE_ICMPV4_RX_CHECKSUM) || defined(NX_ENABLE_INTERFACE_CAPABILITY) || defined(NX_IPSEC_ENABLE) */
    {

        /* Calculate the ICMP message checksum.  */
        checksum =  _nx_ip_checksum_compute(packet_ptr, NX_IP_ICMP,
                                            (UINT)packet_ptr -> nx_packet_length,
                                            /* ICMPv4 checksum does not include
                                               src/dest addresses */
                                            NX_NULL, NX_NULL);

        checksum =  ((USHORT) ~checksum) & NX_LOWER_16_MASK;

        /* Determine if the checksum is valid.  */
        if (checksum)
        {

#ifndef NX_DISABLE_ICMP_INFO

            /* Increment the ICMP invalid packet error.  */
            ip_ptr -> nx_ip_icmp_invalid_packets++;

            /* Increment the ICMP checksum error count.  */
            ip_ptr -> nx_ip_icmp_checksum_errors++;
#endif

            /* Nope, the checksum is invalid.  Toss this ICMP packet out.  */
            _nx_packet_release(packet_ptr);
            return;
        }
    }

    /* Determine the message type and call the appropriate handler.  */
    if (header_ptr -> nx_icmpv4_header_type == NX_ICMP_ECHO_REPLY_TYPE)
    {
        _nx_icmpv4_process_echo_reply(ip_ptr, packet_ptr);
    }
    else if (header_ptr -> nx_icmpv4_header_type == NX_ICMP_ECHO_REQUEST_TYPE)
    {
        _nx_icmpv4_process_echo_request(ip_ptr, packet_ptr);
    }
    else
    {

#ifndef NX_DISABLE_ICMP_INFO

        /* Increment the ICMP unhandled message count.  */
        ip_ptr -> nx_ip_icmp_unhandled_messages++;
#endif

#ifdef TX_ENABLE_EVENT_TRACE

        /* Set the IP header.  */
        ip_header_ptr = (NX_IPV4_HEADER *)packet_ptr -> nx_packet_ip_header;

        /* If trace is enabled, insert this event into the trace buffer.  */
        NX_TRACE_IN_LINE_INSERT(NX_TRACE_INTERNAL_ICMP_RECEIVE, ip_ptr, ip_header_ptr -> nx_ip_header_source_ip, packet_ptr, 0, NX_TRACE_INTERNAL_EVENTS, 0, 0);
#endif /* TX_ENABLE_EVENT_TRACE  */

        /* Unhandled ICMP message, just release it.  */
        _nx_packet_release(packet_ptr);
    }
}

