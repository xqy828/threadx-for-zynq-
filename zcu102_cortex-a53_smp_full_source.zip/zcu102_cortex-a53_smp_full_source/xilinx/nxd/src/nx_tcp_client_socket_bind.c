/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Transmission Control Protocol (TCP)                                 */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_tcp.h"
#include "tx_thread.h"


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_tcp_client_socket_bind                          PORTABLE C      */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function binds the TCP socket structure to a specific TCP      */
/*    port.                                                               */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    socket_ptr                            Pointer to TCP socket         */
/*    port                                  16-bit TCP port number        */
/*    wait_option                           Suspension option             */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                                Completion status             */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _nx_tcp_free_port_find                Find free TCP port            */
/*    _nx_tcp_socket_thread_suspend         Suspend thread                */
/*    tx_mutex_get                          Obtain protection mutex       */
/*    tx_mutex_put                          Release protection mutex      */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-12-2005     William E. Lamie         Initial Version 5.0           */
/*  08-09-2007     William E. Lamie         Modified comment(s),          */
/*                                            moved the port already      */
/*                                            bound check to before the   */
/*                                            new port assignment, and    */
/*                                            added logic to remember the */
/*                                            socket owning the port for  */
/*                                            cleanup, resulting in       */
/*                                            version 5.1                 */
/*  12-30-2007     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.2    */
/*  08-03-2009     William E. Lamie         Modified comment(s), and added*/
/*                                            logic for trace support,    */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s), added    */
/*                                            supported NAT feature,      */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            removed unreachable code,   */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s),          */
/*                                            supported random port find, */
/*                                            improved internal logic,    */
/*                                            resulting in version 5.11   */
/*                                                                        */
/**************************************************************************/
UINT  _nx_tcp_client_socket_bind(NX_TCP_SOCKET *socket_ptr, UINT port, ULONG wait_option)
{
TX_INTERRUPT_SAVE_AREA

UINT           index;
#ifdef NX_NAT_ENABLE
UINT           bound;
#endif /* NX_NAT_ENABLE */
NX_IP         *ip_ptr;
NX_TCP_SOCKET *search_ptr;
NX_TCP_SOCKET *end_ptr;


    /* Setup the pointer to the associated IP instance.  */
    ip_ptr =  socket_ptr -> nx_tcp_socket_ip_ptr;

    /* If trace is enabled, insert this event into the trace buffer.  */
    NX_TRACE_IN_LINE_INSERT(NX_TRACE_TCP_CLIENT_SOCKET_BIND, ip_ptr, socket_ptr, port, wait_option, NX_TRACE_TCP_EVENTS, 0, 0);

    /* Obtain the IP mutex so we can figure out whether or not the port has already
       been bound to.  */
    tx_mutex_get(&(ip_ptr -> nx_ip_protection), TX_WAIT_FOREVER);

    /* Determine if the socket has already been bound to port or if a socket bind is
       already pending from another thread.  */
    if ((socket_ptr -> nx_tcp_socket_bound_next) ||
        (socket_ptr -> nx_tcp_socket_bind_in_progress))
    {

        /* Release the protection mutex.  */
        tx_mutex_put(&(ip_ptr -> nx_ip_protection));

        /* Return an already bound error code.  */
        return(NX_ALREADY_BOUND);
    }

    /* Determine if the port needs to be allocated.  */
    if (port == NX_ANY_PORT)
    {

        /* Call the find routine to allocate a TCP port.  */
        port = NX_SEARCH_PORT_START + (UINT)(NX_RAND() % ((NX_MAX_PORT + 1) - NX_SEARCH_PORT_START));
        if (_nx_tcp_free_port_find(ip_ptr, port, &port) != NX_SUCCESS)
        {

            /* Release the protection mutex.  */
            tx_mutex_put(&(ip_ptr -> nx_ip_protection));

            /* There was no free port, return an error code.  */
            return(NX_NO_FREE_PORTS);
        }
    }
#ifdef NX_NAT_ENABLE
    else
    {

        /* Check if this IP interface has a NAT service. */
        if (ip_ptr -> nx_ip_nat_port_verify)
        {

            /* Yes, so check the port by NAT handler. If NAT does not use this port, allow NetX to use it.  */
            bound = (ip_ptr -> nx_ip_nat_port_verify)(ip_ptr, NX_PROTOCOL_TCP, port);

            /* Check to see if the port has been used by NAT.  */
            if (bound == NX_TRUE)
            {

                /* Release the protection.  */
                tx_mutex_put(&(ip_ptr -> nx_ip_protection));

                /* Return the port unavailable error.  */
                return(NX_PORT_UNAVAILABLE);
            }
        }
    }
#endif

    /* Save the port number in the TCP socket structure.  */
    socket_ptr -> nx_tcp_socket_port =  port;

    /* Calculate the hash index in the TCP port array of the associated IP instance.  */
    index =  (UINT)((port + (port >> 8)) & NX_TCP_PORT_TABLE_MASK);

    /* Pickup the head of the TCP ports bound list.  */
    search_ptr =  ip_ptr -> nx_ip_tcp_port_table[index];

    /* Determine if we need to perform a list search.  */
    if (search_ptr)
    {

        /* Walk through the circular list of TCP sockets that are already
           bound.  */
        end_ptr = search_ptr;
        do
        {

            /* Determine if this entry is the same as the requested port.  */
            if (search_ptr -> nx_tcp_socket_port == port)
            {

                /* Yes, the port has already been allocated.  */
                break;
            }

            /* Move to the next entry in the list.  */
            search_ptr =  search_ptr -> nx_tcp_socket_bound_next;
        } while (search_ptr != end_ptr);
    }

    /* Now determine if the port is available.  */
    if ((search_ptr == NX_NULL) || (search_ptr -> nx_tcp_socket_port != port))
    {

        /* Place this TCP socket structure on the list of bound ports.  */

        /* Disable interrupts.  */
        TX_DISABLE

        /* Determine if the list is NULL.  */
        if (search_ptr)
        {

            /* There are already sockets on this list... just add this one
               to the end.  */
            socket_ptr -> nx_tcp_socket_bound_next =
                ip_ptr -> nx_ip_tcp_port_table[index];
            socket_ptr -> nx_tcp_socket_bound_previous =
                (ip_ptr -> nx_ip_tcp_port_table[index]) -> nx_tcp_socket_bound_previous;
            ((ip_ptr -> nx_ip_tcp_port_table[index]) -> nx_tcp_socket_bound_previous) -> nx_tcp_socket_bound_next =
                socket_ptr;
            (ip_ptr -> nx_ip_tcp_port_table[index]) -> nx_tcp_socket_bound_previous =   socket_ptr;
        }
        else
        {

            /* Nothing is on the TCP port list.  Add this TCP socket to an
               empty list.  */
            socket_ptr -> nx_tcp_socket_bound_next =      socket_ptr;
            socket_ptr -> nx_tcp_socket_bound_previous =  socket_ptr;
            ip_ptr -> nx_ip_tcp_port_table[index] =       socket_ptr;
        }

        /* Restore interrupts.  */
        TX_RESTORE

        /* Release the mutex protection.  */
        tx_mutex_put(&(ip_ptr -> nx_ip_protection));

        /* Return success to the caller.  */
        return(NX_SUCCESS);
    }
    else if (wait_option)
    {

        /* Prepare for suspension of this thread.  */

        /* Increment the suspended thread count.  */
        search_ptr -> nx_tcp_socket_bind_suspended_count++;

        /* Set the socket bind in progress flag (thread pointer).  */
        socket_ptr -> nx_tcp_socket_bind_in_progress =  _tx_thread_current_ptr;

        /* Also remember the socket that has bound to the port, since the thread
           is going to be suspended on that socket.  */
        socket_ptr -> nx_tcp_socket_bound_previous =  search_ptr;

        /* Suspend the thread on this socket's connection attempt.  */
        _nx_tcp_socket_thread_suspend(&(search_ptr -> nx_tcp_socket_bind_suspension_list), _nx_tcp_client_bind_cleanup, socket_ptr, &(ip_ptr -> nx_ip_protection), wait_option);

        /* Return the completion status.  */
        return(_tx_thread_current_ptr -> tx_thread_suspend_status);
    }
    else
    {

        /* Release the IP protection.  */
        tx_mutex_put(&(ip_ptr -> nx_ip_protection));

        /* Return the port unavailable error.  */
        return(NX_PORT_UNAVAILABLE);
    }
}

