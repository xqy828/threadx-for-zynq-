/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2017 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** FileX Component                                                       */
/**                                                                       */
/**   System                                                              */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define FX_SOURCE_CODE


/* Include necessary system files.  */

#include "fx_api.h"
#include "fx_system.h"


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _fx_system_timer_entry                              PORTABLE C      */
/*                                                           5.5          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function is FileX system timer function.  It is called at the  */
/*    rate specified by FX_UPDATE_RATE_IN_SECONDS and is responsible for  */
/*    maintaining both the system date and time.                          */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    id                                    Not used                      */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Initialization                                          */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-12-2005     William E. Lamie         Initial Version 5.0           */
/*  07-18-2007     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.1    */
/*  03-01-2009     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.2    */
/*  11-01-2015     William E. Lamie         Modified comment(s), and      */
/*                                            added check for timer ID,   */
/*                                            resulting in version 5.3    */
/*  04-15-2016     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  04-03-2017     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.5    */
/*                                                                        */
/**************************************************************************/
VOID    _fx_system_timer_entry(ULONG id)
{

UINT second;
UINT minute;
UINT hour;
UINT day;
UINT month;
UINT year;


    /* Determine if the ID is valid.  */
    if (id == FX_TIMER_ID)
    {

        /* Break the current date time into separate fields for easier work!  */
        second =  (_fx_system_time & FX_SECOND_MASK) * 2;
        minute =  (_fx_system_time >> FX_MINUTE_SHIFT) & FX_MINUTE_MASK;
        hour =    (_fx_system_time >> FX_HOUR_SHIFT) & FX_HOUR_MASK;
        day =     _fx_system_date & FX_DAY_MASK;
        month =   (_fx_system_date >> FX_MONTH_SHIFT) & FX_MONTH_MASK;
        year =    ((_fx_system_date >> FX_YEAR_SHIFT) & FX_YEAR_MASK) + FX_BASE_YEAR;

        /* Now apply the "second" update.  */
        second =  second + FX_UPDATE_RATE_IN_SECONDS;

        /* Determine if we need to adjust the minute field.  */
        if (second > FX_MAXIMUM_SECOND)
        {

            /* Yes, we need to adjust the minute field.  */
            minute =  minute + second / 60;
            second =  second % 60;

            /* Determine if we need to adjust the hour field.  */
            if (minute > FX_MAXIMUM_MINUTE)
            {

                /* Yes, we need to adjust the hour field.  */
                hour =    hour + minute / 60;
                minute =  minute % 60;

                /* Determine if we need to adjust the day field.  */
                if (hour > FX_MAXIMUM_HOUR)
                {

                    /* Yes, we need to adjust the day field.  */
                    hour =  0;
                    day++;

                    /* Determine if we need to adjust the month field.  */
                    switch (month)
                    {

                    case 1:                 /* January  */
                    {

                        /* Check for end of the month.  */
                        if (day > 31)
                        {

                            /* Move to next month.  */
                            day = 1;
                            month++;
                        }
                        break;
                    }

                    case 2:                 /* February  */
                    {

                        /* Check for leap year.  We don't need to check for leap
                           century her (century years divisible by 400) since 2000
                           is and this FAT format only supports years to 2107. */
                        if ((year % 4) == 0)
                        {

                            /* Leap year in February... check for 29 days
                               instead of 28.  */
                            if (day > 29)
                            {

                                /* Adjust the month.  */
                                day =  1;
                                month++;
                            }
                        }
                        else
                        {

                            if (day > 28)
                            {

                                /* Adjust the month.  */
                                day = 1;
                                month++;
                            }
                        }
                        break;
                    }

                    case 3:                 /* March  */
                    {

                        /* Check for end of the month.  */
                        if (day > 31)
                        {

                            /* Move to next month.  */
                            day = 1;
                            month++;
                        }
                        break;
                    }

                    case 4:                 /* April  */
                    {

                        /* Check for end of the month.  */
                        if (day > 30)
                        {

                            /* Move to next month.  */
                            day = 1;
                            month++;
                        }
                        break;
                    }

                    case 5:                 /* May  */
                    {

                        /* Check for end of the month.  */
                        if (day > 31)
                        {

                            /* Move to next month.  */
                            day = 1;
                            month++;
                        }
                        break;
                    }

                    case 6:                 /* June */
                    {

                        /* Check for end of the month.  */
                        if (day > 30)
                        {

                            /* Move to next month.  */
                            day = 1;
                            month++;
                        }
                        break;
                    }

                    case 7:                 /* July */
                    {

                        /* Check for end of the month.  */
                        if (day > 31)
                        {

                            /* Move to next month.  */
                            day = 1;
                            month++;
                        }
                        break;
                    }

                    case 8:                 /* August */
                    {

                        /* Check for end of the month.  */
                        if (day > 31)
                        {

                            /* Move to next month.  */
                            day = 1;
                            month++;
                        }
                        break;
                    }

                    case 9:                 /* September */
                    {

                        /* Check for end of the month.  */
                        if (day > 30)
                        {

                            /* Move to next month.  */
                            day = 1;
                            month++;
                        }
                        break;
                    }

                    case 10:                /* October */
                    {

                        /* Check for end of the month.  */
                        if (day > 31)
                        {

                            /* Move to next month.  */
                            day = 1;
                            month++;
                        }
                        break;
                    }

                    case 11:                /* November */
                    {

                        /* Check for end of the month.  */
                        if (day > 30)
                        {

                            /* Move to next month.  */
                            day = 1;
                            month++;
                        }
                        break;
                    }

                    case 12:                /* December */
                    {

                        /* Check for end of the month.  */
                        if (day > 31)
                        {

                            /* Move to next month.  */
                            day = 1;
                            month = 1;

                            /* Also move to next year.  */
                            year++;

                            /* Check for a year that exceeds the representation
                               in this format.  */
                            if (year > FX_MAXIMUM_YEAR)
                            {
                                return;
                            }
                        }
                        break;
                    }

                    default:                /* Invalid month!  */

                        return;             /* Skip updating date/time!  */
                    }
                }
            }
        }

        /* Now apply the new setting to the internal representation.  */

        /* Set the system date.  */
        _fx_system_date =  ((year - FX_BASE_YEAR) << FX_YEAR_SHIFT) |
                            (month << FX_MONTH_SHIFT) | day;

        /* Set the new system time.  */
        _fx_system_time  =  (hour << FX_HOUR_SHIFT) |
                            (minute << FX_MINUTE_SHIFT) | (second / 2);
    }
}

