/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018  by Express Logic Inc.              */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Packet Pool Mangement (Packet)                                      */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */
#include "nx_api.h"
#include "nx_ip.h"

#ifdef NX_IPSEC_ENABLE
#include "nx_ipsec.h"
#endif /* NX_IPSEC_ENABLE */

/* Bring in externs for caller checking code.  */

NX_CALLER_CHECKING_EXTERNS


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nxe_ip_max_payload_size_find                       PORTABLE C      */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function checks for errors in the max IP payload computation   */
/*    service.                                                            */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                Pointer to IP instance        */
/*    src_address                           Packet Source Address         */
/*    dest_address                          Packet Destination Address    */
/*    protocol                              Protocol type                 */
/*    src_port                              Source port number, in host   */
/*                                            byte order.                 */
/*    dest_port                             Destination port number,      */
/*                                            in host byte order.         */
/*    start_offset_ptr                      Pointer to storage space that */
/*                                            contains amount of offset   */
/*                                            for payload.                */
/*    payload_length_ptr                    Pointer to storage space that */
/*                                            indicates the amount of     */
/*                                            payload data that would not */
/*                                            cause IP fragmentation.     */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                                Completion Code.              */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _nx_max_payload_size_get              The acutal function that      */
/*                                            computes the max payload    */
/*                                            size.                       */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application                                                         */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  11-23-2009     Yuxin Zhou               Initial version 5.4.          */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s), replaced */
/*                                            source address with an      */
/*                                            index to the source address,*/
/*                                            added IPsec support,        */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.11   */
/*                                                                        */
/**************************************************************************/

UINT _nxe_ip_max_payload_size_find(NX_IP *ip_ptr,
                                   NXD_ADDRESS *dest_address,
                                   UINT if_index,
                                   UINT src_port,
                                   UINT dest_port,
                                   ULONG protocol,
                                   ULONG *start_offset_ptr,
                                   ULONG *payload_length_ptr)
{

    /* Check for valid pointer to an IP instance.  */
    if ((ip_ptr == NX_NULL) || (ip_ptr -> nx_ip_id != NX_IP_ID))
    {
        return(NX_PTR_ERROR);
    }

    /* Destination address must be valid. */
    if (dest_address == NX_NULL)
    {
        return(NX_PTR_ERROR);
    }

    if ((dest_address -> nxd_ip_version != NX_IP_VERSION_V4) &&
        (dest_address -> nxd_ip_version != NX_IP_VERSION_V6))
    {
        return(NX_IP_ADDRESS_ERROR);
    }

    if ((protocol != NX_PROTOCOL_UDP) &&
        (protocol != NX_PROTOCOL_TCP))
    {
        return(NX_NOT_SUPPORTED);
    }

    /* Check for appropriate caller.  */
    NX_INIT_AND_THREADS_CALLER_CHECKING

    return(_nx_ip_max_payload_size_find(ip_ptr, dest_address, if_index, src_port, dest_port,
                                        protocol, start_offset_ptr, payload_length_ptr));
}

