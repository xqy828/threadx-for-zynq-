/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Protocol (IP)                                              */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE

/* Include necessary system files. */
#include "nx_api.h"
#include "nx_tcp.h"
#include "nx_arp.h"
#include "nx_icmpv6.h"


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_ip_diferred_link_status_process                 PORTABLE C      */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic,Inc.                                      */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function processes link status change event.                   */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                Pointer to IP control block   */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    tx_mutex_get                          Obtain protection mutex       */
/*    tx_mutex_put                          Release protection mutex      */
/*    _nx_tcp_socket_connection_reset       Reset TCP connection          */
/*    _nx_arp_interface_entries_delete      Remove specified ARP entries  */
/*    _nx_nd_cache_interface_entries_delete Delete ND cache entries assoc-*/
/*                                          iated with specified interface*/
/*    link_driver_entry                     Link driver                   */
/*    memset                                Zero out the interface        */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    nx_ip_thread_entry                                                  */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  01-12-2015       Yuxin Zhou             Initial Version 5.8           */
/*  02-22-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            removed cleanup logic when  */
/*                                            link was down,              */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.11   */
/*                                                                        */
/**************************************************************************/
VOID _nx_ip_deferred_link_status_process(NX_IP *ip_ptr)
{

UINT         i;
NX_IP_DRIVER driver_request;
ULONG        link_up;

    if (ip_ptr -> nx_ip_link_status_change_callback == NX_NULL)
    {

        /* Callback function is not set. */
        return;
    }

    for (i = 0; i < NX_MAX_PHYSICAL_INTERFACES; i++)
    {
        if ((ip_ptr -> nx_ip_interface[i].nx_interface_valid) &&
            (ip_ptr -> nx_ip_interface[i].nx_interface_link_status_change))
        {

            /* Reset the flag. */
            ip_ptr -> nx_ip_interface[i].nx_interface_link_status_change = NX_FALSE;

            driver_request.nx_ip_driver_ptr       = ip_ptr;
            driver_request.nx_ip_driver_command   = NX_LINK_GET_STATUS;
            driver_request.nx_ip_driver_interface = &(ip_ptr -> nx_ip_interface[i]);
            driver_request.nx_ip_driver_return_ptr = &link_up;

            (ip_ptr -> nx_ip_interface[i].nx_interface_link_driver_entry)(&driver_request);

            /* Invoke the callback function. */
            /*lint -e{644} suppress variable might not be initialized, since "link_up" was initialized in nx_interface_link_driver_entry. */
            ip_ptr -> nx_ip_link_status_change_callback(ip_ptr, i, link_up);
        }
    }
}

