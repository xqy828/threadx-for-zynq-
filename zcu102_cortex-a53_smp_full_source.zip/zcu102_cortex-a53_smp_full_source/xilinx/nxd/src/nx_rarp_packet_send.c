/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Reverse Address Resolution Protocol (RARP)                          */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_rarp.h"
#include "nx_packet.h"

#ifndef NX_DISABLE_IPV4
/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_rarp_packet_send                                PORTABLE C      */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function builds an RARP packet and calls the associated driver */
/*    to send it out on the network.                                      */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                Pointer to IP instance        */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _nx_packet_allocate                   Allocate a packet for the     */
/*                                            RARP request                */
/*    (ip_link_driver)                      User supplied link driver     */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    NetX Source Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-12-2005     William E. Lamie         Initial Version 5.0           */
/*  08-09-2007     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.1    */
/*  12-30-2007     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.2    */
/*  08-03-2009     William E. Lamie         Modified comment(s), and added*/
/*                                            logic for trace support,    */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Removed internal debug logic, */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s), added    */
/*                                            support for multihome,      */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s), and      */
/*                                            optimized NX_PACKET_STRUCT, */
/*                                            added duo packet pool,      */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            supported packet debugging, */
/*                                            renamed symbols, resulting  */
/*                                            in version 5.9              */
/*  05-10-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            fixed lint warnings,        */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s), added    */
/*                                            support for disabling IPv4, */
/*                                            resulting in version 5.11   */
/*                                                                        */
/**************************************************************************/
VOID  _nx_rarp_packet_send(NX_IP *ip_ptr)
{

NX_PACKET   *request_ptr;
ULONG       *message_ptr;
NX_IP_DRIVER driver_request;
ULONG        i;


    /* Determine which interfaces to send RARP packets out from (e.g. do not have IP addresses). */
    for (i = 0; i < NX_MAX_PHYSICAL_INTERFACES; i++)
    {

        /* Skip this interface if it is not initialized yet. */
        if (ip_ptr -> nx_ip_interface[i].nx_interface_valid == 0)
        {
            continue;
        }

        /* If the interface has a valid address, skip it. */
        if (ip_ptr -> nx_ip_interface[i].nx_interface_ip_address != 0)
        {
            continue;
        }


        /* Skip this interface if mapping is not required, i.e. the driver is not Ethernet-like. */
        /*lint -e{539} suppress positive indentation.  */
        if (ip_ptr -> nx_ip_interface[i].nx_interface_address_mapping_needed == 0)
        {
            continue;
        }

        /* Allocate a packet to build the RARP message in.  */
#ifdef NX_ENABLE_DUAL_PACKET_POOL
        /* Allocate from auxiliary packet pool first. */
        if (_nx_packet_allocate(ip_ptr -> nx_ip_auxiliary_packet_pool, &request_ptr, NX_PHYSICAL_HEADER, NX_NO_WAIT))
        {
            if (ip_ptr -> nx_ip_auxiliary_packet_pool != ip_ptr -> nx_ip_default_packet_pool)
#endif /* NX_ENABLE_DUAL_PACKET_POOL */
            {
                if (_nx_packet_allocate(ip_ptr -> nx_ip_default_packet_pool, &request_ptr, NX_PHYSICAL_HEADER, NX_NO_WAIT))
                {

                    /* Error getting packet, so just get out!  */
                    return;
                }
            }
#ifdef NX_ENABLE_DUAL_PACKET_POOL
            else
            {

                /* Error getting packet, so just get out!  */
                return;
            }
        }
#endif /* NX_ENABLE_DUAL_PACKET_POOL */

        /* Add debug information. */
        NX_PACKET_DEBUG(__FILE__, __LINE__, request_ptr);

#ifndef NX_DISABLE_RARP_INFO
        /* Increment the RARP requests sent count.  */
        ip_ptr -> nx_ip_rarp_requests_sent++;
#endif
        /*lint -e{644} suppress variable might not be initialized, since "request_ptr" was initialized in _nx_packet_allocate. */
        request_ptr -> nx_packet_address.nx_packet_interface_ptr = &(ip_ptr -> nx_ip_interface[i]);
        /* Build the RARP request packet.  */

        /* Setup the size of the RARP message.  */
        request_ptr -> nx_packet_length =  NX_RARP_MESSAGE_SIZE;

        /* Setup the append pointer to the end of the message.  */
        request_ptr -> nx_packet_append_ptr =  request_ptr -> nx_packet_prepend_ptr + NX_RARP_MESSAGE_SIZE;

        /* Setup the pointer to the message area.  */
        /*lint -e{927} -e{826} suppress cast of pointer to pointer, since it is necessary  */
        message_ptr =  (ULONG *)request_ptr -> nx_packet_prepend_ptr;

        /* Write the Hardware type into the message.  */
        *message_ptr =        (ULONG)(NX_RARP_HARDWARE_TYPE << 16) | (NX_RARP_PROTOCOL_TYPE);
        *(message_ptr + 1) =  (ULONG)(NX_RARP_HARDWARE_SIZE << 24) | (NX_RARP_PROTOCOL_SIZE << 16) | NX_RARP_OPTION_REQUEST;
        *(message_ptr + 2) =  (ULONG)(request_ptr -> nx_packet_address.nx_packet_interface_ptr -> nx_interface_physical_address_msw << 16) |
                                     (request_ptr -> nx_packet_address.nx_packet_interface_ptr -> nx_interface_physical_address_lsw >> 16);
        *(message_ptr + 3) =  (ULONG)(request_ptr -> nx_packet_address.nx_packet_interface_ptr -> nx_interface_physical_address_lsw << 16);
        *(message_ptr + 4) =  (ULONG)(request_ptr -> nx_packet_address.nx_packet_interface_ptr -> nx_interface_physical_address_msw & NX_LOWER_16_MASK);
        *(message_ptr + 5) =  (ULONG)(request_ptr -> nx_packet_address.nx_packet_interface_ptr -> nx_interface_physical_address_lsw);
        *(message_ptr + 6) =  (ULONG)0;

        /* If trace is enabled, insert this event into the trace buffer.  */
        NX_TRACE_IN_LINE_INSERT(NX_TRACE_INTERNAL_RARP_SEND, ip_ptr, 0, request_ptr, *(message_ptr + 1), NX_TRACE_INTERNAL_EVENTS, 0, 0);

        /* Endian swapping logic.  If NX_LITTLE_ENDIAN is specified, these macros will
           swap the endian of the RARP message.  */
        NX_CHANGE_ULONG_ENDIAN(*(message_ptr));
        NX_CHANGE_ULONG_ENDIAN(*(message_ptr + 1));
        NX_CHANGE_ULONG_ENDIAN(*(message_ptr + 2));
        NX_CHANGE_ULONG_ENDIAN(*(message_ptr + 3));
        NX_CHANGE_ULONG_ENDIAN(*(message_ptr + 4));
        NX_CHANGE_ULONG_ENDIAN(*(message_ptr + 5));
        NX_CHANGE_ULONG_ENDIAN(*(message_ptr + 6));

        /* Send the RARP request to the driver.  */
        driver_request.nx_ip_driver_ptr =                   ip_ptr;
        driver_request.nx_ip_driver_command =               NX_LINK_RARP_SEND;
        driver_request.nx_ip_driver_packet =                request_ptr;
        driver_request.nx_ip_driver_physical_address_msw =  0xFFFFUL;
        driver_request.nx_ip_driver_physical_address_lsw =  0xFFFFFFFFUL;
        driver_request.nx_ip_driver_interface =             request_ptr -> nx_packet_address.nx_packet_interface_ptr;

        /* If trace is enabled, insert this event into the trace buffer.  */
        NX_TRACE_IN_LINE_INSERT(NX_TRACE_INTERNAL_IO_DRIVER_RARP_SEND, ip_ptr, request_ptr, request_ptr -> nx_packet_length, 0, NX_TRACE_INTERNAL_EVENTS, 0, 0);

        (request_ptr -> nx_packet_address.nx_packet_interface_ptr -> nx_interface_link_driver_entry)(&driver_request);
    }

    return;
}
#endif /* !NX_DISABLE_IPV4  */

