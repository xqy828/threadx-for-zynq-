/**************************************************************************/
/*                                                                        */
/*            Copyright (c)  1996-2018 by Express Logic Inc.              */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Protocol (IP)                                              */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_ip.h"


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_ip_static_route_add                             PORTABLE C      */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function adds a static routing entry to the routing table.     */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                Pointer to IP instance        */
/*    network_address                       Network address, in host byte */
/*                                            order.                      */
/*    net_mask                              Network Mask, in host byte    */
/*                                            order.                      */
/*    next_hop                              Next Hop address, in host     */
/*                                            byte order.                 */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                                Completion status             */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    tx_mutex_get                          Obtain a protection mutex     */
/*    tx_mutex_put                          Release protection mutex      */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application                                                         */
/*                                                                        */
/*  NOTE:                                                                 */
/*                                                                        */
/*    next hop address must be on the local network.                      */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-30-2007     Yuxin Zhou               Initial Version 5.2           */
/*  08-03-2009     William E. Lamie         Modified comment(s), and added*/
/*                                            logic for trace support,    */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            modified struct field names */
/*                                            missing struct name prefix, */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s), check    */
/*                                            to make sure the next hop   */
/*                                            is accessible by one of     */
/*                                            the physical interfaces,    */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s), record   */
/*                                            the physical interface      */
/*                                            associated with the route,  */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s), fixed a  */
/*                                            bug that route table may    */
/*                                            overflow, and added         */
/*                                            interface record when       */
/*                                            shifting entries,           */
/*                                            fixed a bug that unsigned   */
/*                                            number overflows,           */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            fixed a bug that mutex is   */
/*                                            not released before return, */
/*                                            fixed compiler warnings,    */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s), and      */
/*                                            fixed compiler errors when  */
/*                                            event trace is enabled,     */
/*                                            supported disabling IPv4,   */
/*                                            resulting in version 5.11   */
/*                                                                        */
/**************************************************************************/
UINT  _nx_ip_static_route_add(NX_IP *ip_ptr, ULONG network_address,
                              ULONG net_mask, ULONG next_hop)
{
#if !defined(NX_DISABLE_IPV4) && defined(NX_ENABLE_IP_STATIC_ROUTING)
INT           i;
NX_INTERFACE *nx_ip_interface = NX_NULL;

    /* If trace is enabled, insert this event into the trace buffer.  */
    NX_TRACE_IN_LINE_INSERT(NX_TRACE_IP_STATIC_ROUTE_ADD, ip_ptr, network_address, net_mask, next_hop, NX_TRACE_IP_EVENTS, 0, 0);

    /* Obtain the IP mutex so we can manipulate the internal routing table. */
    /* This routine does not need to be protected by mask off interrupt
       because it cannot be invoked from ISR. */
    tx_mutex_get(&(ip_ptr -> nx_ip_protection), TX_WAIT_FOREVER);

    /* Make sure next hop is on one of the interfaces. */
    for (i = 0; i < NX_MAX_IP_INTERFACES; i++)
    {

        if (ip_ptr -> nx_ip_interface[i].nx_interface_valid &&
            ((next_hop & (ip_ptr -> nx_ip_interface[i].nx_interface_ip_network_mask)) == ip_ptr -> nx_ip_interface[i].nx_interface_ip_network))
        {

            nx_ip_interface = &(ip_ptr -> nx_ip_interface[i]);

            /* Break out of the for loop */
            break;
        }
    }

    /* If no matching interface, return the error status. */
    if (nx_ip_interface == NX_NULL)
    {

        /* Unlock the mutex, and return the error status. */
        tx_mutex_put(&(ip_ptr -> nx_ip_protection));

        return(NX_IP_ADDRESS_ERROR);
    }

    /* Obtain the network address, based on net_mask passed in. */
    network_address = network_address & net_mask;

    /* Search through the routing table, check whether the same entry exists. */
    for (i = 0; i < (INT)ip_ptr -> nx_ip_routing_table_entry_count; i++)
    {

        if (ip_ptr -> nx_ip_routing_table[i].nx_ip_routing_dest_ip == network_address &&
            ip_ptr -> nx_ip_routing_table[i].nx_ip_routing_net_mask == net_mask)
        {

            /* Found the same entry: only need to update the next hop field */
            ip_ptr -> nx_ip_routing_table[i].nx_ip_routing_next_hop_address = next_hop;

            /* All done.  Unlock the mutex, and return */
            tx_mutex_put(&(ip_ptr -> nx_ip_protection));
            return(NX_SUCCESS);
        }

        /* The net mask that has more top bits set has a greater numerical value than the
           one with less top bits set.  During a search we want to match smaller nets
           (more top bits set, or larger numerical value) before matching larger nets. */
        if (ip_ptr -> nx_ip_routing_table[i].nx_ip_routing_net_mask <= net_mask)
        {

        INT j;

            /* Check whether the table is full. */
            if (ip_ptr -> nx_ip_routing_table_entry_count == NX_IP_ROUTING_TABLE_SIZE)
            {

                tx_mutex_put(&(ip_ptr -> nx_ip_protection));
                return(NX_OVERFLOW);
            }

            /* The entry pointed to by "i" is a larger network (thus smaller net mask
               value.  The new entry needs to be inserted before "i".

               To do so, we need to make room for the new entry, by shifting entries i and
               after one slot. */
            for (j = (INT)ip_ptr -> nx_ip_routing_table_entry_count - 1; j >= i; j--)
            {

                ip_ptr -> nx_ip_routing_table[j + 1].nx_ip_routing_dest_ip =
                    ip_ptr -> nx_ip_routing_table[j].nx_ip_routing_dest_ip;
                ip_ptr -> nx_ip_routing_table[j + 1].nx_ip_routing_net_mask =
                    ip_ptr -> nx_ip_routing_table[j].nx_ip_routing_net_mask;
                ip_ptr -> nx_ip_routing_table[j + 1].nx_ip_routing_next_hop_address =
                    ip_ptr -> nx_ip_routing_table[j].nx_ip_routing_next_hop_address;
                ip_ptr -> nx_ip_routing_table[j + 1].nx_ip_routing_entry_ip_interface =
                    ip_ptr -> nx_ip_routing_table[j].nx_ip_routing_entry_ip_interface;
            }

            break;
        }
    }

    /* Check whether the table is full. */
    if (i == NX_IP_ROUTING_TABLE_SIZE)
    {
        tx_mutex_put(&(ip_ptr -> nx_ip_protection));
        return(NX_OVERFLOW);
    }

    ip_ptr -> nx_ip_routing_table[i].nx_ip_routing_dest_ip = network_address;
    ip_ptr -> nx_ip_routing_table[i].nx_ip_routing_net_mask = net_mask;
    ip_ptr -> nx_ip_routing_table[i].nx_ip_routing_next_hop_address = next_hop;
    ip_ptr -> nx_ip_routing_table[i].nx_ip_routing_entry_ip_interface = nx_ip_interface;

    ip_ptr -> nx_ip_routing_table_entry_count++;

    /* Unlock the mutex. */
    tx_mutex_put(&(ip_ptr -> nx_ip_protection));

    /* Return success to the caller.  */
    return(NX_SUCCESS);

#else /* !NX_DISABLE_IPV4 && NX_ENABLE_IP_STATIC_ROUTING  */
    NX_PARAMETER_NOT_USED(ip_ptr);
    NX_PARAMETER_NOT_USED(network_address);
    NX_PARAMETER_NOT_USED(net_mask);
    NX_PARAMETER_NOT_USED(next_hop);

    return(NX_NOT_SUPPORTED);

#endif /* !NX_DISABLE_IPV4 && NX_ENABLE_IP_STATIC_ROUTING  */
}

