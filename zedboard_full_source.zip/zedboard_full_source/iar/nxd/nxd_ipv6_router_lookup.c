/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2016 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/
/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Protocol version 6 Default Router Table (IPv6 router)      */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/
#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_ipv6.h"
#include "nx_nd_cache.h"
#include "nx_icmpv6.h"


#ifdef FEATURE_NX_IPV6
/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nxd_ipv6_router_lookup                             PORTABLE C      */
/*                                                           5.10         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function finds a valid router from the default router table,   */
/*    and this function also return the pointer to the router's cache     */
/*    entry in the NetX Duo cache table.                                  */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                IP instance pointer           */
/*    router_address                        Pointer to default router     */
/*    nd_cache_entry                        Pointer to associated ND entry*/
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                                Non zero status               */
/*                                            router not found            */
/*                                          Zero status, router found     */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    _nx_icmpv6_process_redirect                                         */
/*    _nx_ipv6_packet_send                                                */
/*                                                                        */
/*  NOTE                                                                  */
/*                                                                        */
/*    Internal Function.  Caller must have acquired IP protection mutex.  */
/*    This function should not be called from ISR.  Although it has no    */
/*    blocking calls it will slow down response time.                     */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-30-2007     Yuxin Zhou               Initial Version 5.2           */
/*  08-03-2009     Yuxin Zhou               Modified comments, resulting  */
/*                                            in version 5.3              */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            modified struct field names */
/*                                            missing struct name prefix, */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s), check    */
/*                                            whether nd_cache_entry is   */
/*                                            NULL before dereferencing   */
/*                                            it, optimized the router    */
/*                                            table search algorithm,     */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            removed unreachable code,   */
/*                                            added ASSERT macro,         */
/*                                            resulting in version 5.10   */
/*                                                                        */
/**************************************************************************/
UINT  _nxd_ipv6_router_lookup(NX_IP *ip_ptr, ULONG *router_address, void **nd_cache_entry)
{

UINT                          i;
UINT                          table_size;
UINT                          routers_checked;
NX_IPV6_DEFAULT_ROUTER_ENTRY *rt_entry;
ND_CACHE_ENTRY               *NDCacheEntry;

    NX_ASSERT(nd_cache_entry != NX_NULL)

    /* Initialize cache pointer to NULL (if no router found). */
    *nd_cache_entry = NULL;

    /* Set a local variable for convenience. */
    table_size = ip_ptr -> nx_ipv6_default_router_table_size;

    /* Check if there have been any routers added to the table. */
    if (table_size == 0)
    {

        /* Return a non zero (e.g. unsuccessful) error status. */
        return(NX_NOT_SUCCESSFUL);
    }

    for (i = 0; table_size && (i < NX_IPV6_DEFAULT_ROUTER_TABLE_SIZE); i++)
    {

        /* Local pointer for convenience. */
        rt_entry = &(ip_ptr -> nx_ipv6_default_router_table[i]);

        /* Does this slot contain a valid router? */
        if (rt_entry -> nx_ipv6_default_router_entry_flag & NX_IPV6_ROUTE_TYPE_VALID)
        {

            /* Keep track of valid entries we have checked. */
            NDCacheEntry = ip_ptr -> nx_ipv6_default_router_table[i].nx_ipv6_default_router_entry_neighbor_cache_ptr;

            /* Is this router reachable? */
            if (!NDCacheEntry ||
                (NDCacheEntry -> nx_nd_cache_nd_status < ND_CACHE_STATE_REACHABLE) ||
                (NDCacheEntry -> nx_nd_cache_nd_status > ND_CACHE_STATE_PROBE))
            {

                /* No, skip over. */
                table_size--;
                continue;
            }

            /* Yes, copy this router address into the return pointer. */
            COPY_IPV6_ADDRESS(ip_ptr -> nx_ipv6_default_router_table[i].nx_ipv6_default_router_entry_router_address, router_address);

            /* Copy the router's cache entry pointer to the supplied cache table pointer. */
            *nd_cache_entry = ip_ptr -> nx_ipv6_default_router_table[i].nx_ipv6_default_router_entry_neighbor_cache_ptr;

            /* We're done. Break out of the search. */
            return(NX_SUCCESS);
        }
    }

    /* If we are here, we did not find a suitable default router. Do a search
       of routers previously reachable. */

    /* Start at the round robin index so we don't always choose the first
       less-than-reachable router in the table. */
    i = ip_ptr -> nx_ipv6_default_router_table_round_robin_index;

    /* Find a router with previously known reachability. */
    for (routers_checked = 0; routers_checked < NX_IPV6_DEFAULT_ROUTER_TABLE_SIZE; routers_checked++)
    {

        /* Does this slot contain a valid router? */
        if (ip_ptr -> nx_ipv6_default_router_table[i].nx_ipv6_default_router_entry_flag & NX_IPV6_ROUTE_TYPE_VALID)
        {

            /* Yes, copy this router to the return pointer. */
            COPY_IPV6_ADDRESS(ip_ptr -> nx_ipv6_default_router_table[i].nx_ipv6_default_router_entry_router_address, router_address);

            /* Copy the router's cache entry pointer to the supplied cache table pointer. */
            *nd_cache_entry = ip_ptr -> nx_ipv6_default_router_table[i].nx_ipv6_default_router_entry_neighbor_cache_ptr;

            /* Update the index so the same router is not chosen again if there
               any other less-than-reachable routers we can choose, RFC 2461 6.3.6. */
            ip_ptr -> nx_ipv6_default_router_table_round_robin_index++;

            /* Do we need wrap the index? */
            if (ip_ptr -> nx_ipv6_default_router_table_round_robin_index == NX_IPV6_DEFAULT_ROUTER_TABLE_SIZE)
            {

                /* Yes, start back at the first slot. */
                ip_ptr -> nx_ipv6_default_router_table_round_robin_index = 0;
            }

            /* We're done. Return successful outcome status. */
            break;
        }

        /* Are we past the end of the table? */
        if (i == NX_IPV6_DEFAULT_ROUTER_TABLE_SIZE - 1)
        {
            /* Yes, wrap to the first slot.*/
            i = 0;
        }
        else
        {
            i++;
        }
    }

    /* routers_checked must not be NX_IPV6_DEFAULT_ROUTER_TABLE_SIZE. */
    NX_ASSERT(routers_checked != NX_IPV6_DEFAULT_ROUTER_TABLE_SIZE);

    /* Return the result of the search. */
    return(NX_SUCCESS);
}


#endif /* FEATURE_NX_IPV6 */

