/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Ethernet driver for Xilinx Zynq UltraScale+ MPSoC GEM               */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_DRIVER_SOURCE
#include "nx_driver_zynqmp_gem.h"
#include "nx_driver_zynqmp_gem_regs.h"


/* GEM1 driver data */

static NX_DRIVER_INFORMATION nx_driver_gem1 = {
    1,                          /* GEM id */
    GEM1_IRQ,                   /* IRQ number */
    (GEM_REGS *) GEM1_BASE,     /* base address */
    (uint32_t *) GEM1_CRL_APB,  /* clock control */
    (USHORT) -1,                /* PHY address */
    /* 0... */
};


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    nx_driver_zynqmp_gem1                    Zynq UltraScale+ MPSoC/GNU */
/*                                                           5.0          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Regis Feneon, Express Logic France.                                 */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This is the entry point of the GEM1 Ethernet Driver.                */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    driver_req_ptr                        The driver request from the   */
/*                                            IP layer.                   */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    nx_driver_zynqmp_entry                Driver implementation         */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    IP layer                                                            */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  07-01-2018     Regis Feneon             Initial Version 5.0           */
/*                                                                        */
/**************************************************************************/
void nx_driver_zynqmp_gem1(NX_IP_DRIVER *driver_req_ptr)
{
    nx_driver_zynqmp_entry(&nx_driver_gem1, driver_req_ptr);
}
