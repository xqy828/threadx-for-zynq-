/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Internet Protocol (IP)                                              */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE



/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_ipv6.h"
#include "nx_icmpv6.h"

#ifdef FEATURE_NX_IPV6

/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nx_ipv6_option_error                               PORTABLE C      */
/*                                                           5.11 SP1     */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Yuxin Zhou, Express Logic, Inc.                                     */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function handles an invalid Options header packet by examining */
/*    the option header option type's most significant bits and           */
/*    determining if an error message is sent and if the rest of the      */
/*    packet should be processed or discarded.                            */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    ip_ptr                                Pointer to IP control block   */
/*    packet_ptr                            Pointer to packet to send     */
/*    option_type                           The type of option            */
/*    offset                                Where the error occurs        */
/*                                                                        */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    NX_SUCCESS                             Skip this option; no errors  */
/*    NX_OPTION_HEADER_ERROR                 Error; Drop the entire packet*/
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    None                                                                */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    _nx_ipv6_process_hop_by_hop_option                                  */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-30-2007     Yuxin Zhou               Initial Version 5.2           */
/*  08-03-2009     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s),          */
/*                                            simplified the logic,       */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s),          */
/*                                            fixed compiler warnings,    */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            removed duplicated check for*/
/*                                            function pointer, renamed   */
/*                                            symbols, fixed compiler     */
/*                                            warnings, resulting in      */
/*                                            version 5.9                 */
/*  05-10-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            optimized the logic for     */
/*                                            default case of switch,     */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s),  and     */
/*                                            improved internal logic,    */
/*                                            resulting in version 5.11   */
/*  12-15-2018     Yuxin Zhou               Modified comment(s), and      */
/*                                            supported for 64-bit mode,  */
/*                                            resulting in version 5.11SP1*/
/*                                                                        */
/**************************************************************************/
UINT _nx_ipv6_option_error(NX_IP *ip_ptr, NX_PACKET *packet_ptr, UCHAR option_type, UINT offset)
{

UINT rv = NX_SUCCESS;

/*lint -e{927} -e{826} suppress cast of pointer to pointer, since it is necessary  */
NX_IPV6_HEADER *ip_header_ptr = (NX_IPV6_HEADER *)packet_ptr -> nx_packet_ip_header;

    /* Top 2 bits of the option type indicate how we shall process this option
       in case of an error. */
    switch (option_type >> 6)
    {

    case 3: /* Discard the packet and send ICMP Parameter Problem to unicast address */
        if ((ip_header_ptr -> nx_ip_header_destination_ip[0] & (ULONG)0xFF000000) == (ULONG)0xFF000000)
        {

            /* If the destination address is a multicast address, we discard the packet. */
            rv = NX_OPTION_HEADER_ERROR;
            break;
        }
    /*
       No need to break here:  execute the next two cases:
       (1) transmit ICMP error message
       (2) release the packet.
     */

    /*lint -e{825} suppress fallthrough, since it is necessary.  */ /* fallthrough */
    case 2: /* Discard the packet and send ICMP Parameter Problem */

#ifndef NX_DISABLE_ICMPV6_ERROR_MESSAGE

        NX_ICMPV6_SEND_PARAMETER_PROBLEM(ip_ptr, packet_ptr, 2, (ULONG)(offset + sizeof(NX_IPV6_HEADER)));
#else
        NX_PARAMETER_NOT_USED(ip_ptr);
        NX_PARAMETER_NOT_USED(offset);
#endif

    /* No break here.  Execute the next statement to release the packet. */

    /*lint -e{825} suppress fallthrough, since it is necessary.  */ /* fallthrough */
    case 1: /* Discard the packet */

        /* Error status - Drop the packet */
        rv = NX_OPTION_HEADER_ERROR;
        break;

    case 0: /* Skip over this option and continue processing the rest of the packet. */
    default:
        break;
    }

    return(rv);
}


#endif /*  FEATURE_NX_IPV6 */

