/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2017 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** FileX Component                                                       */
/**                                                                       */
/**   Utility                                                             */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/
#define FX_SOURCE_CODE


/* Include necessary system files.  */

#include "fx_api.h"


#ifdef FX_ENABLE_EXFAT
#include "fx_system.h"
#include "fx_media.h"
#include "fx_utility.h"
#include "fx_directory_exFAT.h"



/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _fx_utility_exFAT_system_area_checksum_write        PORTABLE C      */
/*                                                           5.5          */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function writes system area checksum.                          */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    media_ptr                             Media control block pointer   */
/*    sector_buffer                         Pointer to sector buffer      */
/*    system_area_checksum_ptr              Pointer to checksum value     */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    return status                                                       */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _fx_utility_exFAT_system_sector_write Write a format sector         */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    FileX System Functions                                              */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  11-01-2015     William E. Lamie         Initial Version 5.3           */
/*  04-15-2016     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  04-03-2017     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.5    */
/*                                                                        */
/**************************************************************************/
UINT _fx_utility_exFAT_system_area_checksum_write(FX_MEDIA *media_ptr, UCHAR *sector_buffer, ULONG *system_area_checksum_ptr)
{

UINT index;

    /* Fill buffer by check sum.  */
    for (index = 0; index < FX_BOOT_SECTOR_SIZE;)
    {
        _fx_utility_32_unsigned_write(&sector_buffer[index],
                                      *system_area_checksum_ptr);

        index += sizeof(*system_area_checksum_ptr);
    }

    /* Write Check Sum for Main System area.  */
    _fx_utility_exFAT_system_sector_write(media_ptr, sector_buffer,
                                          FX_EXFAT_FAT_MAIN_SYSTEM_AREA_SIZE - 1,
                                          1, FX_BOOT_SECTOR);

    if (FX_SUCCESS != media_ptr -> fx_media_driver_status)
    {
        return(media_ptr -> fx_media_driver_status);
    }

    /* Write Check Sum for BackUp System area.  */
    _fx_utility_exFAT_system_sector_write(media_ptr, sector_buffer,
                                          FX_EXFAT_FAT_MAIN_SYSTEM_AREA_SIZE - 1 + FX_EXFAT_FAT_MAIN_SYSTEM_AREA_SIZE,
                                          1, FX_BOOT_SECTOR);

    return(media_ptr -> fx_media_driver_status);
}

#endif /* FX_ENABLE_EXFAT */

