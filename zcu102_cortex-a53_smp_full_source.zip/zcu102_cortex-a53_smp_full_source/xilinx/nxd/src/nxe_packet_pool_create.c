/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Packet Pool Management (Packet)                                     */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/

#define NX_SOURCE_CODE


/* Include necessary system files.  */

#include "nx_api.h"
#include "nx_packet.h"

/* Bring in externs for caller checking code.  */

NX_CALLER_CHECKING_EXTERNS


/**************************************************************************/
/*                                                                        */
/*  FUNCTION                                               RELEASE        */
/*                                                                        */
/*    _nxe_packet_pool_create                             PORTABLE C      */
/*                                                           5.11 SP1     */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This function checks for errors in the packet pool create           */
/*    function call.                                                      */
/*                                                                        */
/*  INPUT                                                                 */
/*                                                                        */
/*    pool_ptr                              Packet Pool control block     */
/*    name_ptr                              Packet Pool string pointer    */
/*    payload_size                          Size of packet payload        */
/*    pool_start                            Starting address of pool      */
/*    pool_size                             Number of bytes in pool       */
/*    pool_control_block_size               Size of packet pool control   */
/*                                            block                       */
/*                                                                        */
/*  OUTPUT                                                                */
/*                                                                        */
/*    status                                Completion status             */
/*                                                                        */
/*  CALLS                                                                 */
/*                                                                        */
/*    _nx_packet_pool_create                Actual packet pool create     */
/*                                            function                    */
/*    tx_thread_identify                    Get current thread pointer    */
/*    tx_thread_preemption_change           Change preemption for thread  */
/*                                                                        */
/*  CALLED BY                                                             */
/*                                                                        */
/*    Application Code                                                    */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-12-2005     William E. Lamie         Initial Version 5.0           */
/*  08-09-2007     William E. Lamie         Modified comment(s),          */
/*                                            resulting in version 5.1    */
/*  12-30-2007     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.2    */
/*  08-03-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.3    */
/*  11-23-2009     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.4    */
/*  06-01-2010     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.5    */
/*  10-10-2011     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.6    */
/*  01-31-2013     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.7    */
/*  01-12-2015     Yuxin Zhou               Modified comment(s),          */
/*                                            fixed compiler warnings,    */
/*                                            resulting in version 5.8    */
/*  02-22-2016     Yuxin Zhou               Modified comment(s), added    */
/*                                            supported packet alignment, */
/*                                            resulting in version 5.9    */
/*  05-10-2016     Yuxin Zhou               Modified comment(s), and      */
/*                                            fixed lint warnings,        */
/*                                            resulting in version 5.10   */
/*  07-15-2018     Yuxin Zhou               Modified comment(s),          */
/*                                            resulting in version 5.11   */
/*  12-15-2018     Yuxin Zhou               Modified comment(s), and      */
/*                                            supported for 64-bit mode,  */
/*                                            resulting in version 5.11SP1*/
/*                                                                        */
/**************************************************************************/
UINT  _nxe_packet_pool_create(NX_PACKET_POOL *pool_ptr, CHAR *name_ptr, ULONG payload_size,
                              VOID *pool_start, ULONG pool_size, UINT pool_control_block_size)
{

UINT            status;
ULONG           rounded_payload_size;
ULONG           rounded_pool_size;
ULONG           header_size;
UINT            old_threshold;
NX_PACKET_POOL *created_pool;
ULONG           created_count;
CHAR           *end_memory;
CHAR           *created_end;
CHAR           *payload_address;
VOID           *rounded_pool_start;
TX_THREAD      *current_thread;


    /* Check for invalid input pointers.  */
    if ((pool_ptr == NX_NULL) || (pool_start == NX_NULL) || (pool_control_block_size != (UINT)sizeof(NX_PACKET_POOL)))
    {
        return(NX_PTR_ERROR);
    }

    /* Align the starting address to four bytes. */
    /*lint -e{923} suppress cast between ULONG and pointer.  */
    rounded_pool_start = (VOID *)((((ALIGN_TYPE)pool_start + NX_PACKET_ALIGNMENT  - 1) / NX_PACKET_ALIGNMENT) * NX_PACKET_ALIGNMENT);

    /* Round the pool size down to something that is evenly divisible by alignment.  */
    /*lint -e{923} suppress cast between ULONG and pointer.  */
    rounded_pool_size = (ULONG)(((pool_size - ((ALIGN_TYPE)rounded_pool_start - (ALIGN_TYPE)pool_start)) / NX_PACKET_ALIGNMENT) * NX_PACKET_ALIGNMENT);

    /* Calculate the address of payload. */
    /*lint -e{923} suppress cast between ULONG and pointer.  */
    payload_address = (CHAR *)((ALIGN_TYPE)rounded_pool_start + sizeof(NX_PACKET));

    /* Align the address of payload. */
    /*lint -e{923} suppress cast between ULONG and pointer.  */
    payload_address = (CHAR *)((((ALIGN_TYPE)payload_address + NX_PACKET_ALIGNMENT  - 1) / NX_PACKET_ALIGNMENT) * NX_PACKET_ALIGNMENT);

    /* Calculate the header size. */
    /*lint -e{923} suppress cast between ULONG and pointer.  */
    header_size = (ULONG)((ALIGN_TYPE)payload_address - (ALIGN_TYPE)rounded_pool_start);

    /* Round the packet size up to something that helps guarantee proper alignment for header and payload.  */
    rounded_payload_size =  (ULONG)(((header_size + payload_size + NX_PACKET_ALIGNMENT  - 1) / NX_PACKET_ALIGNMENT) * NX_PACKET_ALIGNMENT - header_size);

    /* Check for an invalid pool and payload size.  */
    if ((pool_size <= NX_PACKET_ALIGNMENT) || (!payload_size) ||
        ((rounded_payload_size + header_size) > rounded_pool_size))
    {
        return(NX_SIZE_ERROR);
    }

    /* Calculate the end of the pool memory area.  */
    end_memory =  ((CHAR *)pool_start) + (pool_size - 1);

    /* Pickup current thread pointer.  */
    current_thread =  tx_thread_identify();

    /* Disable preemption temporarily.  */
    if (current_thread)
    {
        tx_thread_preemption_change(current_thread, 0, &old_threshold);
    }

    /* Loop to check for the pool instance already created.  */
    created_pool =   _nx_packet_pool_created_ptr;
    created_count =  _nx_packet_pool_created_count;
    while (created_count--)
    {

        /* Calculate the created pool's end of memory.  */
        created_end =  created_pool -> nx_packet_pool_start + (created_pool -> nx_packet_pool_size - 1);

        /* Is the new pool already created?  */
        /*lint -e{946} suppress pointer subtraction, since it is necessary. */
        if ((pool_ptr == created_pool) ||
            ((pool_start >= (VOID *)created_pool -> nx_packet_pool_start) && (pool_start < (VOID *)created_end)) ||
            ((end_memory  >= created_pool -> nx_packet_pool_start) && (end_memory  < created_end)))
        {

            /* Restore preemption.  */
            if (current_thread)
            {

                /*lint -e{644} suppress variable might not be initialized, since "old_threshold" was initialized by previous tx_thread_preemption_change. */
                tx_thread_preemption_change(current_thread, old_threshold, &old_threshold);
            }

            /* Duplicate packet pool created, return an error!  */
            return(NX_PTR_ERROR);
        }

        /* Move to next entry.  */
        created_pool =  created_pool -> nx_packet_pool_created_next;
    }

    /* Restore preemption.  */
    if (current_thread)
    {
        tx_thread_preemption_change(current_thread, old_threshold, &old_threshold);
    }

    /* Check for appropriate caller.  */
    NX_INIT_AND_THREADS_CALLER_CHECKING

    /* Call actual packet pool create function.  */
    status =  _nx_packet_pool_create(pool_ptr, name_ptr, payload_size, pool_start, pool_size);

    /* Return completion status.  */
    return(status);
}

#ifndef NX_DISABLE_INCLUDE_SOURCE_CODE
#include "nxe_packet_pool_low_watermark_set.c"
#endif /* NX_DISABLE_INCLUDE_SOURCE_CODE */

