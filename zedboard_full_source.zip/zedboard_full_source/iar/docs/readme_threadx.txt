                Express Logic's ThreadX for ZedBoard Evaluation Board (Cortex-A9) 

                                Using the IAR Tools

1.  Installation

ThreadX for ZedBoard Evaluation Board (Cortex-A9) is pre-installed in the evaluation package.


2.  Building the ThreadX run-time Library

Building the ThreadX library is easy. First, open the X-Ware_Platform workspace, select 
the "tx" project, right-click and select "Build Build". You should observe assembly and 
compilation of a series of ThreadX source files. This results in the ThreadX run-time 
library file tx.a, which is needed by the application.


3.  Demonstration System

The ThreadX demonstration is designed to execute under the ZedBoard Evaluation Board.  
Building the demonstration is easy; simply select the "demo_threadx" project, right-click,
and slecect "Build Project". This will build the ThreadX demonstration for the ZedBoard 
board. 

Next, select "Download and Debug" to download and start execution of the demonstration. Select
"Go" to start execution of the demonstration.


4.  System Initialization

The entry point in ThreadX for the Cortex-A9 using IAR tools is at label _boot. 
This is defined within the modified version of the IAR startup code - asm_vectors.S.
This file contains the necessary ThreadX context management surrounding the Xilinx
IRQ handler function IRQInterrupt.


5.  Register Usage and Stack Frames

The IAR compiler assumes that registers r0-r3 (a1-a4) and r12 (ip) are 
scratch registers for each function. All other registers used by a C function 
must be preserved by the function. ThreadX takes advantage of this in 
situations where a context switch happens as a result of making a ThreadX 
service call (which is itself a C function). In such cases, the saved 
context of a thread is only the non-scratch registers.

The following defines the saved context stack frames for context switches
that occur as a result of interrupt handling or from thread-level API calls.
All suspended threads have one of these two types of stack frames. The top
of the suspended thread's stack is pointed to by tx_thread_stack_ptr in the 
associated thread control block TX_THREAD.



    Offset        Interrupted Stack Frame        Non-Interrupt Stack Frame

     0x00                   1                           0
     0x04                   CPSR                        CPSR
     0x08                   r0  (a1)                    r4  (v1)
     0x0C                   r1  (a2)                    r5  (v2)
     0x10                   r2  (a3)                    r6  (v3)
     0x14                   r3  (a4)                    r7  (v4)
     0x18                   r4  (v1)                    r8  (v5)
     0x1C                   r5  (v2)                    r9  (v6)
     0x20                   r6  (v3)                    r10 (v7)
     0x24                   r7  (v4)                    r11 (fp)
     0x28                   r8  (v5)                    r14 (lr)
     0x2C                   r9  (v6)                        
     0x30                   r10 (v7)                        
     0x34                   r11 (fp)                        
     0x38                   r12 (ip)                         
     0x3C                   r14 (lr)
     0x40                   PC 


6.  Interrupt Handling

ThreadX provides complete and high-performance interrupt handling for Xilinx Cortex-A9
targets. All interrupt service routines created by the IAR tools that are called
from IRQInterrupt are compatible with ThreadX.


7.  ThreadX Timer Interrupt

ThreadX requires a periodic interrupt source to manage all time-slicing, 
thread sleeps, timeouts, and application timers. Without such a timer 
interrupt source, these services are not functional but the remainder of 
ThreadX will still run.

The demo_threadx.c file defines the periodic timer setup for the demonstration.


8. VFP Support

By default, VFP support is disabled for each thread. If saving the context of the VFP registers
is needed, the following API call must be made from the context of the application thread - before 
the VFP usage:

void    tx_thread_vfp_enable(void);

After this API is called in the application, VFP registers will be saved/restored for this thread if it
is preempted via an interrupt. All other suspension of the this thread will not require the VFP registers
to be saved/restored.

To disable VFP register context saving, simply call the following API:

void    tx_thread_vfp_disable(void);



9.  Revision History

04/01/2018  Initial ThreadX version for ZedBoard Evaluation Board (Cortex-A9) using IAR's ARM tools.


Copyright(c) 1996-2018 Express Logic, Inc.


Express Logic, Inc.
11423 West Bernardo Court
San Diego, CA  92127

www.expresslogic.com

